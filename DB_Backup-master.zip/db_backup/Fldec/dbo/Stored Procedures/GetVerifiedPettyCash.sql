﻿CREATE Procedure [dbo].[GetVerifiedPettyCash](@usId int)
as
begin
declare @roleN varchar(200)
select  @roleN= roleName from tblRoles tR
where roleId in (select roleId from tblrolemapping where userId=@usId)



if @roleN = 'Accounts' or @roleN='Admin'
begin
	select PettyCashID, (select shortNameFrSite from tblSiteNames where sId=siteid) as siteN,
	Description, DebitAmount, case [Status] when 4 then 'Verified' when 3 then 'Cancelled' end as status, 
	convert(varchar,CreatedDate,103)  + ' ' + convert(varchar,CreatedDate,108) as cDate,
	(select UserName from tblUsers where userId= tPc.UserID) as pUName
	from [dbo].[tblPettyCashNew] tPc where [Status]  in (4,3)
	order by CreatedDate desc
end
else
begin
declare @uNa varchar(200)
select @uNa = UserName from tblUsers where userId= @usId
select PettyCashID,(select shortNameFrSite from tblSiteNames where sId=siteid) as siteN,
Description, DebitAmount, case [Status] when 4 then 'Verified' when 3 then 'Cancelled' end as status, 
convert(varchar,CreatedDate,103)  + ' ' + convert(varchar,CreatedDate,108) as cDate, @uNa as  pUName
from [dbo].[tblPettyCashNew] where UserID = @usId and [Status] in (4,3)
order by CreatedDate desc
end
end