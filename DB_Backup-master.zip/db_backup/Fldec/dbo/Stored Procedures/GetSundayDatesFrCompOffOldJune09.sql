﻿create procedure [dbo].[GetSundayDatesFrCompOffOldJune09](@userId int)
as
begin

declare @d datetime
select @d = convert(varchar,year(getdate())) +'0201'  --'20090101'  if you want 2009 etc etc

select dateadd(dd,number,@d) as sDate from master..spt_values
where type = 'p'
and year(dateadd(dd,number,@d))=year(@d)
and month(dateadd(dd,number,@d)) <= month(getdate())
and DATEPART(dw,dateadd(dd,number,@d)) = 1
and dateadd(dd,number,@d) not in (
select leaveStartedOn from tblrequestleave where leaveStartedOn<>'1900-01-01 00:00:00.000' and userId = @userId)
end