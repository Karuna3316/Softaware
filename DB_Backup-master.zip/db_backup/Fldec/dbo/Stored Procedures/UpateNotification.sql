﻿CREATE procedure [dbo].[UpateNotification](@NotificationId int, @NotificationName nvarchar(500))

as
begin
if @NotificationId >0
begin
update [tblNotification] set NotificationName= @NotificationName
 where NotificationId=@NotificationId
end
else
begin
	insert into [tblNotification](NotificationName)
	select @NotificationName
	select @NotificationId=max(NotificationId) from [tblNotification]


	

	
end

--if @docId >0
--	update [tbldocument] set NotificationId = @NotificationId 
--else
--begin

--insert into [tbldocument](NotificationId)
select @NotificationId
end