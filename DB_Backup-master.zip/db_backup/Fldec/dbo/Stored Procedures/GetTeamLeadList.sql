﻿--[GetTeamLeadList] 1
CREATE PROCEDURE [dbo].[GetTeamLeadList]
    @reqUserId INT
AS
BEGIN
    DECLARE @ReportingTo INT

    SELECT @ReportingTo = ReportingManagerId FROM tblUsers WHERE userId = @reqUserId

    -- Check if the @reqUserId is a Team Lead
    DECLARE @IsTeamLead BIT
    SELECT @IsTeamLead = isTeamLead FROM tblUsers WHERE userId = @reqUserId

    -- If @reqUserId is a Team Lead, select only Team Leads (excluding @reqUserId)
    IF (@IsTeamLead = 1)
    BEGIN
        SELECT 0 AS userid, 'Select Reporting Person' AS username
        UNION
        SELECT userid, username FROM tblUsers WHERE isTeamLead = 1 AND userId <> @reqUserId
    END
    ELSE -- If @reqUserId is not a Team Lead, follow the original logic
    BEGIN
        SELECT 0 AS userid, 'Select Reporting Person' AS username
        UNION
        SELECT userid, username FROM tblUsers WHERE userId = @ReportingTo
    END
END