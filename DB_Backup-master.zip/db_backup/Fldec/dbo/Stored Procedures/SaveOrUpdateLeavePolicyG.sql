﻿
create procedure [dbo].[SaveOrUpdateLeavePolicyG] (@Permission int,@Regularize int,@Leave int, @userId int, @Id int)
as
begin

if(@Id > 0)
begin
update tblUsers set IsPermission = @Permission,IsRegularise = @Regularize,IsLeave = @Leave , userId = @userid  where Id = @Id

select 2
end
else
begin

if not exists (select userid from tblUsers with (nolock) where IsPermission = @Permission and IsRegularise = @Regularize and IsLeave = @Leave and userId = @userId)
begin
	insert into tblUsers( UserId,IsPermission, IsRegularise, IsLeave)
	select @userId, 1, 1, 1
	Select 1
end
else
begin
Select 3
end


	end

end