﻿
CREATE procedure [dbo].[SaveOrUpdateManualAttendance]---0, 130, '2023-03-21 12:23:00.000', '2023-03-21 12:23:50.000', 1, 1
( @AttendanceID int,@userId int,@CheckInDate datetime,@CheckOutDate datetime=null,@Createdby int,@ActionType int)
as
begin

if(@AttendanceID = 0 and @ActionType = 1)
begin

if not exists (select AttendanceID from tblAAttendance with (nolock) where UserID=@userId  AND (convert(varchar(10),CheckInDate,101) = convert(varchar(10),@CheckInDate,101)))
begin

if(@CheckOutDate is null)
begin
	insert into tblAAttendance(UserID,CheckInDate,CheckOutDate,Createdby,createddate,CheckIn,CheckOut)
	select @userId,@CheckInDate,@CheckOutDate,@Createdby,getdate(),1,1
	select 1
end
else
begin
	insert into tblAAttendance(UserID,CheckInDate,CheckOutDate,Createdby,createddate,CheckIn,CheckOut)
	select @userId,@CheckInDate,@CheckOutDate,@Createdby,getdate(),1,1
	select 1
end
	
	end
	else
	Select 3

end
else
begin

if (@ActionType = 2)
begin
if(@AttendanceID <> 0)
begin
update tblAAttendance set CheckInDate = @CheckInDate, CheckOutDate = @CheckOutDate,Updatedby=@Createdby,UpdatedDate=getdate() where AttendanceID = @AttendanceID
select 2
end
else
select 4

end

end

END

--select * from tblUsers where UserName like '%anan%'


--select * from tblAAttendance where userid = 130 order by CheckInDate desc