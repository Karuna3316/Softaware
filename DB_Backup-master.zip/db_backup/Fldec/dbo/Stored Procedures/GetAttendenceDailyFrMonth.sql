﻿
--GetAttendenceDailyFrMonthEditingFeb0122 11
CREATE Procedure [dbo].[GetAttendenceDailyFrMonth](@mon int,@vYear int)
as
begin
declare @tDates table(strDate varchar(50))
declare @sD int, @eD int,@curDay int

--declare @curMon int
--select @curMon =month(getdate())

--if @vYear is null
--select @vYear = year(getdate())
----set @curMon = @curMon + 12
--declare @currentDayNo int
--SELECT  @currentDayNo = DATENAME(d,getdate());

declare @dateToStartFrMon datetime

declare @dName int
select @dName=case @mon 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end

declare @dv nvarchar(50)
set @dv='yy-mm-dd'
select @dv = replace(@dv,'yy',@vYear)
--select @dv
select @dv = replace(@dv,'mm',@mon)
--select @dv
select @dv = replace(@dv,'dd',@dName)
--select @dv
select @dateToStartFrMon = convert(datetime,@dv)
--select @dateToStartFrMon



set @sD = 0
set @eD = @dName

while @sD <@eD
begin
insert into @tDates select convert(varchar,@dateToStartFrMon-(@eD-1),103)
set @eD = @eD - 1
end
--select * from @tDates
declare @totalDays int
select  @totalDays = count(strDate)  from @tDates
   declare @dCols varchar(3000),@eQry nvarchar(max)
   declare @totCols varchar(3000)

    set @totCols = STUFF(
 (select '+[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') 
 
 set @dCols = STUFF(
 (select ',[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
 
 --select @dCols

 declare @sCols varchar(max)
 set @sCols = STUFF(
 (select ',case when  +' + char(39)+ strDate +char(39) + ' in (select convert(varchar,holidaydate,103) from tblHolidays where month(holidayDate) = ' + convert(varchar,@mon) + ') then ''FD'' when [' + strDate + ']=0 then ''A'' else ''P'' end as [' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')

 declare @nQry nvarchar(max)
 
 set @eQry=' declare @tDates1 table(strDate datetime)
declare @sD1 int, @eD1 int,@curDay1 int
declare @dateToStartFrMon1 datetime
declare @dName1 int

select @dName1=case ' + convert(varchar,@mon) + ' 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end

declare @dv1 nvarchar(50)
set @dv1=''yy-mm-dd''
select @dv1 = replace(@dv1,''yy'','+convert(varchar,@vYear) +')

select @dv1 = replace(@dv1,''mm'',' + convert(varchar,@mon) + ')

select @dv1 = replace(@dv1,''dd'',@dName1)

select @dateToStartFrMon1 = convert(datetime,@dv1)
--select @dateToStartFrMon



set @sD1 = 0
set @eD1 = @dName1



while @sD1 <@eD1
begin
insert into @tDates1 select @dateToStartFrMon1-(@eD1-1)
set @eD1 = @eD1 - 1

end

--select * from  @tDates1

declare @totalDays int
select  @totalDays = count(strDate)  from @tDates1

 declare @sundayCount int
select @sundayCount = count(strDate) from @tDates1 
where DATENAME(dw,strDate) =''sunday''

declare @totHolidays int
select @totHolidays = count(hId) from tblHolidays where MONTH(holidayDate) = ' + convert(varchar,@mon) + '

 
	SELECT [UserName],' + @sCols + ',(((' + @totCols +') -(hL*0.5))-(@sundayCount-[sunday]))- (@totHolidays - festivalDays) as [Total Present], ((@totalDays- festivalDays)- (convert(int,( ' + @totCols  + '))+(@sundayCount-(@sundayCount-sunday)))) + (hL*0.5)  as [Total Absent], @sundayCount-[sunday] as [Sunday Worked],@totHolidays - festivalDays as [Festival Days Worked]
FROM (SELECT  
tU.UserName ,
       convert(varchar, checkindate,103) as [Days],
Checkin as [Presence]       
      FROM [tblAAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
       group by UserName,convert(varchar, checkindate,103),Checkin) A
      PIVOT( count(A.Presence)   
    FOR [Days] IN (' + @dCols +')
	) AS MNamePivot  join 
	(
	select sC.uname, [working days],[Leave],[sunday],hL,festivalDays from (
	select tU.UserName as uname, sum(case when checkin=1 then 1 end) as [working days] , isnull(sum(case when checkin is null then 1 end),0) as [Leave],
@sundayCount  - (select count(checkindate) FROM [tblAAttendance] where
 CheckIn = 1 and UserID= tA.userID and month(checkindate) =' + convert(varchar,@mon) + '
 and convert(varchar,checkindate,103) in (
select convert(varchar,strDate,103) from  @tDates1 
where DATENAME(dw,strDate) =''sunday'')) as [sunday],
(select count(strDate) from  @tDates1 where convert(varchar,strDate,103) not in (select convert(varchar,checkindate,103) FROM [tblAAttendance] where
  UserID= tA.userID and month(checkindate) =' + convert(varchar,@mon) + ' ) and convert(varchar,strDate,103) in (select convert(varchar,holidaydate,103) from tblHolidays where month(holidayDate) = ' + convert(varchar,@mon) + ')) as [festivalDays]
--sum(case when tH.holidaydate is null then 1 else 0 end) )as [festivalDays] 
	   from [tblAAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	  --left join tblHolidays tH on convert(varchar,tA.checkindate,103) = convert(varchar,tH.holidaydate,103)
	    where 
		--tA.userid in (25,28) and 
		month(checkindate) =' + convert(varchar,@mon) + '
	   group by tU.UserName,tA.userID) sC
	   
	   join
	   (
	   select tU.UserName as uname,  sum(case when reason=''Half day Leave'' then 1 else 0 end ) as hL 
 
	   from [tblAAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where  
		--tA.userid in (25,28) and 
		month(checkindate) =' + convert(varchar,@mon) + '
	   group by tU.UserName,tA.userID) hC on sC.uname = hC.uname
	   ) tL  on MNamePivot.UserName = tL.uname
	 '

--print @eQry
--select @eQry

	exec(@eQry)
end