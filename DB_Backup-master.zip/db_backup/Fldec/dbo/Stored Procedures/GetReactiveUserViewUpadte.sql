﻿CREATE procedure [dbo].[GetReactiveUserViewUpadte] (@userId int)
as
begin

update  tblUsers set active=1 where userId=@userId

Select 1
end