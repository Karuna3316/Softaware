﻿
--GetClaimableLeaves 138
--select * from tblLeaveBalanceMaster where userid=15
--select * from tblRequestLeave where userid=15
--[GetClaimableLeavesATesting] 15
CREATE procedure [dbo].[GetClaimableLeave] (@userId int)
as
begin
--select * from tblRequestLeave
select
(select  isnull(sum(CasualLeave),0) from [dbo].[tblLeaveBalanceMaster] where userId=@userId and month(createddate) <= month(getdate()) and [year]=year(getdate())) -(

isnull((select  sum(case when leaveDaysType = 6 then 6
			when leaveDaysType = 8 then 0.5
			when leaveDaysType= 7 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=9 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1)),0) 
+ isnull((select  sum(case when leaveType = 6 then 6
			when leaveType = 8 then 0.5
			when leaveType= 7 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=9 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1)),0)) clClaimable,

(select  isnull(sum(SickLeave),0) from [dbo].[tblLeaveBalanceMaster] where userId=@userId and month(createddate) <= month(getdate()) and [year] = year(getdate())) - (
isnull(((select  sum(case when leaveDaysType = 6 then 6
			when leaveDaysType = 8 then 0.5
			when leaveDaysType= 7 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=10 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1))),0) 
+ isnull(((select  sum(case when leaveType = 6 then 6
			when leaveType = 8 then 0.5
			when leaveType= 7 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=10 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1))),0)) slClaimable
end