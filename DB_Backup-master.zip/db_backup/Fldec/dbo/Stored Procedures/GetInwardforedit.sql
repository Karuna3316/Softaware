﻿CREATE procedure [dbo].[GetInwardforedit](@InwardId int)
AS
begin  
SELECT InwardId,SupplierId,  PONumberId , 
ProductsId = STUFF((SELECT ',' + ProductsId FROM tblfdss_InwardProducts where InwardId=@InwardId FOR XML PATH ('')), 1, 1, ''),
Qty = STUFF((SELECT ',' + Qty FROM tblfdss_InwardProducts where InwardId=@InwardId FOR XML PATH ('')), 1, 1, ''),
ReceievedQty = STUFF((SELECT ',' + ReceievedQty FROM tblfdss_InwardProducts where InwardId=@InwardId FOR XML PATH ('')), 1, 1, '')
from tblfdss_Inward where InwardId =@InwardId

END