﻿CREATE procedure [dbo].[GetHelpList]
AS
begin  
select HelpId,HelpmenuId,dbo.fn_Help(HelpmenuId) as Description , Document  from tblhelp


end