﻿create proc [dbo].[DeleteCustomerMaster]
(@CID int)
as
begin
delete from tblfdss_CustomerMaster  where CID = @CID
end