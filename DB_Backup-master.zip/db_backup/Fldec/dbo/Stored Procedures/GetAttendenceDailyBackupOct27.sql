﻿create Procedure [dbo].[GetAttendenceDailyBackupOct27]
as
begin
 declare @tDates table(strDate varchar(50))
declare @sD int, @eD int,@curDay int
--SELECT DAY(EOMONTH(getdate())) AS DaysInMonth		
SELECT @curDay = DATENAME(d,getdate());
set @sD = 1
set @eD = @curDay
declare @dateToStartFrMon datetime
set @dateToStartFrMon = getdate()-@curDay
--select @dateToStartFrMon
while @sD <=@eD
begin
insert into @tDates select convert(varchar,@dateToStartFrMon+@sD,103)
set @sD = @sD + 1
end

--select * from @tDates
declare @totalDays int
select  @totalDays = count(strDate)  from @tDates
   declare @dCols varchar(3000),@eQry nvarchar(max)
   declare @totCols varchar(3000)

    set @totCols = STUFF(
 (select '+[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') 
 
 set @dCols = STUFF(
 (select ',[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
 
 --select @dCols

 declare @sCols varchar(max)
 set @sCols = STUFF(
 (select ',case when [' + strDate + ']=0 then ''A'' else ''P'' end as [' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') 
 
 --select @sCols 
 

	
--	set @eQry='SELECT [UserName],' + @sCols + '
--FROM (SELECT  
--tU.UserName ,
--       convert(varchar, checkindate,103) as [Days],
--tU.UserName as [Presence]       
--      FROM [tblAttendance] tA
--	  join tblUsers tU on tU.userId = tA.UserID
--       group by UserName,convert(varchar, checkindate,103)) A
--      PIVOT( count(A.Presence)   
--    FOR [Days] IN (' + @dCols +')
--	) AS MNamePivot'

	set @eQry=' declare @tDates1 table(strDate datetime)
declare @sD1 int, @eD1 int,@curDay1 int
--SELECT DAY(EOMONTH(getdate())) AS DaysInMonth
SELECT @curDay1 = DATENAME(d,getdate())
--select @curDay1
set @sD1 = 1
set @eD1 = @curDay1
declare @dateToStartFrMon1 datetime
set @dateToStartFrMon1 = getdate()-@curDay1
--select @dateToStartFrMon
while @sD1 <=@eD1
begin
insert into @tDates1 select @dateToStartFrMon1+@sD1 
set @sD1 = @sD1 + 1
end

declare @totalDays int
select  @totalDays = count(strDate)  from @tDates1

 declare @sundayCount int
select @sundayCount = count(strDate) from @tDates1 
where DATENAME(dw,strDate) =''sunday''

--select @sundayCount

 
	SELECT [UserName],' + @sCols + ',((' + @totCols +') -(hL*0.5)) - (@sundayCount-[sunday]) as [Total Present], (@totalDays- (convert(int,( ' + @totCols  + '))+(@sundayCount-(@sundayCount-sunday)))) + (hL*0.5)  as [Total Absent], @sundayCount-[sunday] as [Sunday Worked]
FROM (SELECT  
tU.UserName ,
       convert(varchar, checkindate,103) as [Days],
Checkin as [Presence]       
      FROM [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
       group by UserName,convert(varchar, checkindate,103),Checkin) A
      PIVOT( count(A.Presence)   
    FOR [Days] IN (' + @dCols +')
	) AS MNamePivot  join 
	(
	select sC.uname, [working days],[Leave],[sunday],hL from (
	select tU.UserName as uname, sum(case when checkin=1 then 1 end) as [working days] , isnull(sum(case when checkin is null then 1 end),0) as [Leave],
@sundayCount  - (select count(checkindate) FROM [tblAttendance] where
 CheckIn = 1 and UserID= tA.userID and month(checkindate) =month(getdate())
 and convert(varchar,checkindate,103) in (
select convert(varchar,strDate,103) from  @tDates1 
where DATENAME(dw,strDate) =''sunday'')) as [sunday]
	   from [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where 
		--tA.userid in (25,28) and 
		month(checkindate) =month(getdate())
	   group by tU.UserName,tA.userID) sC
	   
	   join
	   (
	   select tU.UserName as uname,  sum(case when patindex(''%half day%'',reason) > 0 then 1 else 0 end ) as hL 
 
	   from [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where  
		--tA.userid in (25,28) and 
		month(checkindate) =month(getdate())
	   group by tU.UserName,tA.userID) hC on sC.uname = hC.uname
	   ) tL  on MNamePivot.UserName = tL.uname
	 '

--print @eQry

	exec(@eQry)

	end
  --select tU.UserName as uname, sum(case when checkin=1 then 1 end) as [working days] , isnull(sum(case when checkin is null then 1 end),0) as [Leave]
	 --  from [tblAttendance] tA
	 -- join tblUsers tU on tU.userId = tA.UserID
	 --   where 
		----tA.userid in (25,28) and 
		--DATENAME(M,checkindate) ='july'
	 --  group by tU.UserName
	 /*
	 (select tU.UserName as uname, sum(case when checkin=1 then 1 end) as [working days] , isnull(sum(case when checkin is null then 1 end),0) as [Leave]
	   from [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where 
		--tA.userid in (25,28) and 
		DATENAME(M,checkindate) =''july''
	   group by tU.UserName) tL  on MNamePivot.UserName = tL.uname
	 */