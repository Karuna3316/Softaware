﻿
CREATE procedure [dbo].[GetProjectList]
as
begin
select '0' as ProjectNo, 'Select Project' as ProjectName
union
select ProjectId, ProjectName from InvtblProject 
end