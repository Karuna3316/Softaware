﻿CREATE procedure [dbo].[GetTripDocs]
as
begin
select tTrip.Truckid,tTrip.TripNo as [TripNo], DCNo, format(tTrip.createdDate,'dd/MM/yyyy') as [Date],
tDoc.DCCopy,tDoc.RoyaltySlip, tDoc.LandTWeighBil
from [dbo].[VECtblTripdetails] tTrip
left join [VECtblDocuments] tDoc on tDoc.TruckId = tTrip.Truckid and tDoc.tripno = tTrip.TripNO
where tTrip.Truckid is not null
order by DCNo
end