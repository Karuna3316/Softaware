﻿create proc [dbo].[GetStatusticAdminPending]
as
begin


select 


(select Count(*) as count from tblReconciliationNew with(nolock) where  year(CheckIn) = year(getdate()) and  month(CheckIn) = month(getdate()) and approvedUser is null ) as Noofdays,

(select  Count(*) as count  from tblPermission with(nolock)  where year(CheckIn) = year(getdate()) and month(CheckIn) = month(getdate()) and approvedUser is null ) as Present,

(select  count(*) as count from tblRequestLeave with(nolock) where year(leavestartedOn) = year(getdate()) and  month(leavestartedOn) = month(getdate()) and approvedUser is null) as Absent 

end