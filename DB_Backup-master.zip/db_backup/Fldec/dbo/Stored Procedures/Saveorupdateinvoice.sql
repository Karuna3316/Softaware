﻿CREATE procedure [dbo].[Saveorupdateinvoice](  @InvoiceId int, @SupplierId int,@PONumberId int,@InvoiceNo nvarchar(200)=null,@InvoiceDate datetime=null,@Igst decimal(18, 2)=null,@Cgst decimal(18, 2)=null,@Sgst decimal(18, 2)=null,@GVInvoice decimal(18, 2)=null,@userId int,@FileName nvarchar(max)=null,@LPrice nvarchar(max),@Discount nvarchar(max),@Qty nvarchar(max),@ProductsId nvarchar(max) )

as
begin
if(@InvoiceId > 0)
begin
update tblfdss_Invoice set  SupplierId = @SupplierId,PONumberId=@PONumberId,InvoiceNo = @InvoiceNo,InvoiceDate=@InvoiceDate,Igst =@Igst,Cgst =@Cgst,Sgst =@Sgst,GVInvoice =@GVInvoice ,UpdatedDate=GETDATE(),Updatedby=@userId,FileName=@FileName where InvoiceId  =  @InvoiceId

select 2
IF @ProductsId IS NOT NULL AND LEN(@ProductsId) > 0
BEGIN TRY
    BEGIN TRAN 

DELETE FROM tblfdss_ProductsInvoice WITH (TABLOCK) WHERE InvoiceId = @InvoiceId

INSERT INTO tblfdss_ProductsInvoice WITH (TABLOCK) (InvoiceId,CreatedDate,CreatedBy, LPrice, Discount, Qty,ProductsId)
SELECT @InvoiceId, GETDATE(),@userId,s.Item,a.Item,n.Item,t.Item 
FROM dbo.fnSplitString(@LPrice, ',') s
JOIN dbo.fnSplitString(@Discount, ',') a ON s.ID = a.ID
JOIN dbo.fnSplitString(@Qty, ',') n ON s.ID = n.ID
JOIN dbo.fnSplitString(@ProductsId, ',') t ON s.ID = t.ID;
COMMIT TRAN 
END TRY
BEGIN CATCH
    ROLLBACK TRAN 
END CATCH
end

else
begin
if not exists (select InvoiceId from tblfdss_Invoice where InvoiceId =@InvoiceId )
begin
	insert into [tblfdss_Invoice]( SupplierId, PONumberId,InvoiceNo,InvoiceDate,Igst,Cgst,Sgst,GVInvoice,CreatedDate,Createdby,FileName)
	select @SupplierId, @PONumberId,@InvoiceNo,@InvoiceDate,@Igst,@Cgst,@Sgst,@GVInvoice, GETDATE(),@userId,@FileName
	Select 1

	DECLARE @InvoeId int
   SET @InvoeId = SCOPE_IDENTITY()

   if @ProductsId is not null and len(@ProductsId)>0
begin
	insert into [tblfdss_ProductsInvoice](InvoiceId,CreatedDate,CreatedBy,LPrice,Discount,Qty,ProductsId)
	select @InvoeId,GETDATE(),@userId,
	s.Item AS LPrice,
    a.Item AS Discount,
    n.Item AS Qty,
	t.Item AS ProductsId
FROM dbo.fnSplitString(@LPrice, ',') s
JOIN dbo.fnSplitString(@Discount, ',') a ON s.ID = a.ID
JOIN dbo.fnSplitString(@Qty, ',') n ON s.ID = n.ID
JOIN dbo.fnSplitString(@ProductsId, ',') t ON s.ID = t.ID;
	
	end
	end


else
begin
Select 3

end

end
end