﻿
--GetStatisticsPayroll 1
CREATE procedure [dbo].[GetStatisticsPayroll](@userId int)
as
begin
declare @Total int, @Approved int, @Declined int, @Pending int


set @Total = 120
set @Approved = 40
set @Declined = 60
set @Pending = 20

select @Total as Total ,@Approved as Approved,@Declined as Declined,@Pending as Pending


end