﻿CREATE proc [dbo].[ReminderPettyCashlowamount]
as
begin
Declare @resMsg varchar(max);

WITH expression_name(UserID, Creditamount, ExpenseAmount) 
AS 
( 

select P.userId, isnull(sum(CreditAmount),0) -   (select Isnull(Sum(DebitAmount),0) from [dbo].[tblPettyCashNew]
 where Status in (4) and UserID = P.UserID), Isnull(Sum(DebitAmount),0) from [dbo].[tblPettyCashNew] P 
inner join tblusers U 
on P.Userid = U.Userid and ( P.Status  =2  or P.Status is null)
group by  P.UserID

 )

 select @resMsg = '_*Petty Cash Remainder*_  ' +  
 '  ('+ Convert(varchar(5000),(select STUFF((select ',  '+   UserName + ' - Rs. '+ Convert(varchar(12),(Creditamount-ExpenseAmount )) from expression_name E
 inner join [dbo].[tblUsers] U
 on U.userId = E.UserID where Creditamount-ExpenseAmount < 1500  and Creditamount <> 0
 order by U.UserID

  FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')))+' )'


 if  @resMsg is not null
 begin
 insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('917010633708',@resMsg,1,getdate())
  insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('917305068451',@resMsg,1,getdate())

 end
 end

--select * from [dbo].[tblMobileNos]