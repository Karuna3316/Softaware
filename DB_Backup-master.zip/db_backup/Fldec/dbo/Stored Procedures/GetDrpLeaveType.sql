﻿Create procedure [dbo].[GetDrpLeaveType]
as
begin
select Id , Description  from tblDropdown where Dropdowntype = 'LeaveType'
end