﻿--select * from  [dbo].[tblDPRNew]

--Field Names : SiteName, SLNO as [BOQ NO],  WorkDescription as [Work Description], Quantity, Unit

CREATE proc [dbo].[GetDailyProgress](@usId int,@rName varchar(100))
as
Begin
	if  @rName='Admin'
	begin
		select 
	(select SiteName from tblSiteNames where sId = siteId) as sN , SLNO as [BOQNo], WorkDescription, Qty,Unit, FORMAT(CreatedDate,'MM/dd/yyyy hh:mm tt') as crDate
	from [tblDPRNew] order by CreatedDate desc
	end
	else
	begin
	
		declare @projId varchar(200)
		select @projId =projId from tblUsers where userId=@usId
	select 
	(select SiteName from tblSiteNames where sId = siteId) as sN , SLNO as [BOQNo], WorkDescription, Qty,Unit,FORMAT(CreatedDate,'MM/dd/yyyy hh:mm tt') as crDate 
	from [tblDPRNew] where siteId in (select item from [dbo].[fnSplitString](@projId,','))
	order by CreatedDate desc
	end
End