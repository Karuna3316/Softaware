﻿
CREATE procedure [dbo].[SaveOrUpdateMPayroll] (@PayrollID int,  @EmpId nvarchar(500), @EmpName nvarchar(500),@BankacNo nvarchar(500),@BankIFSCcode nvarchar(500),

@Earnings decimal(18,2),@Deductions decimal(18,2),@Netpay decimal(18,2), @Userid int)
as
begin

if(@PayrollID > 0)
begin
update tblPayrollM set EmpId = @EmpId, EmpName = @EmpName, BankacNo = @BankacNo, BankIFSCcode = @BankIFSCcode,Earnings = @Earnings,UpdatedBy = @Userid,

Deductions = @Deductions,Netpay = @Netpay ,Updateddate = getdate() where PayrollID = @PayrollID
select 2
end
else
begin
if not exists (select EmpId from [tblPayrollM] with (nolock) where Month(createddate) = month(getdate()) and EmpName = @EmpName)
begin

if(day(getdate()) >= 5)
begin
	insert into [tblPayrollM](EmpId, EmpName,BankacNo,BankIFSCcode,Earnings,Deductions,Netpay, createddate, ActualCreatedDate, CreatedBy, active)
	select @EmpId,@EmpName,@BankacNo,@BankIFSCcode,@Earnings,@Deductions,@Netpay, Getdate(), getdate(), @Userid, 1
	select 1
end
else
begin
	insert into [tblPayrollM](EmpId, EmpName,BankacNo,BankIFSCcode,Earnings,Deductions,Netpay, createddate, ActualCreatedDate, CreatedBy, active)
	select @EmpId,@EmpName,@BankacNo,@BankIFSCcode,@Earnings,@Deductions,@Netpay, Getdate()-day(getdate()) , getdate(), @Userid, 1
	select 1
end
	
	end
	else
	Select 3

end

END