﻿CREATE proc [dbo].[Sp_Admin_Regularize]
as
begin
select Top 3 dbo.fn_username(userid) as EmployeeName , Count(*) as Count
from tblAAttendance A  where  year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and
((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)
group by dbo.fn_username(userid) order by Count(*) desc
end