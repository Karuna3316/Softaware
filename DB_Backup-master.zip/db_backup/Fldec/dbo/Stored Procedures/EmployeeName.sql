﻿CREATE proc [dbo].[EmployeeName]
as
begin
select UserId, UserName from tblUsers where isTeamLead=1  order by UserName

end