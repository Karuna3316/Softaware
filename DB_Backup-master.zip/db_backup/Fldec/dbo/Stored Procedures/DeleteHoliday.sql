﻿CREATE proc [dbo].[DeleteHoliday]
(@Dimid int)
as
begin
delete from tbldim where DimId = @Dimid
end