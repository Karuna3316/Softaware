﻿
CREATE procedure [dbo].[SaveOrUpdateTeam] (  @Team nvarchar(2000), @TeamID int)
as
begin

if(@TeamID > 0)
begin
update tblTeam set  Team = @Team where TeamID = @TeamID

select 2
end
else
begin
--if not exists (select Team from tblTeam with (nolock) where convert(varchar(12), createdDate, 103) = convert(varchar(12), @createdDate, 103))
--begin
	insert into [tblTeam]( Team)
	select @Team
	Select 1
	--end
	--else
	--Select 3

	end

end