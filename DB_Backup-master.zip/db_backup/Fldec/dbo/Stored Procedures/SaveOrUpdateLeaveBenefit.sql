﻿
CREATE procedure [dbo].[SaveOrUpdateLeaveBenefit] (@Date datetime, @Userid int, @LBId int)
as
begin

if(@LBId > 0)
begin
update tblLeaveBalanceMaster set CreatedDate = @Date, Year = year(@Date), UserId = @Userid  where lBId = @LBId

select 2
end
else
begin

if not exists (select userid from tblLeaveBalanceMaster with (nolock) where year = year(@Date) and month(createddate) = month(@Date) and userid = @userid)
begin
	insert into tblLeaveBalanceMaster(CreatedDate, UserId, Year, CasualLeave, SickLeave)
	select @Date, @Userid, year(@Date), 1.0, 0.5
	Select 1
end
else
begin
Select 3
end


	end

end