﻿CREATE proc [dbo].[Credentials]
as
begin
select Username, password , rolename  from [dbo].[tblRoleMapping] RM
inner join [dbo].[tblUsers] U on RM.userId = U.userId
inner join tblRoles R on R.roleId = Rm.roleId

end