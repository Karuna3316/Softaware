﻿--[GetAbsentDates] 15
CREATE procedure [dbo].[GetAbsentDates](@userId int)
as
begin
if (day(getdate()) > 2)
begin

select CheckInDate from  tblAAttendance where userId=@userId 
and  convert(date,CheckInDate) not in (select convert(date,checkin) from [tblReconciliationNew] with(nolock) where userId = @userId) and year(Checkindate) = year(getdate()) and month(checkindate)  in ( month(getdate())) 
and ((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)

end
else
begin
select CheckInDate from  tblAAttendance where userId=@userId 
and  convert(date,CheckInDate) not in (select convert(date,checkin) from [tblReconciliationNew]  with(nolock) where userId = @userId) and year(Checkindate) = year(getdate()) and month(checkindate)  in ( month(getdate()), month(getdate())-1) 
and ((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)

end

end