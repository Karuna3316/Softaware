﻿CREATE proc [dbo].[DeleteIndustryType]
(@MasterID int)
as
begin
delete from tblfdss_Master where MasterID = @MasterID
end