﻿--GetCashItem 4
Create procedure GetCashItem(@pcId int)
as
begin
select ExpenseFor, ExpenseAmt, username, Sitename,
billAttachment, Remarks from PettyCashTransaction where pTId=@pcId
end