﻿


CREATE procedure [dbo].[GetSupportData]  (@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select createdby, supportId as RId, [dbo].[fn_SupportType] (SupportTypeID) as SupportType, [dbo].[fn_username]  (createdby) as EmployeeName, Convert(varchar(12), date, 103) as Date, Time, status,
--case when Status = 1 then 'Pending' when status = 2 then 'Approved' else 'Declined' end as Status,
 case when ApproverComments is null then  Reason else Reason + '. HR Comments : ' + ApproverComments end as Reason
from tblsupport lR
where  Year(date) = Year(getdate()) and Month(date) = month(getdate())   order by Status

end
else
begin
select createdby, supportId as RId , [dbo].[fn_SupportType] (SupportTypeID) as SupportType, [dbo].[fn_username]  (createdby) as EmployeeName, Convert(varchar(12), date, 103) as Date, Time, status,
--case when Status = 1 then 'Pending' when status = 2 then 'Approved' else 'Declined' end as Status,
 case when ApproverComments is null then  Reason else LTRim(Rtrim(Reason)) + '. (HR Comments : '  + ApproverComments + ')'end as Reason
from tblsupport lR 
where Createdby = @userId and  Year(date) = Year(getdate()) and Month(date) = month(getdate())   order by Status
end

end