﻿--[GetInwardMaterialNew] 1, 'Procurement'
CREATE Procedure [dbo].[GetInwardMaterialNew](@uId int, @roleName varchar(150))
as
begin
if @roleName = 'admin'

begin
	with MaterialGrid
	(MaterialName, Unit, Quantity, conDate,siteN, createddate,InventoryId)
	as
	(
		select   SiteName as [MaterialName], Unit, Quantity,
		FORMAT(Createddate,'dd/MM/yyyy hh:mm') as conDate
		,MaterialName as [SiteName] , Createddate, ' ' as InventoryId
		from [dbo].[Mt_MaterialInward] --order by MaterialId desc
		union 
		select  sN.siteName as [MaterialName], Unit, Quantity,
		FORMAT(iMN.Createddate,'dd/MM/yyyy hh:mm') as conDate
		,MaterialName as [siteName], iMN.Createddate, InventoryId
		from [Mt_MaterialInwardNew] iMN
		join tblSiteNames sN on sN.sId = iMN.SiteName --order by MaterialId

	)
	select * from MaterialGrid order by createddate desc
end
else
	begin
	declare @projId varchar(200)
	select @projId =projId from tblUsers where userId=@uId;

	with MaterialGrid
	(MaterialName, Unit, Quantity, conDate,siteN, createddate,InventoryId)
	as
	(		
		select  SiteName as [MaterialName], Unit, Quantity, FORMAT(Createddate,'dd/MM/yyyy hh:mm') as conDate, MaterialName as [SiteName], 
		createddate ,' ' as InventoryId
		from [dbo].[Mt_MaterialInward] where SiteName in(select siteName from tblSiteNames where sId in (
		select item from [dbo].[fnSplitString](@projId,',')))
		union
		select sN.siteName as [MaterialName], Unit, Quantity, FORMAT(iMN.Createddate,'dd/MM/yyyy hh:mm') as conDate, MaterialName as [siteName],
		 iMN.createddate,InventoryId
		from [Mt_MaterialInwardNew] iMN
		join tblSiteNames sN on sN.sId = iMN.SiteName where iMN.SiteName in (select item from [dbo].[fnSplitString](@projId,','))
	)
	select * from MaterialGrid order by createddate desc
		
	end
end