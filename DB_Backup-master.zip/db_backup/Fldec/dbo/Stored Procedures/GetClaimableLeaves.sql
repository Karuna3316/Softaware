﻿
--GetClaimableLeaves 138
--select * from tblLeaveBalanceMaster where userid=15
--select * from tblRequestLeave where userid=15
--[GetClaimableLeavesATesting] 15
CREATE procedure [dbo].[GetClaimableLeaves](@userId int)
as
begin
--select * from tblRequestLeave
select
(select  isnull(sum(CasualLeave),0) from [dbo].[tblLeaveBalanceMaster] where userId=@userId and month(createddate) <= month(getdate()) and [year]=year(getdate())) -(

isnull((select  sum(case when leaveDaysType = 1 then 1
			when leaveDaysType = 3 then 0.5
			when leaveDaysType= 2 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=1 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1)),0) 
+ isnull((select  sum(case when leaveType = 1 then 1
			when leaveType = 3 then 0.5
			when leaveType= 2 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=1 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1)),0)) clClaimable,

(select  isnull(sum(SickLeave),0) from [dbo].[tblLeaveBalanceMaster] where userId=@userId and month(createddate) <= month(getdate()) and [year] = year(getdate())) - (
isnull(((select  sum(case when leaveDaysType = 1 then 1
			when leaveDaysType = 3 then 0.5
			when leaveDaysType= 2 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=2 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1))),0) 
+ isnull(((select  sum(case when leaveType = 1 then 1
			when leaveType = 3 then 0.5
			when leaveType= 2 then datediff(day,leaveStartedOn,leaveEndsOn)+1 end)
from tblRequestLeave where leaveCategory=2 and userId=@userId and year(leaveStartedOn)=year(getdate()) and (isApproved is null or isApproved =1))),0)) slClaimable
end