﻿create proc [dbo].[DeleteProductsMaster](@ProductsID int)
as
begin
delete from tblfdss_ProductsMaster where ProductsID = @ProductsID
end