﻿
--GetStatusticEmployee 1
CREATE procedure [dbo].[GetStatusticEmployee](@userId int)
as
begin

declare @Absentcount decimal(18,1), @Presentcount decimal(18,1), @Holidayscount int, @mon int, @Timepercentage int
set @mon = month(getdate())



set @Holidayscount = (select count(*) from tblAAttendance where userid = @userId and   month(checkindate) = month(getdate()) and checkin =1  and 
((DATEPART(hour, CheckInDate) >= 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 )) and ( DATEPART(hour, CheckInDate) <= 12 and   DATEPART(MINUTE, CheckInDate) >=1))

declare @NoofHolidays int
select @NoofHolidays= Count(*) from  tblDim where year(Date) = year(getdate()) and Month(Date)= Month(getdate())

declare @dName int
select @dName=case @mon 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end

;with CTE as

(
select Date from tblDim where DAY(Date)<= DAY(getdate()) and Month(Date)= Month(getdate())
union
select CheckInDate from tblAAttendance where UserID = @userId and CheckIn = 1 and Month(CheckInDate)= Month(getdate())
) 

 select @Absentcount = day(getdate()) - count(*) + (select  count(UserID) * 0.5 from tblAAttendance where year(checkindate)= year(getdate()) and month(checkindate)= month(getdate()) and day(checkindate) <> day(getdate()) and UserID= 1
and (CAST(checkindate as time) >= CAST('12:00' as time) or 
CAST(isnull(checkoutdate,'16:59') as time) <= CAST('16:59' as time)) and convert(varchar(12), checkindate, 103) not in (select convert(varchar(12), Date, 103) from dbo.tbldim where  month(date)= month(getdate())  and year(date)= year(getdate())))
 from CTE

 select @Presentcount = count(*) - (select  count(UserID) * 0.5 from tblAAttendance where year(checkindate)= year(getdate()) and month(checkindate)= month(getdate()) and day(checkindate) <> day(getdate()) and UserID= 1
and (CAST(checkindate as time) >= CAST('12:00' as time) or 
CAST(isnull(checkoutdate,'16:59') as time) <= CAST('16:59' as time)) and convert(varchar(12), checkindate, 103) not in (select convert(varchar(12), Date, 103) from dbo.tbldim where  month(date)= month(getdate())  and year(date)= year(getdate()))) from tblAAttendance where UserID = @userId and CheckIn = 1 and Month(CheckInDate)= Month(getdate())

 select @Timepercentage = (select [dbo].[fn_TimePercentageCalc]  (@userId))


 declare @NoOfRegularization int
Declare @NoofRegularizeApplied int
Declare @NoOfPermission int
Declare @NoOfPermissionApplied int
Declare @NoOfMissingCheckOut int
Declare @WorkedinHolidays int


set @NoOfRegularization = (select Count(*) 
from tblAAttendance A  where userid = @userid and year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and
((DATEPART(hour, CheckInDate) >= 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)
group by dbo.fn_username(A.userid), A.UserID )

set @NoofRegularizeApplied = (select Count(*) from tblReconciliationNew R where userid = @userid and year(CheckIn) = year(getdate()) and  month(CheckIn)=month(getdate()) and 
userid = @userid )

--set @NoOfMissingCheckOut = (select count(*) from tblAAttendance where  userid = @userid and CheckOut is null and year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and day(checkindate) <> day(getdate()) )
set @NoOfMissingCheckOut = (select count(*) from tblDim where year(date) = year(getdate()) and month(date) = month(getdate())) --(select count(*) from tblAAttendance where  userid = @userid and CheckOut is null and year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and day(checkindate) <> day(getdate()) )

set @NoOfPermission = (select [dbo].[fnPermissionCount](@userid))

set @NoOfPermissionApplied = (select [dbo].[fnPermissionAppliedCount](@userid))

set @WorkedinHolidays = (select count(*) from tblAAttendance where UserID = @userid and Convert(varchar(12), Checkindate, 103) in (select convert(varchar(12), date, 103) from tblDim where year(date) = year(getdate()) and month(date) = month(getdate()) ))



 if(@mon = 4)
  select @dName - @NoofHolidays as [Noofdays] , @Presentcount + 4 as [Present], @Absentcount as [Absent], @Holidayscount as Holidays, @Timepercentage as TimePercentage,ISNULL( @NoOfRegularization ,0)as NoOfRegularization,  isnull(@NoofRegularizeApplied,0) as NoofRegularizeApplied, isnull( @NoOfPermission,0) as NoOfPermission, isnull(@NoOfPermissionApplied,0) as NoOfPermissionApplied,
isnull(@NoOfMissingCheckOut,0) as NoOfMissingCheckOut, Isnull(@WorkedinHolidays,0) as WorkedinHolidays

  else
    select @dName- @NoofHolidays as [Noofdays] , @Presentcount  as [Present], @Absentcount as [Absent], @Holidayscount as Holidays, @Timepercentage as TimePercentage,ISNULL( @NoOfRegularization ,0)as NoOfRegularization,  isnull(@NoofRegularizeApplied,0) as NoofRegularizeApplied, isnull( @NoOfPermission,0) as NoOfPermission, isnull(@NoOfPermissionApplied,0) as NoOfPermissionApplied,
isnull(@NoOfMissingCheckOut,0) as NoOfMissingCheckOut, Isnull(@WorkedinHolidays,0) as WorkedinHolidays



end



--select * from tblAAttendance where userid = 1

--update tblAAttendance set CheckOutDate = '2022-12-05 09:24:36.130', CheckInDate = '2022-12-05 19:30:36.130' where AttendanceID = 9