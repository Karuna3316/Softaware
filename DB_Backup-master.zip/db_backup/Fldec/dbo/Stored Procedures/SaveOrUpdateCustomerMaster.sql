﻿CREATE procedure [dbo].[SaveOrUpdateCustomerMaster] (  @CID int , @IndusTypeId int, @CompanyName nvarchar(500),@CPName nvarchar(300),@GstNo nvarchar(300),@CPNumber nvarchar(25),@Address nvarchar(MAX), @userid int)
as
begin

if(@CID > 0)
begin
update  tblfdss_CustomerMaster set IndusTypeId =  @IndusTypeId, CompanyName = @CompanyName, CPName = @CPName, GstNo = @GstNo, CPNumber = @CPNumber, Address = @Address ,UpdatedDate=getdate(), Updatedby = @userid where CID = @CID
select 2
end
else
begin
if not exists (select CID,IndusTypeId,CompanyName,CPName,GstNo,CPNumber,Address from tblfdss_CustomerMaster with (nolock) where CompanyName = @CompanyName )
begin
	insert into tblfdss_CustomerMaster (IndusTypeId,CompanyName,CPName,GstNo,CPNumber,Address,CreatedBy, CreatedDate)
	select  @IndusTypeId,@CompanyName, @CPName, @GstNo, @CPNumber, @Address, @userid, getdate()
	Select 1
end

else
begin
Select 3

end

end

end