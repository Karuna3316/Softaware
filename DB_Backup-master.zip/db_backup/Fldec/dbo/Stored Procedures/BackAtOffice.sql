﻿create procedure BackAtOffice(@userId int)
as
begin
declare @attendaceId int, @bId int
select @attendaceId = attendanceId from tblAAttendance where UserID = @userId and convert(varchar,CheckInDate,103)=convert(varchar,getdate(),103)
select top 1 @bId = wBId from tblWorkBreaksTakenInADay where attendanceid=@attendaceId order by wBId desc

update tblWorkBreaksTakenInADay set backAtOffice=GETDATE() where wBId = @bId
end