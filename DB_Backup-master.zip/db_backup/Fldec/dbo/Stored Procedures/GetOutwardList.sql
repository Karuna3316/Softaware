﻿CREATE procedure [dbo].[GetOutwardList]
AS
begin  

Select OutwardId, dbo.fn_CustomerName(CustomerId) as CustomerName, dbo.fn_OutwardType(OutwardTypeId) as OutwardType , case when UpdatedBy is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(UpdatedBy) end as CreatedBy,case when UpdatedBy is null then  createddate  else  UpdatedDate  end as createddate from tblfdss_Outward order by createddate desc

end