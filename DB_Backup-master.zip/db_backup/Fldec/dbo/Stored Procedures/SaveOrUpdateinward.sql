﻿CREATE procedure [dbo].[SaveOrUpdateinward] (@InwardId int,  @SupplierId int,@PONumberId nvarchar(max),@ProductsId nvarchar(max),@Qty nvarchar(max),@ReceievedQty nvarchar(max) ,@userId int)
as
begin

if(@InwardId > 0)
begin
update tblfdss_Inward set SupplierId = @SupplierId, PONumberId= @PONumberId, UpdatedDate=GETDATE(),Updatedby=@userId where InwardId =@InwardId

select 2

IF @ProductsId IS NOT NULL AND LEN(@ProductsId) > 0
BEGIN TRY
    BEGIN TRAN 

DELETE FROM tblfdss_InwardProducts WITH (TABLOCK) WHERE InwardId= @InwardId

INSERT INTO tblfdss_InwardProducts WITH (TABLOCK) (InwardId,CreatedDate,CreatedBy, Qty,ReceievedQty,ProductsId)
SELECT @InwardId, GETDATE(),@userId,s.Item,a.Item,t.Item 
FROM dbo.fnSplitString(@Qty, ',') s
JOIN dbo.fnSplitString(@ReceievedQty, ',') a ON s.ID = a.ID
JOIN dbo.fnSplitString(@ProductsId, ',') t ON s.ID = t.ID;
COMMIT TRAN 
END TRY
BEGIN CATCH
    ROLLBACK TRAN 
END CATCH

end
else

begin
if not exists (select InwardId from  tblfdss_Inward with (nolock) where InwardId = @InwardId )
begin
	insert into tblfdss_Inward (SupplierId,PONumberId,Createdby,CreatedDate)
	select @SupplierId,@PONumberId,@userId,getdate()
	Select 1

	DECLARE @ScopeID int
   SET @ScopeID = SCOPE_IDENTITY()

   if @ProductsId is not null and len(@ProductsId)>0
begin
	insert into tblfdss_InwardProducts (InwardId,ProductsId,Qty,ReceievedQty,CreatedDate,CreatedBy)	
	select @ScopeID,
	t.Item AS ProductsId,
	s.Item AS  Qty,
    a.Item AS ReceievedQty,
   	GETDATE(),
	@userId
	
FROM dbo.fnSplitString(@Qty, ',') s
JOIN dbo.fnSplitString(@ReceievedQty, ',') a ON s.ID = a.ID
JOIN dbo.fnSplitString(@ProductsId, ',') t ON s.ID = t.ID;
	end
	end
	else
	Select 3

	end

end