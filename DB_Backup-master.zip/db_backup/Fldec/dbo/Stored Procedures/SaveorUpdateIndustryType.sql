﻿
CREATE procedure [dbo].[SaveorUpdateIndustryType] (@MasterID int, @Description nvarchar(500),@userid int)
as
begin

if(@MasterID > 0)
begin
update tblfdss_Master set  Description = @Description,UpdatedDate = getdate(), updatedBy = @userid  where MasterID = @MasterID
select 2
end
else
begin

if not exists (select MasterID from tblfdss_Master with (nolock) where MasterID=@MasterID)
begin
	insert into tblfdss_Master(Description,MasterType,createdBy,createddate)
	select @Description,'Industry',@userid, Getdate()
	Select 1
end
else
begin
Select 3
	end

end

end