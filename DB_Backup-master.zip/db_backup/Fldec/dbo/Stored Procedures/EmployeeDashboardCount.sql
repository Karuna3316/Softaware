﻿
CREATE proc [dbo].[EmployeeDashboardCount] ---1
(@userid int)
as

begin

declare @NoOfRegularization int
Declare @NoofRegularizeApplied int
Declare @NoOfPermission int
Declare @NoOfPermissionApplied int
Declare @NoOfMissingCheckOut int
Declare @WorkedinHolidays int


set @NoOfRegularization = (select Count(*) 
from tblAAttendance A  where userid = @userid and year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and
((DATEPART(hour, CheckInDate) >= 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)
group by dbo.fn_username(A.userid), A.UserID )

set @NoofRegularizeApplied = (select Count(*) from tblReconciliationNew R where userid = @userid and year(CheckIn) = year(getdate()) and  month(CheckIn)=month(getdate()) and 
userid = @userid )

set @NoOfMissingCheckOut = (select count(*) from tblDim where year(date) = year(getdate()) and month(date) = month(getdate())) --(select count(*) from tblAAttendance where  userid = @userid and CheckOut is null and year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and day(checkindate) <> day(getdate()) )

set @NoOfPermission = (select [dbo].[fnPermissionCount](@userid))

set @NoOfPermissionApplied = (select [dbo].[fnPermissionAppliedCount](@userid))

set @WorkedinHolidays = (select count(*) from tblAAttendance where UserID = @userid and Convert(varchar(12), Checkindate, 103) in (select convert(varchar(12), date, 103) from tblDim where year(date) = year(getdate()) and month(date) = month(getdate()) ))

select ISNULL( @NoOfRegularization ,0)as NoOfRegularization,  isnull(@NoofRegularizeApplied,0) as NoofRegularizeApplied, isnull( @NoOfPermission,0) as NoOfPermission, isnull(@NoOfPermissionApplied,0) as NoOfPermissionApplied,
isnull(@NoOfMissingCheckOut,0) as NoOfMissingCheckOut, Isnull(@WorkedinHolidays,0) as WorkedinHolidays

end