﻿CREATE procedure [dbo].[GetdrpActionNames]
as
begin

select ActionId, ActionName from tblAction

end