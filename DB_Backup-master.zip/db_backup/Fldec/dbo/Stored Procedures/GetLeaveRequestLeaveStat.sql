﻿

create procedure [dbo].[GetLeaveRequestLeaveStat]  (@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
Declare @Total int, @Approved int, @Declined int, @Pending int

set @Total = 
(select count(*)
from [tblRequestLeave] lR 
where lR.reportingTo = @userId  and leaveType not in (4,5)
and month(leaveStartedOn) in ( month(getdate()))  and year(leaveStartedOn) = year(getdate()) )

set @Approved = 
(select count(*)
from [tblRequestLeave] lR 
where lR.reportingTo = @userId  and leaveType not in (4,5) and isApproved = 1
and month(leaveStartedOn) in ( month(getdate()))  and year(leaveStartedOn) = year(getdate()) )


set @Declined = 
(select count(*)
from [tblRequestLeave] lR 
where lR.reportingTo = @userId  and leaveType not in (4,5) and isApproved = 2
and month(leaveStartedOn) in ( month(getdate()))  and year(leaveStartedOn) = year(getdate()) )

set @Pending = 
(select count(*)
from [tblRequestLeave] lR 
where lR.reportingTo = @userId  and leaveType not in (4,5) and isApproved is null
and month(leaveStartedOn) in ( month(getdate()))  and year(leaveStartedOn) = year(getdate()) )

select isnull(@Total, 0) as Total,  isnull(@Approved, 0) as Approved, isnull(@Declined, 0) as Declined, isnull(@Pending, 0) as Pending


end


end