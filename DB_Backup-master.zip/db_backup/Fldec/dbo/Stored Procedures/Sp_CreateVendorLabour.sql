﻿CREATE proc [dbo].[Sp_CreateVendorLabour]
@Vendorid int, @Siteid int
as


begin
	DECLARE @Counter INT 
SET @Counter=1

Declare @ResultVendorlabourlist nvarchar(250)
set @ResultVendorlabourlist = ''
WHILE ( @Counter <= 20)
BEGIN


   insert into tblvendorlabour(vendorid, labourname, createddate, siteid) values(@Vendorid, 'Name' + CONVERT(varchar(10),@Counter), getdate(),@Siteid)

   /*Step 1
   select top 1 VendorNo from tblvendor order by createdate desc

   Step 2
   insert  into tblVendor(VendorName, JobNature, CompanyName, VendorNo)
values('Jaynarayan Singh','Housekeeping','Jaynarayan Singh','151')

Step 3
select top 1 vendorid from tblvendor order by createdate desc

[dbo].[Sp_CreateVendorLabour] @Vendorid, @Siteid
*/

     SET @Counter  = @Counter  + 1
   
	
END

----select distinct(vendorid) from  tblvendorlabour 
--select * from tblVendor where vendorno = '91'
--Select * from tblVendorlabour where vendorid = 44
---select * from tblVendor where vendorname like '%Thir%'
--select distinct userid from tbllAttendance where  vendorid = 3 and SiteId = 25 and convert(varchar(12),checkindate,103) = convert(varchar(12),getdate(),103) )



--update tblVendor set CompanyName = 'Karunakaran' where VendorNo = '98'



--select * from tblSiteNames where active = 1
end

--select * from tblvendor where vendorname like '%sak%'

--update tblvendor set JobNature = 'Tiles' where vendorid = 120

--select * from tblVendor where vendorname like '%sak%'

----select * from tblVendorlabour  order by  where vendorid = 30

--select * from tblVendor order by VendorID desc

--delete from tblvendor where vendorid = 161

--select  * from tblVendorlabour order by Createddate desc

--select * from tblLAttendance order by CheckInDate desc

--select * from tblusers where UserName like '%Raj%'

--select * from tblVendorlabour where siteid = 19 and vendorid = 1 order by Createddate desc

--select distinct vendorid , SiteId from tblLAttendance where  siteid = 19 order by CheckInDate desc

--select VendorNo, VendorName from tblVendor where vendorid in (select distinct vendorid  from tblLAttendance where  siteid = 19)

--select * from tblvendor where VendorName like '%kupp%'

-- select * from tblvendor order by createdate desc



--select * from tblVendorlabour where siteid = 33 and vendorid = 138

--select * from tblSiteNames where siteName like '%BW%'