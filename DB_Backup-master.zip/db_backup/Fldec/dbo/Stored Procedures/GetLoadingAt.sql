﻿CREATE procedure GetLoadingAt
as
begin
select SupplierId as cId, SupplierName as cVal from [dbo].[VECtblSupplier]
union
select '0' as cId,'select' as cVal
end