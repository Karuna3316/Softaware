﻿
create Procedure [dbo].[GetReports]

as

begin
select 31 as [Noofworkingday], 15 as [Noofdayspresent], 1 as [NoofdaysAbsent], 1 as [LeaveBalance]
end