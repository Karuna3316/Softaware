﻿
--GetTotalPaid 2022,8,6
create procedure GetTotalPaid(@year int,@mon int,@userId int)
as
begin
declare @dName int

select @dName=case @mon 
when 12 then 31 when 11 then 30 when 10 then 31 when 9 then 30 when 8 then 31 when 7 then 31 
when 6 then 30 when 5 then 31 when 4 then 30 when 3 then 31 when 2 then 28 when 1 then 31 
end

if (year(getdate()) = @year and month(getdate()) = @mon)
set @dName=day(getdate())

select 
userName,
@dName - (([HalfDay] + (@dName-([DaysWorked]-workedOnHolidays)- NoOfHolidays) + [Regularize LOP]) - (clAvail + slAvail)) as [DaysWorked]
from(
SELECT 
(select username from tblusers where userid= @userId) as UserName,  

(select count(UserID) from tblAAttendance where year(checkindate)=@year and month(checkindate)=@mon and UserID=@userId  
and CAST(checkindate as time) <= CAST('12:00' as time) and   CAST(checkoutdate as time) >= CAST('17:00' as time)) as   [DaysWorked],

(select count(UserID) * 0.5 from tblAAttendance where year(checkindate)=@year and month(checkindate)=@mon and UserID=@userId 
and (CAST(checkindate as time) >= CAST('12:00' as time) or   CAST(checkoutdate as time) <= CAST('17:00' as time)))  as [HalfDay], 

(select count(UserID) from tblAAttendance where userid=@userId and month(checkindate)=@mon and year(checkindate)=@year
and day(checkindate) in (select day(Date) from tblDim where month([date])=@mon and year([Date]) =@year)) as workedOnHolidays,

clAvail,slAvail ,    
dbo.[fnCalcLOPFrLateChkIn](@userId,@mon) as [Regularize LOP],    
[dbo].[fn_Noofholiday](@userId,@mon,@year)  as [NoOfHolidays] 

from( select        
isnull(sum(case when leaveDaysType = 1 and leaveCategory=2 and isApproved=1 then 1   
when leaveDaysType = 3 and leaveCategory=2  then 0.5
when leaveDaysType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)     
else 0 end),0) +   isnull(sum(case when leaveType = 1 and leaveCategory=2 and isApproved=1 then 1 
when leaveType = 3 and leaveCategory=2  then 0.5
when leaveType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)   
else 0 end),0) slAvail,
isnull(sum(case when leaveDaysType = 1 and leaveCategory=1 then 1    
when leaveDaysType = 3 and leaveCategory=1 then 0.5
 when leaveDaysType= 2 and leaveCategory=1 
then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)      else 0 end),0) +   
isnull(sum(case when leaveType = 1 and leaveCategory=1 then 1    
when leaveType = 3 and leaveCategory=1  then 0.5 
when leaveType= 2 and leaveCategory=1 
then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)      else 0 end),0) clAvail        
from  tblRequestLeave where userId = @userId and isApproved=1 and   year(leaveStartedOn)=@year and month(leaveStartedOn) = @mon ) A1 ) A2 
end