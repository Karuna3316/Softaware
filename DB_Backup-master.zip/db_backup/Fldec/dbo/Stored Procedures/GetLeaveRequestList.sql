﻿CREATE Procedure [dbo].[GetLeaveRequestList](@userid int)
AS
BEGIN
select 3 as [Noofopening], 3 as [Availed], 0 as [Balance], 2 as [Opening], 1 as [Availedd], 5 as [Balancee], 5 as [TotalLeave], 4 as [TotalAvailed], 3 as [Lossofpay], 2 as [Pending], 3 as [Approved], 1 as [Rejected]
END