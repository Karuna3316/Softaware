﻿CREATE procedure [dbo].[GetMenuMaster]
AS
begin  
select menuId,  CASE WHEN isMainMenu = 1 THEN SUBSTRING(menu, CHARINDEX('</i>', menu) + 5, LEN(menu) - CHARINDEX('</i>', menu) - 4) END AS MainMenu,
       url,
       CASE WHEN isMainMenu = 0 THEN SUBSTRING(menu, CHARINDEX('<span class="pcoded-mtext">', menu) + LEN('<span class="pcoded-mtext">'), CHARINDEX('</span> </a> </li>', menu) - CHARINDEX('<span class="pcoded-mtext">', menu) - LEN('<span class="pcoded-mtext">')) END AS SubMenu,
       parentId,
       CONVERT(varchar(12), createddate, 103) AS createddate,
       dbo.fn_username(Createdby) AS Createdby
FROM tblmenus
ORDER BY parentId


  END