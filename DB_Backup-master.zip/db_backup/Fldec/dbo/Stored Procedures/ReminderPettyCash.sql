﻿CREATE proc [dbo].[ReminderPettyCash]
as
begin
DECLARE @Result AS NVARCHAR(MAX)   
DECLARE @colsIS AS NVARCHAR(MAX)         
  
  Set @colsIS = '*_The following petty cash requests are pendings_*' 
     
 select @colsIS = @colsIS + STUFF((SELECT '  ( *Request Id* - *' + Convert(varchar(12), PettyCashId) + '* - _' +  (rtrim(ltrim(REPLACE(REPLACE(Description, CHAR(13), ''), CHAR(10), '')))) + '_ - Rs. ' + Convert(varchar(12),DebitAmount  ) + ' )'         
 from [tblPettyCashNew]  where  Status = 1
       
 FOR XML PATH('')),1,1,'')

 if @colsIS is not null
 set @Result = @colsIS

 if  @Result is not null
 begin
 insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('919962222745',@colsIS,1,getdate())
  insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('917010633708',@colsIS,1,getdate())
  end

 end