﻿
--GetCurDayAccessTimings 111
CREATE procedure [dbo].[GetCurDayAccessTimings](@userId int)
as
begin
declare @chkIn bit, @chkOut bit, @dateTookBreakAt datetime, @dateBackAtOffice datetime,@attendaceId int

select @chkIn = checkin, @chkOut = checkout, @attendaceId = AttendanceID from [dbo].[tblAAttendance] 
where userid=@userId and convert(varchar,CheckInDate,103)=convert(varchar,getdate(),103)

select top 1 @dateTookBreakAt = tookBreakAt, @dateBackAtOffice = backAtOffice from 
tblWorkBreaksTakenInADay where attendanceid=@attendaceId order by wBId desc

select @chkIn as chkIn, @chkOut as chkOut,@dateTookBreakAt as tookBreakAt,@dateBackAtOffice as backAt, @attendaceId as att

end


select * from tblUsers where UserName like '%bar%'