﻿CREATE proc [dbo].[GetLeavebenefitProjectNew]
as 
begin
(SELECT tblUsers.UserName as bVal,tblLeaveBalanceMaster.Year as bId,tblLeaveBalanceMaster.CreatedDate
FROM tblLeaveBalanceMaster
LEFT JOIN tblUsers
ON tblLeaveBalanceMaster.UserId=tblUsers.userId)
 
select '0' as bId,'select' as bVal
end