﻿create procedure GetSiteNames
as
begin
select shortNameFrSite as [Site], sId  from tblSiteNames
end