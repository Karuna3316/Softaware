﻿
--Casual leave, Opening, 	Availed, 	Balance
--[GetDashboardDataFrLeave] 15
create procedure [dbo].[GetDashboardDataFrLeavebackup1308](@userId int)
as
begin
declare @monthVal int
set @monthVal=month(getdate())

declare @clAvailed decimal(10,1),@clAlloted int, @clBalance decimal(10,1)
select @clAlloted=sum(CasualLeave) from [dbo].[tblLeaveBalanceMaster] where UserId=@userId

select @clAlloted = @clAlloted -isnull((select sum(case when leaveType = 1 then 1
			when leaveType = 3 then 0.5
			when leaveType= 2 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where  leaveCategory=1 and userId=@userId and year(leaveStartedOn)=year(getdate())
and month(leaveStartedOn) = @monthVal 
 and isApproved=1),0)

select @clAvailed = sum(case when leaveType = 1 then 1
			when leaveType = 3 then 0.5
			when leaveType= 2 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where leaveCategory=1 and userId=@userId and year(leaveStartedOn)=year(getdate()) 
and month(leaveStartedOn) = @monthVal 
and isApproved=1
select @clBalance = isnull(@clAlloted,0) - isnull(@clAvailed,0)

declare @slAvailed decimal(10,1),@slAlloted decimal(10,1), @slBalance decimal(10,1)
select @slAlloted=sum(SickLeave) from [dbo].[tblLeaveBalanceMaster] where UserId=@userId

select @slAlloted= @slAlloted -isnull(( select sum(case when leaveType = 1 then 1
			when leaveType = 3 then 0.5
			when leaveType= 2 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where leaveCategory=2 and userId=@userId  and year(leaveStartedOn)=year(getdate()) and isApproved=1),0)

select @slAvailed = sum(case when leaveType = 1 then 1
			when leaveType = 3 then 0.5
			when leaveType= 2 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where leaveCategory=2 and userId=@userId  and year(leaveStartedOn)=year(getdate()) 
and month(leaveStartedOn) = @monthVal 
and isApproved=1
select @slBalance = isnull(@slAlloted,0) - isnull(@slAvailed,0)

declare @lPending decimal(10,1), @lApproved decimal(10,1), @lRejected decimal(10,1)
select @lPending = count(reqLId) from tblRequestLeave where userId=@userId and year(leaveStartedOn)=year(getdate()) and month(leaveStartedOn) = @monthVal and isApproved is null
select @lApproved=count(reqLId) from tblRequestLeave where userId=@userId and year(leaveStartedOn)=year(getdate()) and month(leaveStartedOn) = @monthVal and isApproved =1
select @lRejected=count(reqLId) from tblRequestLeave where userId=@userId and year(leaveStartedOn)=year(getdate()) and month(leaveStartedOn) = @monthVal and isApproved =2

declare @leaveTakenTillDate decimal(10,1)
declare @lossOfPay  decimal(10,1)

select @leaveTakenTillDate = day(getdate()) -
(
(select count(DimId) from tblDim where year(date)=year(getdate()) and month(date) = month(getdate()) and day(date)<=day(getdate()))+
(select count(UserID) from tblAAttendance where year(checkindate)=year(getdate()) and month(checkindate)=@monthVal and UserID=@userId
and day(checkindate) not in(select day(date) from tblDim where year(date)=year(getdate()) and month(date) = month(getdate()) and day(date)<=day(getdate()) )
and CAST(checkindate as time) <= CAST('12:30' as time) and 
CAST( case when cast (getdate() as date) = cast(checkindate as date) then isnull(checkoutdate,'17:30')
else checkoutdate  end as time) >= CAST('17:30' as time)) +
(select count(userId)*0.5 from tblAAttendance where year(checkindate)=year(getdate()) 
and month(checkindate)=month(getdate()) and UserID =@userId
and (CAST(checkindate as time) >= CAST('12:30' as time) or 
CAST(checkoutdate as time) <= CAST('17:30' as time)))
)

select @lossOfPay = @leaveTakenTillDate - (isnull(@clAvailed,0)+ isnull(@slAvailed,0))

 select convert(decimal(18,1),@clAlloted) as clOpening, isnull(@clAvailed,0) as clAvailed, @clBalance as clBalance,
		convert(decimal(18,1),@slAlloted) as slOpening, isnull(@slAvailed,0) as slAvailed , @slBalance as slBalance,
		@lPending as leaveReqPending , @lApproved as leaveReqApproved , @lRejected as leaveReqRejected,
		convert(decimal(18,1),@leaveTakenTillDate) as leaveTakenTillDate,convert(decimal(18,1),@lossOfPay) as lossOfPay, convert(decimal(18,1),(isnull(@clAvailed,0)+isnull(@slAvailed,0))) as totSLCLAvailed


end
--select * from tblRequestLeave where reqLId=7
--select * from tblRequestLeave where userId=20