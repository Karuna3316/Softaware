﻿CREATE proc [dbo].[GetCustomerMasterforedit](@CID int)
as
begin

Select CID, IndusTypeId,CompanyName,CPName,GstNo,CPNumber,Address from tblfdss_CustomerMaster where CID = @CID 

end