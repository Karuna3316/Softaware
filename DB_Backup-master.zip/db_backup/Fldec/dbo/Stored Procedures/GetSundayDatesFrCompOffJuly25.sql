﻿create procedure [dbo].[GetSundayDatesFrCompOffJuly25](@userId int)
as
begin
select [Date] as sDate from tblDim where convert(date,[Date]) 
in (select convert(date,CheckInDate) from tblAAttendance where userId = @userId)
and convert(date,[Date]) not in (select convert(date,CompOffTakenFor) from tblrequestleave where userId = @userId and CompOffTakenFor is not null)

/*declare @d datetime
select @d = convert(varchar,year(getdate())) +'0201'  --'20090101'  if you want 2009 etc etc

select dateadd(dd,number,@d) as sDate from master..spt_values
where type = 'p'
and year(dateadd(dd,number,@d))=year(@d)
and month(dateadd(dd,number,@d)) <= month(getdate())
and DATEPART(dw,dateadd(dd,number,@d)) = 1
and dateadd(dd,number,@d) not in (
select leaveStartedOn from tblrequestleave where leaveStartedOn<>'1900-01-01 00:00:00.000' and userId = @userId)*/
end