﻿--[GetEmployeeList] 1
CREATE procedure [dbo].[GetHelpDescription]
as
begin

select HId,Description from tblhelpmenus

end