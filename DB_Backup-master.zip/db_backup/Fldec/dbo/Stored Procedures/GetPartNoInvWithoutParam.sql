﻿CREATE proc [dbo].[GetPartNoInvWithoutParam]  
as
begin

select PartId as cId, PartNo as cVal from InvtblPartNo

end