﻿CREATE procedure CheckOut(@userId int)
as
begin
declare @attendaceId int
select @attendaceId = attendanceId from tblAAttendance where UserID = @userId and convert(varchar,CheckInDate,103)=convert(varchar,getdate(),103)
update [tblAAttendance] set CheckOut=1,CheckOutDate=getdate() where AttendanceID = @attendaceId

end