﻿create proc [dbo].[GetProductMasterForEdit](@ProductsID int) 
as
begin

Select ProductsID,MakeId,SupplierId,ProductsName,Size,Hsn,LPrice,MinQty from tblfdss_ProductsMaster where ProductsID = @ProductsID
end