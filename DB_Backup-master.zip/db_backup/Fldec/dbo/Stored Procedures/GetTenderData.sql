﻿CREATE Procedure GetTenderData
as
begin
select TenderName, ClientName, 
convert(varchar,ReceivedDate,103) as rDate, 
convert(varchar,SubmissionDate,103) as sDate, 
convert(varchar,RevSubmissionDate,103) as rSDate ,RevVersion, 
convert(varchar,AwardedDate,103) as aDate,
 (case when StatusId = 1 then 'Pending' when statusid = 2 then 'Submitted' else 'Awarded' end) as Status from [dbo].[tblTenderSubmission]
end