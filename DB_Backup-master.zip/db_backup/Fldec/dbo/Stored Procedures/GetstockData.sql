﻿CREATE proc [dbo].[GetstockData] 
as  
begin  
select ProjectTypeId, BoxTypeId, ProjectId, InwardRegisterId, PartNo, Desciption, Quantity, dbo.fn_ProjectType(ProjectTypeId) as ProjectTypeName, dbo.fn_BoxType(BoxTypeId) as BoxTypeName,dbo.fn_Project(ProjectId) as ProjectName from InvInwardRegister  
SELECT a.InventoryId, a.Quantity-b.Qty as Difference FROM InvInwardRegister a
INNER JOIN InvOutwardRegister b
ON a.Quantity=b.Qty
end  



--SELECT  (SELECT SUM(Quantity) FROM InvInwardRegister) - (SELECT SUM(Qty) FROM InvOutwardRegister) as MyValues     
 

--end  