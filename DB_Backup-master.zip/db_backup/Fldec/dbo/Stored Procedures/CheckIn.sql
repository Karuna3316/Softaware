﻿CREATE procedure CheckIn(@userId int)
as
begin
if not exists(select attendanceId from tblAAttendance where UserID = @userId and convert(varchar,CheckInDate,103)=convert(varchar,getdate(),103))
begin
insert into [tblAAttendance](UserID,CheckIn,CheckInDate)
select @userId,1,getdate()
end
end