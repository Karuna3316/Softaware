﻿CREATE procedure [dbo].[GetMasterList]
as
begin
select   TeamID  ,Team  from tblTeam  

union all
select DesignationID ,Designation from tblDesignation 

union all 
(select ProbationStatusID , ProbationStatus from tblProbationStatus)

end


select * from tblDesignation
select * from tblProbationStatus order by ProbationStatusID