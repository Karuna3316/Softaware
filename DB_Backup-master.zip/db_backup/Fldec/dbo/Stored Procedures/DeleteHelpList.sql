﻿CREATE proc [dbo].[DeleteHelpList]
(@HelpId int)
as
begin
delete from tblhelp where HelpId = @HelpId
end