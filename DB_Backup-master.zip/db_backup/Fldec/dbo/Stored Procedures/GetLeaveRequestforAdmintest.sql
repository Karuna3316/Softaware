﻿
create procedure [dbo].[GetLeaveRequestforAdmintest]   (@stDate datetime,@endDate datetime, @userid int)
as
begin

select userId, 
(select username from tblusers where userId=lR.userId) as userName,
leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,leaveDaysType 
from [tblRequestLeave] lR 

 where 	 convert(varchar(12),leaveStartedOn,101) >= convert(varchar(12),@stDate,101)
	and convert(varchar(12),leaveStartedOn,101) <= convert(varchar(12),@endDate,101)
order by isApproved

--end


end