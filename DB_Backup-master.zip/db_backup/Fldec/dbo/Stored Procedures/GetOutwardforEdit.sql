﻿CREATE procedure [dbo].[GetOutwardforEdit] (@OutwardId int)
AS
begin  
SELECT
    o.OutwardId,
    o.CustomerId,
    o.OutwardTypeId,
    ProductsId = STUFF((SELECT ',' + op.ProductsId FROM tblfdss_OutwardProducts op WHERE op.OutwardId = @OutwardId FOR XML PATH('')), 1, 1, ''),
    OutwardedQty = STUFF((SELECT ',' + op.OutwardedQty FROM tblfdss_OutwardProducts op WHERE op.OutwardId = @OutwardId FOR XML PATH('')), 1, 1, ''),
    Qty = (
        SELECT STUFF((SELECT ',' + REPLACE(CONVERT(VARCHAR(25), SUM(CAST(ip.ReceievedQty AS DECIMAL(18, 2)))), '.00', ',')
        FROM tblfdss_InwardProducts ip 
        WHERE ip.ProductsId = op.ProductsId 
        FOR XML PATH('')), 1, 1, '')
        FROM tblfdss_OutwardProducts op
        WHERE op.OutwardId = o.OutwardId
        FOR XML PATH(''), TYPE
    ).value('.', 'NVARCHAR(MAX)')
FROM tblfdss_Outward o
WHERE o.OutwardId = @OutwardId




END



--[dbo].[GetOutwardforEdit] 9

-- select stuff((select ',' + convert(varchar(25), sum(cast(ip.ReceievedQty AS DECIMAL(18, 2)))) from tblfdss_InwardProducts ip where ip.ProductsId = 9 for XML PATH('')), 1, 1, '')
-- select sum(cast(ip.ReceievedQty AS DECIMAL(18, 2))) from tblfdss_InwardProducts ip where ip.ProductsId = 9