﻿CREATE proc [dbo].[GetAttID](@AttendanceID int)
as
begin

select AttendanceID, UserID,dbo.fn_username(UserId) as UserName,CheckInDate,CheckOutDate from tblAAttendance where AttendanceID=@AttendanceID

end