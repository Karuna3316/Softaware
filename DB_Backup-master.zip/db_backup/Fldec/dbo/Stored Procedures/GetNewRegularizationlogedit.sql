﻿CREATE procedure [dbo].[GetNewRegularizationlogedit] ( @RId int)
as
begin


select userid, 

(select username from tblusers where userid=lR.userId) as userName,Convert(varchar(12), CheckIn,103) as CheckIn, CheckIn as Date,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userid = lR.reportingTo) as reportingUser 
from [tblReconciliationNew] lR where  RId = @RId 
	order by [Date]


	end