﻿

CREATE PROCEDURE [dbo].[SaveOrUpdateMenuMaster] (@menuId INT,@menu NVARCHAR(200),@userid int,@url NVARCHAR(2000),@dpid NVARCHAR(200),@FileName nvarchar(max)=null)
AS
BEGIN
    IF (@menuId > 0)
    BEGIN
	 IF (@url = '' and @menu = '')
            begin
        -- Update existing menu entry
        UPDATE tblmenus
        SET
            menu = '<i class="' + @FileName + '"></i>' + @dpid,
			parentId=@menuId,
            url = '#',
			isMainMenu =1,
			active = 1,
            createdBy = @userid,
            createddate = GETDATE()
			
        WHERE menuId = @menuId;
		end
		ELSE IF (@url != '' and @menu != '')
            begin
        -- Update existing menu entry
        UPDATE tblmenus
        SET
            menu = '<span class="pcoded-submenu"><i class="' + @FileName + '"></i></span>  <span class="pcoded-mtext">' + @menu +'</span> </a> </li>',
			parentId=@dpid,
            url = @url,
			active = 1,
            createdBy = @userid,
			isMainMenu = 0,
            createddate = GETDATE()
        WHERE menuId = @menuId;
		end
		select 2
    END
    ELSE
    BEGIN
        IF NOT EXISTS (SELECT menuId FROM tblmenus WITH (NOLOCK) WHERE menuId = @menuId)
        BEGIN
            -- Insert new menu entry
            IF (@url = '' and @menu = '')
            BEGIN
                INSERT INTO tblmenus (menu, url, parentId, isMainMenu, active, createddate, Createdby)
                SELECT '<i class="' + @FileName + '"></i>' + @dpid , '#', (SELECT TOP 1 menuId FROM tblmenus ORDER BY menuId DESC) + 1, 1, 1, GETDATE(), @userid;
                SELECT 1;
            END
            ELSE if (@url != '' and @menu != '')
            BEGIN
                INSERT INTO tblmenus (menu, url, parentId, isMainMenu, active, createddate, Createdby)
                SELECT '<span class="pcoded-submenu"><i class="' + @FileName + '"></i></span>  <span class="pcoded-mtext">' + @menu +'</span> </a> </li>', @url, @dpid, 0, 1, GETDATE(), @userid;
                SELECT 1;
            END
        END
        ELSE
        BEGIN
            SELECT 3;
        END
    END
END