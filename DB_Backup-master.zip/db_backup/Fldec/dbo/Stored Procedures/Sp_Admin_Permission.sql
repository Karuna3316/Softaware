﻿CREATE proc [dbo].[Sp_Admin_Permission]

as

begin

;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(Checkindate) = year(checkindate) and month(checkindate) = month(getdate()) and convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where year(date) = year(getdate()) and month(date) = month(getdate())) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) 
union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as CheckInDate
from tblAAttendance where year(Checkindate) = year(checkindate) and month(checkindate) = month(getdate()) and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where year(date) = year(getdate()) and month(date) = month(getdate())) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1)
)
select Top 3 dbo.fn_username(userid) as [EmployeeName] , count(*) as [Count]  from cte   group by userid order by count(*) desc

end