﻿CREATE procedure [dbo].[GetProductMasterHistory]
as
begin
  select LPrice,[dbo].[fn_username](Updatedby) as Updatedby,convert(varchar(12), UpdatedDate, 103) as UpdatedDate from tblfdss_ProductsmasterHistory
end