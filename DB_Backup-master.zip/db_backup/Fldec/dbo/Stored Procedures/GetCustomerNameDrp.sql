﻿CREATE procedure [dbo].[GetCustomerNameDrp]
as
begin
select CID,CompanyName  from [dbo].[tblfdss_CustomerMaster]
end