﻿--GetSrchDetails 'ii'
--GetSrchDetails 'Karthick Ornate','tea'
--'Karthick Ornate', date, description, amount, remarks
-- GetSrchDetails 'test','Night food' 
CREATE procedure GetSrchDetails(@uName varchar(500),@srchStr varchar(500))
as
begin
select @uName as username, A.cAmt, B.eAmt, ( A.cAmt - B.eAmt) as availableAmt
 from
(select  sum(creditedamount) as cAmt from [PettyCashMaster] where  username = @uName) A
join 
(select SUM(expenseAmt) as eAmt from [PettyCashtransaction]  where username =@uName) B
on 1=1 where A.cAmt is not null
select ExpenseFor, ExpenseAmt, username, convert(varchar,createdDate,104) as createdDate, Sitename, billAttachment,remarks,pTId 
 from PettyCashTransaction where username=@uName and PATINDEX('%'+ @srchStr +'%',expensefor) > 0 
 union
 select ExpenseFor, ExpenseAmt, username, convert(varchar,createdDate,104) as createdDate, Sitename, billAttachment,remarks,pTId 
  from PettyCashTransaction where username=@uName and PATINDEX('%'+ @srchStr +'%',remarks) > 0 
 --remarks= ltrim(rtrim(@srchStr))
 order by createdDate desc

 
end
--select convert(varchar,createdDate,103),* from PettyCashTransaction where ltrim(rtrim(expensefor))='Night food' convert(varchar,createdDate,103)='01/04/2021'
--select convert(varchar,createdDate,104)
/*select convert(varchar,createdDate,103),* from PettyCashTransaction where PATINDEX('%food%',expensefor) > 0
select convert(varchar,createdDate,103),* from PettyCashTransaction
contains(expensefor,'Night')*/