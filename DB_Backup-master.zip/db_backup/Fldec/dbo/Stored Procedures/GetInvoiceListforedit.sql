﻿CREATE procedure [dbo].[GetInvoiceListforedit](@InvoiceId int)
AS
begin  

SELECT InvoiceId,SupplierId,  PONumberId ,InvoiceNo, FORMAT(InvoiceDate,'yyyy-MM-dd') AS InvoiceDate,FileName,Igst,Cgst,Sgst,GVInvoice, 
ProductsId = STUFF((SELECT ',' + ProductsId FROM tblfdss_ProductsInvoice where InvoiceId=@InvoiceId FOR XML PATH ('')), 1, 1, ''),
LPrice = STUFF((SELECT ',' + LPrice FROM tblfdss_ProductsInvoice where InvoiceId=@InvoiceId FOR XML PATH ('')), 1, 1, ''),
Qty = STUFF((SELECT ',' + Qty FROM tblfdss_ProductsInvoice where InvoiceId=@InvoiceId FOR XML PATH ('')), 1, 1, ''),
Discount = STUFF((SELECT ',' + Discount FROM tblfdss_ProductsInvoice where InvoiceId=@InvoiceId FOR XML PATH ('')), 1, 1, '')
from tblfdss_Invoice where InvoiceId =@InvoiceId
end