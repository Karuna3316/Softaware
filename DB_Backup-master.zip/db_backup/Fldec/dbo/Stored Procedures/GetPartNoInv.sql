﻿CREATE proc [dbo].[GetPartNoInv]  @BoxTypeId int, @ProjectId int
as
begin

select InventoryId as cId, PartNo as cVal from InvInwardRegister where  BoxTypeId = @BoxTypeId and ProjectId = @ProjectId and InventoryId is not null and PartNo is not null

end