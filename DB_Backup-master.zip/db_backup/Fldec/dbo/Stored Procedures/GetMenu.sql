﻿
CREATE Procedure [dbo].[GetMenu]

as

begin
select menuId,menu, [url], parentId, isMainMenu, active, createddate from tblmenus 
end