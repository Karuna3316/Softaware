﻿--GetPermissionDatesforDB 33
CREATE procedure [dbo].[GetPermissionDatesforDB](@userId int)
as
begin

if (day(getdate()) > 2)
begin

if(@userId = 15 or @userId = 17 or @userId = 18 or @userId = 23 or @userId = 33 or @userId = 103 or @userId = 131 or  @userId =25 or @userId = 59 or @userId = 88 or @userId = 98 or @userId = 112)
begin
select convert(varchar(10), checkindate, 103) as Date , CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0) as Time,  ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as Hours
 from tblAAttendance where month(checkindate) in ( month(getdate()))  and  day(checkindate) not in
  (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)

union
select convert(varchar(10), checkindate, 103) as Date, CONVERT(VARCHAR(10), CAST(CheckOutDate AS TIME), 0) as Time,  ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as Hours
from tblAAttendance where month(checkindate) in ( month(getdate())) and   checkout is not null  and  day(checkindate) not in (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)
end
else
begin
select convert(varchar(10), checkindate, 103) as Date , CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0) as Time, ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as Hours
 from tblAAttendance where month(checkindate) in ( month(getdate()))  and  day(checkindate) not in (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)

union
select convert(varchar(10), checkindate, 103) as Date , CONVERT(VARCHAR(10), CAST(CheckOutDate AS TIME), 0) as Time, ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as Hours
from tblAAttendance where month(checkindate) in ( month(getdate())) and   checkout is not null  and day(checkindate) not in (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)
end

end
else
begin
if(@userId = 15 or @userId = 17 or @userId = 18 or @userId = 23 or @userId = 33 or @userId = 103 or @userId = 131 or  @userId =25 or @userId = 59 or @userId = 88 or @userId = 98 or @userId = 112)
begin
select convert(varchar(10), checkindate, 103) as Date , CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0) as Time, ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as Hours
 from tblAAttendance where month(checkindate) in ( month(getdate()), month(getdate())-1)  and  Convert(varchar(12),checkindate, 103) not in
  (select Convert(varchar(12),Date, 103) from dbo.tblDim where month([date])in ( month(getdate()), month(getdate())-1) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)

union
select convert(varchar(10), checkindate, 103) as Date , CONVERT(VARCHAR(10), CAST(CheckOutDate AS TIME), 0) as Time, ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as Hours
from tblAAttendance where month(checkindate) in ( month(getdate()),month(getdate())-1) and   checkout is not null  and  Convert(varchar(12),checkindate, 103) not in 
(select Convert(varchar(12),Date, 103) from dbo.tblDim where month([date])in ( month(getdate()), month(getdate())-1) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)
end
else
begin
select convert(varchar(10), checkindate, 103) as Date , CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0) as Time, ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as Hours
 from tblAAttendance where month(checkindate) in ( month(getdate()),month(getdate())-1)  and  Convert(varchar(12),checkindate, 103) not in 
 (select Convert(varchar(12),Date, 103) from dbo.tblDim where month([date])in ( month(getdate()), month(getdate())-1) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)

union
select convert(varchar(10), checkindate, 103) as Date , CONVERT(VARCHAR(10), CAST(CheckOutDate AS TIME), 0) as Time, ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as Hours
from tblAAttendance where month(checkindate) in ( month(getdate()),month(getdate())-1) and   checkout is not null  and Convert(varchar(12),checkindate, 103) not in 
(select Convert(varchar(12),Date, 103) from dbo.tblDim where month([date])in ( month(getdate()), month(getdate())-1) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)
end
end


end