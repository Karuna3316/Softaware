﻿CREATE proc PayslipDeductionsDatasetReport
as
begin
select 'Employee PF Contribution' as Deductions, '1,800' as Amount
union
select '' as Deductions, '' as Amount
union
select '' as Deductions, '' as Amount
union
select '' as Deductions, '' as Amount
union
select '' as Deductions, '' as Amount


end