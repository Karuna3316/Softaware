﻿CREATE proc  [dbo].[Sp_Admin_Annoucement]  (@EmployeeType int)
as
begin

if(@EmployeeType = 1)
select  Convert(varchar(12), DOJ, 103)  +  ' - '  + dbo.fn_username(U.userid) as Employee, dbo.fn_Team(Teamid) as Team from tblUsers U with(nolock)
inner join tblRoleMapping RM  with(nolock) on
Rm.userId = U.Userid
inner join tblRoles  R with(nolock)
on R.roleId = RM.roleId
where r.roleId not in (9, 11) and Doj is not null and year(DOJ) = year(getdate()) and month(Doj) = month(getdate()) 

else if (@EmployeeType = 2)
select  Convert(varchar(12), DOJ, 103)  +  ' - '  + dbo.fn_username(U.userid) as Employee, dbo.fn_Team(Teamid) as Team from tblUsers U with(nolock)
inner join tblRoleMapping RM  with(nolock) on
Rm.userId = U.Userid
inner join tblRoles  R with(nolock)
on R.roleId = RM.roleId where r.roleId = 9 and Doj is not null and  year(U.Doj) = year(getdate()) and month(U.Doj) = month(getdate())

else if (@EmployeeType = 3)
select  Convert(varchar(12), DOJ, 103)  +  ' - '  + dbo.fn_username(U.userid) as Employee, dbo.fn_Team(Teamid) as Team from tblUsers U with(nolock)
inner join tblRoleMapping RM with(nolock) on
Rm.userId = U.Userid
inner join tblRoles R with(nolock)
on R.roleId = RM.roleId where r.roleId = 11 and Doj is not null and year(U.Doj) = year(getdate()) and month(U.Doj) = month(getdate())

else if (@EmployeeType = 4)
select  Convert(varchar(12), DateOfLeaving, 103)  +  ' - '  + dbo.fn_username(userid) as Employee,    dbo.fn_Team(Teamid) as Team from tblUsers with(nolock) where DateOfLeaving is not null  and year(DateOfLeaving) = year(getdate()) and month(DateOfLeaving) = month(getdate()) 
else if (@EmployeeType = 5)
select Convert(varchar(12), Checkindate, 103)  +  ' - ' + dbo.fn_username(userid) as Employee,  [dbo].[fn_TeamUserid] (UserID) as Team  from tblAAttendance with (nolock) where year(checkindate)= year(getdate()) and month(checkindate) = month(getdate()) and LeaveRequst like '%OnDuty%' order by CheckInDate
else if (@EmployeeType = 6)
select  Convert(varchar(12), Checkindate, 103)  +  ' - '  + dbo.fn_username(userid) as Employee, [dbo].[fn_TeamUserid] (UserID) as Team  from tblAAttendance with (nolock) where year(checkindate)= year(getdate()) and month(checkindate) = month(getdate()) and LeaveRequst like '%Comp Off%'
end