﻿CREATE procedure [dbo].[GetMenuMappingListForEdit](@roleId int)
as
begin
SELECT 
  CASE WHEN m.isMainMenu = 1 THEN 'MainMenu' ELSE 'SubMenu' END AS MenuType,
  m.menuId AS MenuID
FROM tblMenuMappingFrRole mm
JOIN tblmenus m ON mm.menuId = m.menuId  where mm.roleId = @roleId
end