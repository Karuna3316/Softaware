﻿CREATE proc [dbo].[Sp_GetCurrentStock]
as
begin

Select SNO,  SKU,Commodity,ClosingStock,UnitsIn,UnitsOut,FinalStock,Quantity,Rate,Total,Type,Division,LOC from tbl_Stock 
union 
Select  295,  '','','','','','','','Total Value ','710443840.86','','',''




end