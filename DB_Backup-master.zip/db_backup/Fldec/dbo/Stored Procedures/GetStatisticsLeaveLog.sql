﻿--GetStatisticsLeaveLog '2022-10-01','2022-12-31',1, null
--GetStatisticsRegularize 4
CREATE procedure [dbo].[GetStatisticsLeaveLog](@stDate datetime,@endDate datetime,@userId int,@EmployeeId int = null)
as
begin




declare @Total int, @Approved int, @Declined int, @Pending int
if (select roleName from tblRoles where roleId = (select top 1 roleId from tblRoleMapping where userid = @userId))  <> 'admin'
begin
if(@EmployeeId > 0)
begin

set @Total = (Select count(*) from [tblRequestLeave] lR  with(nolock) where (userId = @EmployeeId ) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101)  )
set @Approved = (Select count(*) from [tblRequestLeave] lR with(nolock) where (userId = @EmployeeId ) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 1 )
set @Declined = (Select count(*) from [tblRequestLeave] lR with(nolock) where (userId = @EmployeeId ) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 2)
set @Pending = (Select count(*) from [tblRequestLeave] lR with(nolock) where (userId = @EmployeeId) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved is null)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
else
begin


set @Total = (Select count(*) from [tblRequestLeave] lR  with(nolock) where (userId = @userId or reportingTo = @userId) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101)  )
set @Approved = (Select count(*) from [tblRequestLeave] lR with(nolock) where (userId = @userId or reportingTo = @userId) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 1 )



set @Declined = (Select count(*) from [tblRequestLeave] lR with(nolock) where (userId = @userId or reportingTo = @userId) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 2)
set @Pending = (Select count(*) from [tblRequestLeave] lR with(nolock) where (userId = @userId or reportingTo = @userId) and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved is null)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end

end
else
begin
if(@EmployeeId > 0)
begin

set @Total = (Select count(*) from [tblRequestLeave] lR  with(nolock) where userId = @EmployeeId  and   convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101)  )
set @Approved = (Select count(*) from [tblRequestLeave] lR  with(nolock) where  userId = @EmployeeId  and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 1 )
set @Declined = (Select count(*) from [tblRequestLeave] lR  with(nolock) where  userId = @EmployeeId  and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 2 )
set @Pending = (Select count(*) from [tblRequestLeave] lR   with(nolock) where  userId = @EmployeeId  and  convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved is null )

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
else
begin

set @Total = (Select count(*) from [tblRequestLeave] lR  with(nolock) where   convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101)  )
set @Approved = (Select count(*) from [tblRequestLeave] lR  with(nolock) where   convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 1 )

set @Declined = (Select count(*) from [tblRequestLeave] lR  with(nolock) where   convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved = 2 )
set @Pending = (Select count(*) from [tblRequestLeave] lR   with(nolock) where   convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101) and isApproved is null )

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
end
end