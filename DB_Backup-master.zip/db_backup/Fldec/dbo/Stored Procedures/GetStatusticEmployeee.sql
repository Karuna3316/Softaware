﻿
--GetCurDayAccessTimings 25
create procedure [dbo].[GetStatusticEmployeee]
as
begin
declare @userId int
declare @Absentcount int, @Presentcount int, @Holidayscount int, @mon int
set @mon = month(getdate())
set @Holidayscount = (select count(Date) from tblDim where Month(Date)= Month(getdate()) and DAY(Date) not in (1,2) )

declare @dName int
select @dName=case @mon 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end

;with CTE as

(
select Date from tblDim where DAY(Date)<= DAY(getdate()) and Month(Date)= Month(getdate())
union
select CheckInDate from tblAAttendance where UserID = @userId and CheckIn = 1 and Month(CheckInDate)= Month(getdate())) 

 select @Absentcount = day(getdate()) - count(*) from CTE

 select @Presentcount = count(*) from tblAAttendance where UserID = @userId and CheckIn = 1 and Month(CheckInDate)= Month(getdate())

 if(@mon = 4)
  select @dName as [Noofdays] , @Presentcount + 2 as [Present], @Absentcount as [Absent], @Holidayscount as Holidays
  else
    select @dName as [Noofdays] , @Presentcount  as [Present], @Absentcount as [Absent], @Holidayscount as Holidays


end