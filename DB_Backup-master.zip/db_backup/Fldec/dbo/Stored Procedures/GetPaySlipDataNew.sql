﻿--[GetPaySlipDataNewtest] 13,01,2023
CREATE procedure [dbo].[GetPaySlipDataNew](@userId int, @mon int, @year int)
as
begin
if((day(getdate()) >= 5 and @mon < month(getdate())   and year(getdate()) = @year) or   @year <year(getdate()))

begin

Declare @payRollId int

if exists (select payrollid from tblPayrollRegister where userid = @userId and month(createddate) = @mon and  year(CreatedDate)=@year )
select @payRollId =payrollid from tblPayrollRegister where userid = @userId and month(createddate) = @mon and  year(CreatedDate)=@year
else 
select top 1 @payRollId =payrollid from tblPayrollRegister where userid = @userId order by CreatedDate desc


declare @empCode nvarchar(150),@empName nvarchar(250), @empDesc nvarchar(250),@DOJ nvarchar(200),@accNo nvarchar(250),@panNo nvarchar(200)
select  @empCode = EMPID, @empDesc =(dbo.fn_Designation((select DesignationId from tblUsers with (nolock) where userid = @userId))), @empName = username, @DOJ = format(DOJ,'dd-MMM-yy'), 
@accNo = BankAccNo , @panNo = PANNo  from tblUsers where userId = @userId


declare @dName int
select @dName=case @mon 
when 12 then 31 when 11 then 30 when 10 then 31 when 9 then 30 when 8 then 31 when 7 then 31 
when 6 then 30 when 5 then 31 when 4 then 30 when 3 then 31 when 2 then 28 when 1 then 31 
end

if (year(getdate()) = @year and month(getdate()) = @mon)
set @dName=day(getdate())

 ;with CTE (PayrollID,Userid,Basic,HRA,MedicalAllowance,SpecialAllowance,EPFEmployeeContribution,ESICEmployeeContribution,ProfessionalTax,EPFEmployerContribution,
TobePaid,Conveyance,InsurancePremium , totalDays, TDS, LoanOrAdvance )
 as
(



 select PayrollID,Userid, Basic , HRA, isnull(MedicalAllowance,0) as MedicalAllowance,
 isnull(SpecialAllowance,0) as SpecialAllowance ,isnull(EPFEmployeeContribution,0) as EPFEmployeeContribution,
 isnull(ESICEmployeeContribution,0) as ESICEmployeeContribution,isnull(ProfessionalTax,0) as ProfessionalTax, 
  isnull(EPFEmployerContribution,0)as EPFEmployerContribution,

  @dName-(([dbo].[fn_HalfDayLeave](@userId,@mon,@year) + (@dName - [dbo].[fn_Daysworked](@userId,@mon,@year) - [dbo].[fn_Noofholiday](@userId,@mon,@year)) +  dbo.[fnCalcLOPFrLateChkIn](@userId,@mon) +  [dbo].[fnCalcLOPFrPermissionRpt](@userId,@mon,@year)) -  isnull([dbo].[fnLeaveAvaildedRpt](@userId,@mon,@year),0))  as TobePaid,

 isnull(Conveyance,0) as Conveyance, isnull(InsurancePremium,0) as InsurancePremium, @dName, convert(int,TDS) as TDS, convert(int, LoanOrAdvance) as LoanOrAdvance
 from tblPayrollRegister where userId = @userId and PayrollID = @payRollId

 --order by tPR.CreatedDate desc
 )

 select @empCode [eCode] ,@empName [eName], @empDesc [eDesc], @DOJ [DOJ], @accNo [accNo],
 @panNo as [panNo],@dName [totDays], TobePaid as [workedDays] , Convert(Decimal(18,2),Basic) as [basicAmt],Convert(Decimal(18,2),HRA) as [HRA], Convert(Decimal(18,2),MedicalAllowance) as [medicalAllow],Convert(Decimal(18,2),SpecialAllowance) as [specialAllow],

  case when EPFEmployeeContribution >=1 then 
 case when (((Convert(Decimal(18,2),(Basic/totalDays * TobePaid)) + Convert(Decimal(18,2),(HRA/totalDays * TobePaid)) + Convert(Decimal(18,2),(MedicalAllowance/totalDays * TobePaid)) 
 + Convert(Decimal(18,2),(SpecialAllowance/totalDays * TobePaid)) + Convert(Decimal(18,2),(Conveyance/totalDays * TobePaid)))-  Convert(Decimal(18,2),(HRA/totalDays * TobePaid)))) >= 15000 then 15000*12/100 
 else (((Convert(Decimal(18,2),(Basic/totalDays * TobePaid)) + Convert(Decimal(18,2),(HRA/totalDays * TobePaid)) + Convert(Decimal(18,2),(MedicalAllowance/totalDays * TobePaid)) 
 + Convert(Decimal(18,2),(SpecialAllowance/totalDays * TobePaid)) + Convert(Decimal(18,2),(Conveyance/totalDays * TobePaid)))-  Convert(Decimal(18, 2), Convert(Decimal(18,2),(HRA/totalDays * TobePaid))))* 12/100)
  end
  else
  EPFEmployeeContribution end
   as  [employeePFC],
 ProfessionalTax as [profTax],EPFEmployerContribution, ESICEmployeeContribution as [employeeESICContr],
TobePaid,Convert(Decimal(18,2),Conveyance)  as [conveyance],0.00 as [insurancePre], totalDays ,totalDays - TobePaid as LOP,TDS, LoanOrAdvance,

 case when EPFEmployeeContribution >=1 then 
Convert(Decimal(18,2), Round((Convert(Decimal(18,2),(Basic/totalDays * TobePaid)) + Convert(Decimal(18,2),(HRA/totalDays * TobePaid)) + Convert(Decimal(18,2),(MedicalAllowance/totalDays * TobePaid)) 
 + Convert(Decimal(18,2),(SpecialAllowance/totalDays * TobePaid)) + Convert(Decimal(18,2),(Conveyance/totalDays * TobePaid))) - 
 (case when (((Convert(Decimal(18,2),(Basic/totalDays * TobePaid)) + Convert(Decimal(18,2),(HRA/totalDays * TobePaid)) + Convert(Decimal(18,2),(MedicalAllowance/totalDays * TobePaid)) 
 + Convert(Decimal(18,2),(SpecialAllowance/totalDays * TobePaid)) + Convert(Decimal(18,2),(Conveyance/totalDays * TobePaid)))-  Convert(Decimal(18,2),(HRA/totalDays * TobePaid)))) >= 15000 then 15000*12/100 
 else (((Convert(Decimal(18,2),(Basic/totalDays * TobePaid)) + Convert(Decimal(18,2),(HRA/totalDays * TobePaid)) + Convert(Decimal(18,2),(MedicalAllowance/totalDays * TobePaid)) 
 + Convert(Decimal(18,2),(SpecialAllowance/totalDays * TobePaid)) + Convert(Decimal(18,2),(Conveyance/totalDays * TobePaid)))-  Convert(Decimal(18, 2), Convert(Decimal(18,2),(HRA/totalDays * TobePaid))))* 12/100)
  end
 ) - TDS - LoanOrAdvance ,0))  else  

 Convert(Decimal(18,2),Round(((Convert(Decimal(18,2),(Basic/totalDays * TobePaid)) + Convert(Decimal(18,2),(HRA/totalDays * TobePaid)) + Convert(Decimal(18,2),(MedicalAllowance/totalDays * TobePaid)) 
 + Convert(Decimal(18,2),(SpecialAllowance/totalDays * TobePaid)) + Convert(Decimal(18,2),(Conveyance/totalDays * TobePaid))) - (EPFEmployeeContribution) - TDS - LoanOrAdvance),0))

--end 

 end

 as Netpay
 
 
 from CTE


 end


 end