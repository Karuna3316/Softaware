﻿CREATE procedure [dbo].[UpateUsersFromUI](@userId int, @docId int,@UploadAadharFile nvarchar(200),@UploadPANFile nvarchar(200),@Name nvarchar(500),@Aadhar nvarchar(12),@PAN nvarchar(10),
@PrimaryAddress nvarchar(500),@TEmpAddress nvarchar(500),@Mobile1 nvarchar(10),@Mobile2 nvarchar(10),@EmailId nvarchar(50),@Others nvarchar(500),@Remarks nvarchar(500))
as
begin
if @userId >0
begin
update [MastertblUsers] set Name= @Name,Aadhar=@Aadhar,PAN = @PAN,PrimaryAddress=@PrimaryAddress,TEmpAddress=@TEmpAddress,Mobile1 = @Mobile1,Mobile2 = @Mobile2,EmailId=@EmailId,Others=@Others,Remarks=@Remarks,UploadPAN = @UploadPANFile,UploadAadhar = @UploadAadharFile
 where userId=@userId
end
else
begin
Declare @useridvalue int

if not exists (select userId from MastertblUsers)
set @useridvalue = 1
else
begin
select top 1 @useridvalue  = userId  from MastertblUsers order by createdDate desc
Set @useridvalue = @useridvalue + 1
end



	insert into [MastertblUsers](userId, Name,Aadhar,PAN,PrimaryAddress,TEmpAddress,Mobile1,Mobile2,EmailId,Others,Remarks,UploadPAN,UploadAadhar)
	select @useridvalue, @Name,@Aadhar,@PAN,@PrimaryAddress,@TEmpAddress,@Mobile1,@Mobile2,@EmailId,@Others,@Remarks,@UploadPANFile,@UploadAadharFile

	select @userId=max(userId) from [MastertblUsers]
end


if @docId >0
	update [tbldocumentsss] set UploadPAN = @UploadPANFile,UploadAadhar = @UploadAadharFile,userId = @userId where docId = @docId
else
begin

insert into [tbldocumentsss](userId,UploadPAN,UploadAadhar)
select @userId, @UploadPANFile, @UploadAadharFile
end
end