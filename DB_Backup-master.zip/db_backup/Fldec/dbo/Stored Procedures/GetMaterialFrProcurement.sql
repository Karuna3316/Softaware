﻿CREATE Procedure [dbo].[GetMaterialFrProcurement](@userId int)
as
begin
if exists (select roleId from tblRoleMapping where userid=@userId and roleId in (2,3))--manager or engineer
begin
	select MaterialRequestId as mRId, dbo.fn_sitenameshort(siteid) as siteN, MaterialName, Qty, Unit, 
	[status], convert(varchar,CreatedDate,103)  + ' ' + convert(varchar,CreatedDate,108) as cDate 
	from [dbo].[tblMaterialRequest] 
	where  siteId in (select item from dbo.[fnSplitString]((select projId from tblUsers where userId=@userId),','))
	--(select projId from tblUsers where userId=@userId)
	order by siteid 
end
else
begin
if exists (select roleId from tblRoleMapping where userid=@userId and roleId =1)
begin
select MaterialRequestId as mRId, (select shortNameFrSite from tblSiteNames where sId=siteid) as siteN, MaterialName,
	 Qty, Unit, [status], convert(varchar,CreatedDate,103)  + ' ' + convert(varchar,CreatedDate,108) as cDate 
	from [dbo].[tblMaterialRequest] 
	order by siteId desc
end
else
begin
	select MaterialRequestId as mRId, (select shortNameFrSite from tblSiteNames where sId=siteid) as siteN, MaterialName,
	 Qty, Unit, [status], convert(varchar,CreatedDate,103)  + ' ' + convert(varchar,CreatedDate,108) as cDate 
	from [dbo].[tblMaterialRequest] 
	where [status] not in ( 'Order Done', 'Cancelled') order by CreatedDate desc
end
end
end

--select shortNameFrSite from tblSiteNames where sId=
--
--select * from [tblMaterialRequest]