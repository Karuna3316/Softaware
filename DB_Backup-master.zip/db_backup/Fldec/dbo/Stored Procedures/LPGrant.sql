﻿CREATE proc [dbo].[LPGrant] 
as
begin
select userid, dbo.fn_username(userid) as EmployeeName,
case when IsPermission = 1 then 'Yes' else 'No' end as Permission,
case when IsRegularise = 1 then 'Yes' else 'No' end as Regularize,
case when IsLeave = 1 then 'Yes' else 'No' end as Leave

 from tblUsers where active = 1 and (IsPermission is not null or IsRegularise is not null or IsLeave is not null or Time is not null )
end