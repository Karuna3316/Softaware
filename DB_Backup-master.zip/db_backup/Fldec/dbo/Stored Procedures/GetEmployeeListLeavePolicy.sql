﻿--[GetEmployeeList] 1
CREATE procedure [dbo].[GetEmployeeListLeavePolicy]
as
begin


select userid, username from tblUsers where active = 1 order by username

end