﻿
--GetTimeUtilization 1
CREATE procedure [dbo].[GetTimeUtilization](@userId int)
as
begin



select [dbo].[fn_TimePercentageCalc]  (@userId) as TimePercentage


 
end