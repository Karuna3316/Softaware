﻿create proc Sp_Admin_PresentDetails
as
begin
select 'Test1' as EmployeeName, 'Tester' as Designation, '10:00' as CheckInTime, '19:30' as CheckOutTime
union
select 'Test2' as EmployeeName, 'Tester' as Designation, '10:00' as CheckInTime, '19:30' as CheckOutTime
end