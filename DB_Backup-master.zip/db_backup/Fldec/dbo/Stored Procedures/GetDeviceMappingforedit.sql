﻿CREATE procedure [dbo].[GetDeviceMappingforedit] (@userid int) 
as
begin
Select userid,username,Devicecode from tblusers where userid =@userid


end