﻿
CREATE  proc [dbo].[Delayleavereport]
as
begin
select [dbo].[fn_username](userid), [dbo].[fn_joiningid](userid), case when ( sum(DelayLeave) - 3) <0 then 0 else ( sum(DelayLeave) - 3) end   from tblAttendance where month(checkindate) = month(getdate()-1) and checkin = 1  group by  userid  ,[dbo].[fn_joiningid](userid) order by  [dbo].[fn_username](userid)
end