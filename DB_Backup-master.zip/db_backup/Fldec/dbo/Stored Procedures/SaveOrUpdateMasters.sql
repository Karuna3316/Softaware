﻿CREATE procedure [dbo].[SaveOrUpdateMasters] (@TeamID int , @Team varchar(100),@ProbationStatusID int, @ProbationStatus varchar(100),@DesignationID int , @Designation varchar(100))
as 
begin
if(@TeamID > 0)
begin
update tblTeam set Team = @Team  where TeamID = @TeamID
 
select 1
end
else
begin
select 2
     insert into tblTeam(TeamID, Team)
	select @TeamID, @Team
	select 3
end


if(@ProbationStatusID > 0)
 begin
 update tblProbationStatus set ProbationStatus = @ProbationStatus where ProbationStatusID =@ProbationStatusID
 
 select 1
 end
 else
 begin
 select 2
  insert into tblProbationStatus(ProbationStatusID, ProbationStatus)
	select @ProbationStatusID, @ProbationStatus
	select 3
end


if(@DesignationID > 0)
 begin
 update tblDesignation set Designation = @Designation where DesignationID =@DesignationID
 

 end

 else
 begin
 select 2
  insert into tblDesignation(DesignationID, Designation)
	select @DesignationID, @Designation
	select 3
end
end