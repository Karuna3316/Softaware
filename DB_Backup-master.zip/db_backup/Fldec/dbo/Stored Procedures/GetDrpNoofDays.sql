﻿Create procedure [dbo].[GetDrpNoofDays]
as
begin
select Id , Description  from tblDropdown where Dropdowntype = 'NoofDays'
end