﻿
create proc [dbo].[AttendanceDetails] 

as

begin
DECLARE @CheckInDate datetime

SET @CheckInDate=CONVERT(DateTime, CONVERT(VARCHAR,GETDATE(),101)+' 9:00:00')
--select @CheckInDate
--select GETDATE()
--if(@CheckInDate < (select GETDATE()))
--select 1
--else 
--select 2

select (select count(UserName) from tblUsers where UserID=userId and active = 1) as TotalEmployees,
(select COUNT(CheckIn) from tblAAttendance where CheckIn=1 and CONVERT(varchar(12),CheckInDate,103)=CONVERT(varchar(12),GETDATE(),103)) as TotalPresent,
(select (select count(UserName) from tblUsers where UserID=userId and active = 1)) - (select COUNT(CheckIn) from tblAAttendance where CheckIn=1 and CONVERT(varchar(12),CheckInDate,103)=CONVERT(varchar(12),GETDATE(),103))  as TotalAbsent,
(select count(CheckIn)from tblAAttendance  where CheckInDate >= @CheckInDate) as TotalLateCheckIn
end