﻿
create procedure [dbo].[SaveOrUpdateLeavePolicy] (@reqUserId int, @LPId int, @Permission nvarchar, @Regularize nvarchar, @Leave nvarchar )
as
begin

if(@LPId > 0)
begin
update tblLeavePolicy set reqUserId = @reqUserId, Permission = @Permission, Regularize = @Regularize, Leave = @Leave  where LPId = @LPId

select 2
end
else
begin
	insert into tblLeavePolicy(reqUserId, Permission, Regularize, Leave)
	select @reqUserId, @Permission, @Regularize, @Leave
		Select 1

end

end