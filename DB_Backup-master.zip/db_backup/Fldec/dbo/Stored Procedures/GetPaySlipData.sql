﻿--[GetPaySlipData] 3
CREATE procedure [dbo].[GetPaySlipData](@payRollId int)
as
begin
declare @year int,@mon int,@userId int

--set @userId =1
--set @mon = 10
--set @year=2022

select @userId=userId, @mon = month(createddate), @year=year(createddate) from tblPayrollRegister where PayrollID = @payRollId

declare @empCode nvarchar(150),@empName nvarchar(250), @empDesc nvarchar(250),@DOJ nvarchar(200),@accNo nvarchar(250),@panNo nvarchar(200)
select  @empCode = EMPID, @empDesc =Designation, @empName = username, @DOJ = format(DOJ,'dd-MMM-yy'), 
@accNo = BankAccNo , @panNo = PANNo  from tblUsers where userId = @userId

declare @totalDaysFraMonth int,@lopDays int,@noOfDaysWorked int

declare @dName int

select @dName=case @mon 
when 12 then 31 when 11 then 30 when 10 then 31 when 9 then 30 when 8 then 31 when 7 then 31 
when 6 then 30 when 5 then 31 when 4 then 30 when 3 then 31 when 2 then 28 when 1 then 31 
end

set @totalDaysFraMonth = @dName
--if (year(getdate()) = @year and month(getdate()) = @mon)
--set @dName=day(getdate())
declare @tL int
--select @dName as calculatedDays
select 
@noOfDaysWorked = [DaysWorked] ,
@lopDays = @dName - LOP,@tL=totalLeave 
from(
SELECT
(select count(UserID) from tblAAttendance where year(checkindate)=@year and month(checkindate)=@mon and UserID=@userId  
and CAST(checkindate as time) <= CAST('12:00' as time) and   CAST(checkoutdate as time) >= CAST('17:00' as time)) as   [DaysWorked],

(select count(UserID) * 0.5 from tblAAttendance where year(checkindate)=@year and month(checkindate)=@mon and UserID=@userId 
and (CAST(checkindate as time) >= CAST('12:00' as time) or   CAST(checkoutdate as time) <= CAST('17:00' as time)))  as [HalfDay], 

(select count(UserID) from tblAAttendance where userid=@userId and month(checkindate)=@mon and year(checkindate)=@year
and day(checkindate) in (select day(Date) from tblDim where month([date])=@mon and year([Date]) =@year)) as workedOnHolidays,

clAvail,slAvail ,    
dbo.[fnCalcLOPFrLateChkIn](@userId,@mon) as [Regularize LOP],    
[dbo].[fn_Noofholiday](@userId,@mon,@year)  as [NoOfHolidays],totalLeave, totalLeave-(clAvail + slAvail) LOP 

from( select        
isnull(sum(case when leaveDaysType = 1 and leaveCategory=2 and isApproved=1 then 1   
when leaveDaysType = 3 and leaveCategory=2  then 0.5
when leaveDaysType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)     
else 0 end),0) +   isnull(sum(case when leaveType = 1 and leaveCategory=2 and isApproved=1 then 1 
when leaveType = 3 and leaveCategory=2  then 0.5
when leaveType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)   
else 0 end),0) slAvail,
isnull(sum(case when leaveDaysType = 1 and leaveCategory=1 then 1    
when leaveDaysType = 3 and leaveCategory=1 then 0.5
 when leaveDaysType= 2 and leaveCategory=1 
then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)      else 0 end),0) +   
isnull(sum(case when leaveType = 1 and leaveCategory=1 then 1    
when leaveType = 3 and leaveCategory=1  then 0.5 
when leaveType= 2 and leaveCategory=1 
then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)      else 0 end),0) clAvail,
@totalDaysFraMonth-((select count(DimId) from tblDim where year(date)= @year and month(date) = @mon) +
(select count(UserID) from tblAAttendance where year(checkindate)= @year and month(checkindate)=@mon and UserID=@userId
and day(checkindate) not in(select day(date) from tblDim where year(date)=@year and month(date) = @mon)
and CAST(checkindate as time) <= CAST('12:30' as time) and 
CAST(checkoutdate as time) >= CAST('17:30' as time)) +
(select count(userId)*0.5 from tblAAttendance where year(checkindate)= @year 
and month(checkindate)=@mon and UserID =@userId
and (CAST(checkindate as time) >= CAST('12:30' as time) or 
CAST(checkoutdate as time) <= CAST('17:30' as time)))) totalLeave
from  tblRequestLeave where userId = @userId and isApproved=1 and   year(leaveStartedOn)=@year and month(leaveStartedOn) = @mon ) A1 ) A2


declare @basicAmt decimal, @hraAmt decimal, @medicalAllow decimal, @specialAllow decimal, @grossPay decimal,@conveyance decimal
declare @empPF decimal, @totDeductions decimal, @netPay decimal, @empESICContri decimal,@profTax decimal,@insurancePre decimal

select @basicAmt = [basic], @empPF =EPFEmployeeContribution,@medicalAllow = MedicalAllowance, @specialAllow = SpecialAllowance,
@hraAmt = HRA,@profTax = ProfessionalTax,@conveyance = Conveyance, @empESICContri= ESICEmployeeContribution, @insurancePre = InsurancePremium
 from tblPayrollRegister where PayrollID = @payRollId

 --set @grossPay = @basicAmt + @hraAmt + @medicalAllow + @specialAllow
 --set @totDeductions = @empPF + @profTax
 --set @netPay = @grossPay- @totDeductions

 --select * from tblPayrollRegister

 if @noOfDaysWorked = 0
 begin
 set @lopDays = 0
 set @insurancePre =0
 set @empESICContri = 0
 end
 
 select @empCode [eCode] ,@empName [eName], @empDesc [eDesc], @DOJ [DOJ], @accNo [accNo],
 @panNo as [panNo],@totalDaysFraMonth [totDays] ,@lopDays [LOP] ,@noOfDaysWorked [workedDays],@tL, @basicAmt [basicAmt], @hraAmt [HRA], 
 @medicalAllow [medicalAllow], @specialAllow [specialAllow], @conveyance as [conveyance],
 @empPF [employeePFC], @profTax [profTax], @noOfDaysWorked as [TobePaid],@empESICContri as [employeeESICContr],
 @insurancePre as [insurancePre]

 end