﻿
CREATE procedure [dbo].[SaveorupdateDeviceMapping] (@userid int,@Devicecode nvarchar(2000),@UpdatedBy int)
as
begin
if(@userid > 0)
begin
update tblusers  set  Devicecode = @Devicecode,UpdatedBy=@UpdatedBy,UpdatedDate=GETDATE() where userid  = @userid 
select 2
end

end