﻿

CREATE procedure [dbo].[GetLeaveLogforAdminLogWOP]   
as
begin
select top 100 reqLId,
userId,
(select username from tblusers where userId=lR.userId) as userName,
[dbo].[fn_Dropdown](leaveType) as leaveType,
[dbo].[fn_Dropdown](leaveDaysType) as leaveDaysType,
[dbo].[fn_Dropdown](leaveCategory) as leaveCategory,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,
convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, 
Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
isApproved,reason
from [tblRequestLeave] lR  order by createdDate desc 
end