﻿--[GetEmployeeList] 1
CREATE procedure [dbo].[GetEmployeeListLeave]
as
begin


select userid, username from tblUsers where active = 1 order by username

end