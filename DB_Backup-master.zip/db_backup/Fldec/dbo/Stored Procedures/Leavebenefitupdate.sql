﻿ CREATE procedure [dbo].[Leavebenefitupdate](@UserId int,@CreatedDate datetime ,@Year int,@CasualLeave int,@SickLeave int,@EmployeeId int)
as
begin
if @UserId >0
begin
update [dbo].[tblLeaveBalanceMaster] set CasualLeave= 1, SickLeave = 0.5,CreatedDate=@CreatedDate,Year=@Year
 where UserId=@EmployeeId

end
else
begin
	insert into [dbo].[tblLeaveBalanceMaster](UserId,CreatedDate,Year)
	select @UserId,@CreatedDate,@Year

	select @UserId=max(@UserId) from [dbo].[tblLeaveBalanceMaster]
	
end
end