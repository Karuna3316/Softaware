﻿
--GetEmployees 'admin'
CREATE proc [dbo].[GetEmployees](@rName varchar(100))
as
Begin
if  @rName='Admin'
begin
select Userid as [EmpID],
 UserName as [EmpName],   Designation, Mobile, 
 Convert(varchar(12), DOJ, 103) as DOJ, Insured, Form11,
  case when IsOffice = 0 then 'Office' else 'Site' end as Work,JoiningId,EmailId 
  from tblUsers where active = 1 and username <> 'Rm' order by JoiningId
  end
  end

 -- select * from tblUsers