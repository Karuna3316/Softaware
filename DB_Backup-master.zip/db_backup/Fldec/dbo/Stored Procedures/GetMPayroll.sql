﻿CREATE proc [dbo].[GetMPayroll]
as
begin

Select distinct dbo.fn_MPayrollID(EmpName) as PayrollID,dbo.fn_MEmpId(EmpName) as EmpId, dbo.fn_MEmpName(EmpName) as EmpName,dbo.fn_MBankacNo(EmpName) as BankacNo
,dbo.fn_MBankIFSCcode(EmpName) as BankIFSCcode,dbo.fn_MEarnings(EmpName) as Earnings,dbo.fn_MDeductions(EmpName) as Deductions,dbo.fn_MNetpay(EmpName) as Netpay
, [dbo].[fn_PRMYear](EmpName) as Year, [dbo].[fn_PRMMonth] (EmpName) as Month , [dbo].[fn_PayrollMCreatedBy](EmpName)  as UpdatedBy, [dbo].[fn_PayrollMCreatedDate](EmpName) as UpdatedDate from tblPayrollM where active = 1

end