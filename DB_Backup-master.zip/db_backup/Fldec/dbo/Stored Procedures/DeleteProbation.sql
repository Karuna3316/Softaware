﻿CREATE proc [dbo].[DeleteProbation]
(@ProbationStatusID int)
as
begin
delete from tblProbationStatus where ProbationStatusID = @ProbationStatusID
end