﻿CREATE procedure [dbo].[GetNewPermissiolog] (@stDate datetime,@endDate datetime, @userid int, @roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,CheckIn,--CheckOut,
reason,createdDate,[status],PId,reportingTo, 
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblPermission lR where 
 	 convert(varchar(10),CheckIn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),CheckIn,101) <= convert(varchar(10),@endDate,101) order by [status] 
	end
	else
	select userId, 
(select username from tblusers where userId=lR.userId) as userName,CheckIn,--CheckOut,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblReconciliationNew lR where  (lR.userId = @userId or lR.reportingTo = @userId) and
 	( convert(varchar(10),CheckIn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),CheckIn,101) <= convert(varchar(10),@endDate,101))     order by [status] 
 
end