﻿Create procedure [dbo].[GetDrpType]
as
begin
select Id , Description  from tblDropdown where Dropdowntype = 'Type'
end