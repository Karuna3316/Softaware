﻿CREATE proc [dbo].[GetProjectsName]
as
begin
select ProjectId as cId, ProjectName as cVal from InvtblProject

end