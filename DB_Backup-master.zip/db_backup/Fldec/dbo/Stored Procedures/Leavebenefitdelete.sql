﻿CREATE procedure [dbo].[Leavebenefitdelete](@UserId int)
as
begin
delete from  [tblLeaveBalanceMaster] where UserId=@UserId
end