﻿--[GetRegularizationDates] 33
CREATE procedure [dbo].[GetRegularizationDates](@userId int)
as
begin
if (day(getdate()) > 2)
begin
select Convert(varchar(12), CheckInDate, 103) as Date,  CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0) as Time from  tblAAttendance where userid=@userId 
and year(Checkindate) = year(getdate()) and month(CheckInDate) = month(getdate()) and convert(date,CheckInDate)  not in (select convert(date,date) from tblDim with(nolock) where  year(date) = year(getdate()) and month(date)  = month(getdate())) 
and ((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)
end
else
begin
select Convert(varchar(12), CheckInDate, 103) as Date,  CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0) as Time from  tblAAttendance where userid=@userId 
and year(Checkindate) = year(getdate()) and month(CheckInDate) = month(getdate()) and convert(date,CheckInDate)  not in (select convert(date,date) from tblDim with(nolock) where year(date) = year(getdate()) and month(date)  in ( month(getdate()), month(getdate())-1) )
and ((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)
end
end