﻿CREATE procedure [dbo].[GetDocumentsFrShare](@uId int)
as
begin
declare @projId varchar(500)
select @projId =projId from tblUsers where userId=@uId

select docId,
(select shortNameFrSite from tblsitenames where sId=siteId) as siteN,
docName, docFileName,
(select docType from tblDocumentTypes where docTypeId=tD.docTypeId) as docType 
from tblDocuments tD
where siteId in (select item from [dbo].[fnSplitString](@projId,','))
--and docTypeId = (select docTypeId from tblDocumentTypes where patindex('%share%',docType) > 0)
--userId = @uId 
order by createddate desc
end

--select * from tblDocuments where docTypeId = 16