﻿CREATE procedure [dbo].[SaveOrUpdateLeaveLog](@reqLId int,@userId int, @LeaveMode int,@StartDate datetime, @EndDate datetime=null, @reason nvarchar(2000),@Leavetype int, @ReportingUser int, @NoofDays int,@compOffTakenFrMultiple nvarchar(1000))
as
BEGIN
if(@reqLId>0)
begin
update [tblRequestLeave] set userId = @userId, leaveType = @LeaveMode, leaveDaysType=@NoofDays,leaveCategory=@Leavetype,leaveStartedOn = @StartDate, leaveEndsOn = @EndDate ,reportingTo=@ReportingUser,reason = @reason,UpdatedDate =getdate() where reqLId = @reqLId
select 2
end
else
begin
insert into [tblRequestLeave](userId, leaveType,leaveDaysType,leaveCategory,leaveStartedOn, leaveEndsOn,reportingTo,reason,createdDate)
select @userId, @LeaveMode,@NoofDays,@Leavetype,@StartDate, @EndDate,@ReportingUser, @reason,getdate()

select 1
DECLARE @reqL int
SET @reqL = SCOPE_IDENTITY()

if @compOffTakenFrMultiple is not null and len(@compOffTakenFrMultiple)>0
begin
insert into tblCompOffTakenFr(reqLId,compOffDate)
select @reqL,item from dbo.fnSplitString(@compOffTakenFrMultiple,',')
end

END

end