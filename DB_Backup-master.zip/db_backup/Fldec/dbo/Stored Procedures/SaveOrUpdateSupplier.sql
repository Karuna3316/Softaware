﻿CREATE procedure [dbo].[SaveOrUpdateSupplier] (  @SID int , @SupplierName nvarchar(500),@CPName nvarchar(300),@GstNo nvarchar(300),@CPNumber nvarchar(25),@Address nvarchar(MAX), @userid int)
as
begin

if(@SID > 0)
begin
update tblfdss_SupplierMaster set  SupplierName = @SupplierName, CPName = @CPName, GstNo = @GstNo, CPNumber = @CPNumber, Address = @Address ,UpdatedDate=getdate(), Updatedby = @userid where SID = @SID
select 2
end
else
begin
if not exists (select SID,SupplierName,CPName,GstNo,CPNumber,Address from tblfdss_SupplierMaster with (nolock) where SupplierName = @SupplierName )
begin
	insert into [tblfdss_SupplierMaster ]( SupplierName,CPName,GstNo,CPNumber,Address,CreatedBy, CreatedDate)
	select @SupplierName, @CPName, @GstNo, @CPNumber, @Address, @userid, getdate()
	Select 1
end

else
begin
Select 3

end

end

end