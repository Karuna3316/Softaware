﻿create proc [dbo].[GetCustomerMasterdropdown]
as
begin
select MasterID,Description from tblfdss_Master where MasterType='Industry'

end