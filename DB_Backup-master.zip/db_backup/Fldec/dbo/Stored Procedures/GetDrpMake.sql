﻿create procedure [dbo].[GetDrpMake]
as
begin
select MasterID,Description  from tblfdss_Master where MasterType='Make'
end