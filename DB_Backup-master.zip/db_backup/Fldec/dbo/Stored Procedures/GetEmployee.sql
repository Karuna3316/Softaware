﻿CREATE procedure [dbo].[GetEmployee]
as
begin
select userId , UserName  from tblUsers where active = 1
end