﻿CREATE proc [dbo].[Sp_Admin_Regularize_Counts]
as
begin
select 'Test1' as EmployeeName, '7' as Count
union
select 'Test2' as EmployeeName, '3' as Count
union
select 'Test3' as EmployeeName, '0' as Count
union
select 'Test4' as EmployeeName, '10' as Count
end