﻿CREATE procedure [dbo].[GetSupplierList]
as
begin
  select distinct SuppID,[dbo].[fn_suppliername](SupplierId) as SupplierId,PONumber,convert(varchar(12), PODate, 103) as PODate,FileName,
  case when Updatedby is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(Updatedby) end as Updatedby,
case when Updatedby is null then CreatedDate  else  UpdatedDate end as UpdatedDate from tblfdss_Supplier order by UpdatedDate desc
end