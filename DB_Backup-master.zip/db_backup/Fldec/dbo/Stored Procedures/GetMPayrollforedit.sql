﻿CREATE proc [dbo].[GetMPayrollforedit](@PayrollID int)
as
begin

Select PayrollID,EmpId,EmpName,BankacNo,BankIFSCcode,Earnings,Deductions,Netpay from tblPayrollM where PayrollID = @PayrollID

end