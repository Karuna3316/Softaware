﻿CREATE proc [dbo].[DeleteInvSupplier]
(@SuppID int)
as
begin
delete from tblfdss_Supplier where SuppID = @SuppID
delete from tblfdss_Products where SuppID = @SuppID
end