﻿
 CREATE procedure [dbo].[ApplyHRMSNorms]   (@regId int,@userId int)
 as
 begin
	 declare @PermissionDaycount int
 select @PermissionDaycount = count( distinct day(checkin)) from tblPermission where  status = 1 and userId = (select userid from tblPermission where PId= @regId) and year(CheckIn) = year(getdate()) and month(checkin) = month(getdate()) and day(checkin)  <> (select day(checkin) from tblPermission where PId= @regId) and Aspernorms = 1

  if ( 3 <= @PermissionDaycount)
 begin
 	update tblPermission set approvedUser=@userId,[status]=2, Aspernorms = 0,
		approvedDate = getdate() where PId=@regId
		select 2
		end
		else 
		begin
		 	update tblPermission set approvedUser=@userId,[status]=1, Aspernorms = 1,
		approvedDate = getdate() where PId=@regId
		select 1
		end

 end