﻿
CREATE proc [dbo].[GetOutwardMaterial]  (@userId int, @role varchar(100))
as
begin
if @role='admin'
begin
	select distinct SiteName ,
		case when row_number() over(partition by [BOQ Work Description] order by [BOQ Work Description] ) = 1 
		then [BOQ Work Description] else '' end as [BOQ Work Description],
		MaterialName,Quantity,Unit, Createddate
			from(
				select (select shortNameFrSite from tblSiteNames s where Sid =  O.SiteId) as SiteName,
				(select B.Description from [tblShortBOQ] B where SLNO = O.SLNO and SiteId = O.SiteId ) As [BOQ Work Description] , 
				 MaterialName,O.Quantity, I.Unit, O.Createddate from [dbo].[Mt_MaterialOutward]  O
				 inner join [dbo].[Mt_MaterialInwardNew] I
					on O.InventoryId = I.InventoryId)  OM
end
else
begin
		declare @projId varchar(200)
		select @projId =projId from tblUsers where userId=@userId

		select distinct SiteName ,
		case when row_number() over(partition by [BOQ Work Description] order by [BOQ Work Description] ) = 1 
		then [BOQ Work Description] else '' end as [BOQ Work Description],
		MaterialName,Quantity,Unit, Createddate
			from(
				select (select shortNameFrSite from tblSiteNames s where Sid =  O.SiteId) as SiteName,
				(select B.Description from [tblShortBOQ] B where SLNO = O.SLNO and SiteId = O.SiteId ) As [BOQ Work Description] , 
				 MaterialName,O.Quantity, I.Unit, O.Createddate from [dbo].[Mt_MaterialOutward]  O
				 inner join [dbo].[Mt_MaterialInwardNew] I
					on O.InventoryId = I.InventoryId
					where I.SiteName in (select item from [dbo].[fnSplitString](@projId,','))
					)  OM
end
end

--select top 1 * from [Mt_MaterialInwardNew]