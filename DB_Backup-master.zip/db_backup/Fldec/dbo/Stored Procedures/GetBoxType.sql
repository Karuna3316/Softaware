﻿CREATE proc [dbo].[GetBoxType] @ProjectTypeId int
as
begin

select BoxTypeId as cId, BoxTypeName as cVal  from InvtblBoxType where ProjectTypeId = @ProjectTypeId

end