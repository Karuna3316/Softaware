﻿CREATE proc [dbo].[HousekeepingBill] --450, 05,1,31,'Iopex 4th floor'
( @HousekeepingRate int, @month int, @StartDate int, @EndDate int, @sitename varchar(150))
As
begin

 

with wagestable (Date, Housekeeping,	[Rate],	[Total Amount])
as
(
select convert(varchar(12), Createddate, 105) as Date, (Housekeeping + OTHousekeeping) as Housekeeping, @HousekeepingRate as [Rate], (Housekeeping + OTHousekeeping)  * @HousekeepingRate  as  [Total Amount]  from
 [dbo].[tblLabourReport] where month = @month and day between @StartDate and @EndDate and SiteName = @sitename
 )

 select * from wagestable union
 select 'Total', sum(Housekeeping),	@HousekeepingRate, Sum([Total Amount]) from wagestable


 end