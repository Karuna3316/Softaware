﻿CREATE proc [dbo].[GetLeavePolicyGforedit](@userid int)
as
begin

Select userid, dbo.fn_username(userid) as EmployeeName, isnull(IsPermission, 0) as IsPermission, isnull(IsRegularise,0) as IsRegularise, isnull(IsLeave, 0)  as IsLeave , Time from tblUsers with (nolock) where userid = @userid

end

--select time, * from tblUsers where userid = 130