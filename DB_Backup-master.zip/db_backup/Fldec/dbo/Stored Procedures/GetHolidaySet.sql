﻿CREATE procedure [dbo].[GetHolidaySet](@stDate datetime,@endDate datetime)
as
begin

 select DimId,Convert(varchar(12),Date,105) as Date from tblDim

end