﻿CREATE proc [dbo].[DeleteMPayroll]
(@PayrollID int)
as
begin

update tblPayrollM set active = 0  where EmpName  = (select EmpName from tblPayrollM with(nolock) where PayrollID =  @PayrollID)

if (@PayrollID = @PayrollID)
begin
delete from tblPayrollM where PayrollID = @PayrollID
end

end