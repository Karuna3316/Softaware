﻿CREATE procedure [dbo].[GetSubMenuCheckbox](@ParentID int)
as
begin
      select menuId as SMID, CASE WHEN isMainMenu = 0 THEN SUBSTRING(menu, CHARINDEX('<span class="pcoded-mtext">', menu) + LEN('<span class="pcoded-mtext">'), CHARINDEX('</span> </a> </li>', menu) - CHARINDEX('<span class="pcoded-mtext">', menu) - LEN('<span class="pcoded-mtext">')) END AS SubMenu FROM tblmenus where parentId=@ParentID and isMainMenu=0
end