﻿CREATE procedure [dbo].[GetDocFrId](@dId int)
as
begin
select docId,
siteId as siteN,
--(select shortNameFrSite from tblsitenames where sId=siteId) as siteN,
docName, docFileName, docTypeId from tblDocuments
where docId = @dId 
end

--select * from tblDocuments