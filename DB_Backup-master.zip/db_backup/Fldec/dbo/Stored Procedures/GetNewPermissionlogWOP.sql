﻿--select * from tblPermission
CREATE procedure [dbo].[GetNewPermissionlogWOP]
as
begin

select top 100  userid, (select username from tblUsers where userid = PR.userId) as username , PDatewithhour as checkin, reason, createddate, status , PId, reportingTo, 
(select username from tblUsers where userid = PR.reportingTo) as reportingUser from tblPermission PR 
 order by PId   desc


	end