﻿CREATE proc [dbo].[GetUserDetails] 
as
begin
select Date,Description from tblDim

end