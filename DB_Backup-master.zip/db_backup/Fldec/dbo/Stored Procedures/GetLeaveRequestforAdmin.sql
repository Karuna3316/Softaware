﻿
--[dbo].[GetLeaveRequestforAdmin] '2022-11-02','2022-10-28', 2, 'Employee'

CREATE procedure [dbo].[GetLeaveRequestforAdmin]   (@stDate datetime,@endDate datetime, @userid int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,leaveDaysType 
from [tblRequestLeave] lR 

 where 	 convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101)
order by  lR.leaveStartedOn 

end
else
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,leaveDaysType 
from [tblRequestLeave] lR 

 where  	 (convert(varchar(10),lR.leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),lR.leaveStartedOn,101) <= convert(varchar(10),@endDate,101)) and (lR.userId = @userId or lR.reportingTo = @userId)
order by lR.leaveStartedOn 
end
end