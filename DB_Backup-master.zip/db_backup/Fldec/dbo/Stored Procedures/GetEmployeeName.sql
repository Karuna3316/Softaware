﻿create procedure [dbo].[GetEmployeeName]
as
begin
select userid as cId, username as cVal from tblUsers where active = 1
union
select '0' as cId,'select' as cVal
end