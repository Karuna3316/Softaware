﻿CREATE proc [dbo].[OverallReports] (@ProjectId int)


as

begin
(
select ProjectId,dbo.fn_Project(ProjectId) as ProjectName ,Item, Quantity, Value,Reference, PartNo, Description,Manufacturer,PCBFootprint from invtblboms where ProjectId  = @ProjectId 
)
select ProjectId, dbo.fn_Project(ProjectId) as ProjectName, Item, Quantity,  Value,Reference, PartNo, Description,Manufacturer,PCBFootprint from invtblboms
 end