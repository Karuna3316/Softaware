﻿CREATE proc [dbo].[GetLeaveBenefits]
as
begin

Select distinct dbo.fn_LBID(userid) as lBId, UserId, dbo.fn_username(userid) as EmployeeName,  dbo.fn_LBDate(Userid) as Date, dbo.fn_LBYear(Userid) as Year,
Case when dbo.fn_LBMONth(Userid) = 1 then 'JAN' 
when dbo.fn_LBMONth(Userid) = 2 then 'FEB'
when dbo.fn_LBMONth(Userid) = 3 then 'MAR'
when dbo.fn_LBMONth(Userid) = 4 then 'APR'
when dbo.fn_LBMONth(Userid) = 5 then 'MAY'
when dbo.fn_LBMONth(Userid) = 6 then 'JUN'
when dbo.fn_LBMONth(Userid) = 7 then 'JUL'
when dbo.fn_LBMONth(Userid) = 8 then 'AUG'
when dbo.fn_LBMONth(Userid) = 9 then 'SEP'
when dbo.fn_LBMONth(Userid) = 10 then 'OCT'
when dbo.fn_LBMONth(Userid) = 11 then 'NOV'
when dbo.fn_LBMONth(Userid) = 12 then 'DEC'
end  as Mon, CasualLeave, SickLeave from tblLeaveBalanceMaster where CasualLeave = 1.0 and SickLeave = 0.5

end