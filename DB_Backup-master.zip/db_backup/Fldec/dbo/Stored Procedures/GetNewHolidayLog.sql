﻿CREATE procedure [dbo].[GetNewHolidayLog](@Date datetime)
as
begin

 select DimId,Date from tblDim


end