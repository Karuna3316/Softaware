﻿
CREATE procedure [dbo].[SaveOrUpdateLeaveBenefitP] (@InventoryId int,@Qty decimal(18,2), @UserId int, @OutwardTo int )
as


begin
	insert into [InvOutwardRegister](InventoryId,Qty, OutwardTo,CreatedBy, CreatedDate)
	select @InventoryId,@Qty, @OutwardTo,@UserId, getdate()


end