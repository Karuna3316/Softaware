﻿create proc Sp_Admin_Leave
as
begin
select 'Test1' as EmployeeName, '2' as Count
union
select 'Test2' as EmployeeName, '1' as Count
end