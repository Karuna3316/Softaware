﻿create procedure TakeBreakAt(@userId int)
as
begin
declare @attendaceId int
select @attendaceId = attendanceId from tblAAttendance where UserID = @userId and convert(varchar,CheckInDate,103)=convert(varchar,getdate(),103)
insert into tblWorkBreaksTakenInADay(attendanceId,userId,tookBreakAt)
select @attendaceId,@userId,getdate()
end