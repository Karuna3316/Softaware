﻿
CREATE procedure [dbo].[SaveOrUpdateDesignation] (  @Designation nvarchar(2000), @DesignationID int)
as
begin

if(@DesignationID > 0)
begin
update tblDesignation set  Designation = @Designation where DesignationID = @DesignationID

select 2
end
else
--begin
--if not exists (select DesignationID from tblDesignation with (nolock) where convert(varchar(12), createdDate, 103) = convert(varchar(12), @createdDate, 103))
begin
	insert into [tblDesignation]( Designation)
	select @Designation
	Select 1
	--end
	--else
	--Select 3

	end

end