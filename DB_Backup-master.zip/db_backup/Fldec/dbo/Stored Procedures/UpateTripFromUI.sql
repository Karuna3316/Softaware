﻿CREATE procedure [dbo].[UpateTripFromUI](@tripId int, @docId int,@dcFile nvarchar(500),@royaltySlipFile nvarchar(500), @landTFile nvarchar(500),
@supplierId int, @clientId int, @materialId int, @truckId int, @cDate datetime, @dcno nvarchar(50),@royaltyNo nvarchar(500),
@royaltyMT nvarchar(500),@netWeighMT nvarchar(500))
as
begin
if @tripId >0
begin
update [VECtblTripdetails] set createdDate = @cDate,DCNO= @dcno, SupplierId = @supplierId,ClientId = @clientId,MaterialId = @materialId,Truckid = @truckId,
RoyalityNo = @royaltyNo,RoyaltyMT = @royaltyMT,NetWeightMT = @netWeighMT where id=@tripId
end
else
begin
	declare @TripNo nvarchar(50)     
Select top 1 @TripNo = TripNO + 1 from [VECtblTripdetails] with (nolock) order by DCNO desc 

	insert into [VECtblTripdetails](TripNO,createdDate,DCNO,SupplierId,ClientId,MaterialId,Truckid,
	RoyalityNo,RoyaltyMT,NetWeightMT)
	select @TripNo,@cDate,@dcno,@supplierId,@clientId, @materialId, @truckId ,@royaltyNo,@royaltyMT ,@netWeighMT
	select @tripId=max(id) from [VECtblTripdetails]
	
end

if @docId >0
	update [VECtblDocuments] set DCCopy = @dcFile,RoyaltySlip = @royaltySlipFile, LandTWeighBil = @landTFile,TruckId =  @truckId where docId = @docId
else
begin
declare @tNo nvarchar(50)
select @tNo = TripNO from [VECtblTripdetails] where id=@tripId
insert into [VECtblDocuments](TruckId,DCCopy,RoyaltySlip,LandTWeighBil,tripno)
select @truckId, @dcFile, @royaltySlipFile, @landTFile, @tNo
end




end