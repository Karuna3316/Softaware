﻿create proc [dbo].[GetSupplierforedit](@SID int)
as
begin

Select SID, SupplierName,CPName,GstNo,CPNumber,Address from tblfdss_SupplierMaster where SID = @SID

end