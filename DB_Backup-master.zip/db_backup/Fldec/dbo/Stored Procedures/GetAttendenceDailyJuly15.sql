﻿--select CheckInDate from [dbo].[tblAttendance]
--select convert(varchar,getdate(),103)
--select DATEPART(dd, getdate()+1) AS Date
create Procedure [dbo].[GetAttendenceDailyJuly15]
as
begin
declare @tDates table(strDate varchar(50))
declare @sD int, @eD int,@curDay int
--SELECT DAY(EOMONTH(getdate())) AS DaysInMonth
SELECT @curDay = DATENAME(d,getdate());
set @sD = 1
set @eD = @curDay
declare @dateToStartFrMon datetime
set @dateToStartFrMon = getdate()-@curDay
--select @dateToStartFrMon
while @sD <=@eD
begin
insert into @tDates select convert(varchar,@dateToStartFrMon+@sD,103)
set @sD = @sD + 1
end

--select  * from @tDates
   declare @dCols varchar(3000),@eQry nvarchar(max)
 
 set @dCols = STUFF(
 (select ',[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
 
 declare @sCols varchar(max)
 set @sCols = STUFF(
 (select ',case when [' + strDate + ']=0 then ''A'' else ''P'' end as [' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
 

	
--	set @eQry='SELECT [UserName],' + @sCols + '
--FROM (SELECT  
--tU.UserName ,
--       convert(varchar, checkindate,103) as [Days],
--tU.UserName as [Presence]       
--      FROM [tblAttendance] tA
--	  join tblUsers tU on tU.userId = tA.UserID
--       group by UserName,convert(varchar, checkindate,103)) A
--      PIVOT( count(A.Presence)   
--    FOR [Days] IN (' + @dCols +')
--	) AS MNamePivot'

	set @eQry='SELECT [UserName],' + @sCols + '
FROM (SELECT  
tU.UserName ,
       convert(varchar, checkindate,103) as [Days],
Checkin as [Presence]       
      FROM [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
       group by UserName,convert(varchar, checkindate,103),Checkin) A
      PIVOT( count(A.Presence)   
    FOR [Days] IN (' + @dCols +')
	) AS MNamePivot'



	exec(@eQry)

end
--	select * from tblUsers
--	[20/06/2021],[21/06/2021],[22/06/2021],[23/06/2021]
--	select datepart(DW,getdate()-3)
--DECLARE @currentDay DATETIME = GETDATE()-3; -- 3 Apr 2019
--SELECT DATENAME(dw,@currentDay);

	/*select convert(varchar,getdate(),103) from 
	( select getdate() from 1 where getdate() between getdate() -25 and getdate()) a
	

	 --select * from @tDates
--set @eQry='SELECT *
--FROM (SELECT  
--UserID,
--       convert(varchar, checkindate,103) as [Days],
--       UserID [Presence]
--      FROM [tblAttendance]
--       group by UserID,convert(varchar, checkindate,103)) A
--      PIVOT( count(UserID)   
--    FOR [Days] IN (' + @dCols +')
--	) AS MNamePivot'
	*/