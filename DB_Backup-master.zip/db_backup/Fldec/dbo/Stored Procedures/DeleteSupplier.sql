﻿Create proc [dbo].[DeleteSupplier]
(@SID int)
as
begin
delete from tblfdss_SupplierMaster  where SID = @SID
end