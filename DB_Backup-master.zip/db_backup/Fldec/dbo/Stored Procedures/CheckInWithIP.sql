﻿CREATE procedure [dbo].[CheckInWithIP](@userId int, @IPAddress nvarchar(20))
as
begin
if not exists(select attendanceId from tblAAttendance where UserID = @userId and convert(varchar,CheckInDate,103)=convert(varchar,getdate(),103))
begin
insert into [tblAAttendance](UserID,CheckIn,CheckInDate, IPAddress)
select @userId,1,getdate(), @IPAddress
end
end