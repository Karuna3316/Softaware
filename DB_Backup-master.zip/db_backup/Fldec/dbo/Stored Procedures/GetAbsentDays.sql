﻿CREATE proc GetAbsentDays  (@userid int)

As 
begin

select Style103 as Date, [dbo].[fn_DBDay] (TheDate) as DayName  from DateDimension with(nolock) where  TheYear = year(getdate()) and TheMonth = month(getdate()) and Style103  not in (select convert(varchar(12), checkindate, 103) from tblAAttendance with(nolock) where userid = @userid and 
 Year(CheckInDate) = year(getdate()) and month(CheckInDate) = month(getdate())) and Style103 not in (select convert(varchar(12), date, 103) from tbldim with(nolock) where Year(date) = year(getdate()) and month(date) = month(getdate())) and theday <= day(getdate())
order by TheDay


end