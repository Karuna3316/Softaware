﻿CREATE proc [dbo].[PartDescription] (@PartId int)
as
begin

select top 1 Description as Description from InvtblPartNo where PartId = @PartId

end