﻿CREATE proc [dbo].[GetYLR](@usId int,@rName varchar(100))
as
begin
	declare @projId varchar(200)
	select @projId =projId from tblUsers where userId=@usId
if  @rName='Admin' or @rName='Accounts'
begin

with CTE  (sitename, date, engineer, Safety, housekeeping, carpenter, Painter, Pop, plumber,Mason, Helper, Others,Remarks,total)
	as

	(
	select case when ROW_NUMBER()  OVER (Partition by SiteName  ORDER BY LaboureportId ) = 1 then SiteName else '' end as Sitename,  Convert(varchar(12),createddate,103) as date, Isnull(Engineer,0) as Engineer, 
	Isnull(safety,0) as Safety,Isnull(Housekeeping,0) + Isnull(OTHousekeeping,0) as Housekeeping,Isnull(Carpenter,0) as Carpenter,Isnull(Painter,0) as Painter,Isnull(Pop,0) as POP,Isnull(Plumber,0) as Plumber,
Isnull(Mason,0) + Isnull(OTMason,0) as Mason, Isnull(Helper,0) + Isnull(OTHelper,0) as Helper,Isnull(Other,0) as Others, Isnull(Remarks,'') as Remarks,totalManpower as Total from [dbo].[tblLabourReport] where  year = year(getdate())
)
 select * into tempYLR from CTE

	insert into tempYLR (sitename, date, engineer, Safety, housekeeping, carpenter, Painter, Pop, plumber,Mason, Helper, Others,Remarks,total)
	Select 'Total Manpower', * from (
	select '' as [Date],Sum(Isnull(Engineer,0)) as Engineer, Sum(Isnull(safety,0)) as Safety,Sum(Isnull(Housekeeping,0)) as Housekeeping, 
	Sum(Isnull(Carpenter,0)) as Carpenter,Sum(Isnull(Painter,0)) as Painter,Sum(Isnull(Pop,0)) as POP,Sum(Isnull(Plumber,0)) as Plumber,
	Sum(Isnull(Mason,0)) as Mason, Sum(Isnull(Helper,0)) as Helper,Sum(Isnull(Other,0)) as Others,'' as [remarks],Sum(Isnull(totalManpower,0)) as Total 
	from [dbo].[tblLabourReport]where  year = year(getdate())) A
	where A.Total is not null and A.Total > 0
	
	 select * from tempYLR
	 drop table tempYLR


end
else
begin
		
with CTE  (sitename, date, engineer, Safety, housekeeping, carpenter, Painter, Pop, plumber,Mason, Helper, Others,Remarks,total)
	as

	(

		select case when ROW_NUMBER()  OVER (Partition by SiteName  ORDER BY LaboureportId ) = 1 then SiteName else '' end as Sitename, 
		 Convert(varchar(12),createddate,103) as date, Isnull(Engineer,0) as Engineer, Isnull(safety,0) as Safety,
		 Isnull(Housekeeping,0) + Isnull(OTHousekeeping,0) as Housekeeping,Isnull(Carpenter,0) as Carpenter,Isnull(Painter,0) as Painter,
		 Isnull(Pop,0) as POP,Isnull(Plumber,0) as Plumber,Isnull(Mason,0) + Isnull(OTMason,0) as Mason, Isnull(Helper,0) + Isnull(OTHelper,0) as Helper,
		 Isnull(Other,0) as Others, Isnull(Remarks,'') as Remarks,totalManpower as Total from [dbo].[tblLabourReport] 
		 where year = year(getdate()) and SiteName in(select siteName from tblSiteNames where sId in
		  (select item from [dbo].[fnSplitString](@projId,',')))
		  )
		  select * into tempYLR from CTE

	insert into tempYLR (sitename, date, engineer, Safety, housekeeping, carpenter, Painter, Pop, plumber,Mason, Helper, Others,Remarks,total)
	Select 'Total Manpower', * from
	(select '' as [Date], Sum(Isnull(Engineer,0)) as Engineer, Sum(Isnull(safety,0)) as Safety,Sum(Isnull(Housekeeping,0)) as Housekeeping, Sum(Isnull(Carpenter,0)) as Carpenter,Sum(Isnull(Painter,0)) as Painter,Sum(Isnull(Pop,0)) as POP,Sum(Isnull(Plumber,0)) as Plumber,
	Sum(Isnull(Mason,0)) as Mason, Sum(Isnull(Helper,0)) as Helper,Sum(Isnull(Other,0)) as Others,'' as [Remarks],Sum(Isnull(totalManpower,0)) as Total from [dbo].[tblLabourReport]  where year = year(getdate()) and SiteName in(select siteName from tblSiteNames where sId in
		  (select item from [dbo].[fnSplitString](@projId,',')))) A
		  where A.Total is not null and A.Total > 0

		 select * from tempYLR
	 drop table tempYLR

end

end