﻿CREATE proc [dbo].[GetAbsentdaysABD]  

As 
begin

select dbo.fn_username(userid) as EmployeeName from tblUsers where active = 1 and  userid not in  (select userid from tblAAttendance with(nolock) where 
Convert(varchar(12), checkindate, 103) = Convert(varchar(12), getdate(), 103)) and userid not  in (select userid from tblusers with(nolock) where active = 1 and projId is not null)


end