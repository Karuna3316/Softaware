﻿CREATE Procedure [dbo].[GetNotificationlist](@userid int)
AS
BEGIN
select 0 as [Noofopening]
SELECT  NotificationName ,createdDate FROM tblNotification
ORDER BY [NotificationId] DESC; 
end