﻿
--GetStatisticsRegularize 4
CREATE procedure [dbo].[GetStatisticsRegularizeLog](@stDate datetime,@endDate datetime,@userId int,@EmployeeId int = null)
as
begin

set @endDate = @endDate + 1

declare @Total int, @Approved int, @Declined int, @Pending int
if (select roleName from tblRoles where roleId = (select top 1 roleId from tblRoleMapping where userid = @userId))  = 'admin'
begin
if(@EmployeeId > 0)
begin

set @Total = (Select count(*) from [tblReconciliationNew] lR  with(nolock) where (userId = @EmployeeId ) and  lR.CheckIn between @stDate and @endDate)
set @Approved = (Select count(*) from [tblReconciliationNew] lR with(nolock) where (userId = @EmployeeId ) and  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblReconciliationNew] lR with(nolock) where (userId = @EmployeeId ) and  lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblReconciliationNew] lR with(nolock) where (userId = @EmployeeId) and  lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
else
begin

set @Total = (Select count(*) from [tblReconciliationNew] lR  with(nolock) where  lR.CheckIn between @stDate and @endDate )
set @Approved = (Select count(*) from [tblReconciliationNew] lR with(nolock) where  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblReconciliationNew] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblReconciliationNew] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end

end
else
begin
if(@EmployeeId > 0)
begin
set @Total = (Select count(*) from [tblReconciliationNew] lR  with(nolock) where  lR.CheckIn between @stDate and @endDate )
set @Approved = (Select count(*) from [tblReconciliationNew] lR with(nolock) where  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblReconciliationNew] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblReconciliationNew] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
else
begin
set @Total = (Select count(*) from [tblReconciliationNew] lR  with(nolock) where  lR.CheckIn between @stDate and @endDate )
set @Approved = (Select count(*) from [tblReconciliationNew] lR with(nolock) where  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblReconciliationNew] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblReconciliationNew] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
end
end