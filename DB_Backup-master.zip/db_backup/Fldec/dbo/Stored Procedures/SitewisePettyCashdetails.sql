﻿Create proc SitewisePettyCashdetails

As

Begin

select (select [ProjectCode] from tblSiteNames where sid = SiteId) as [Project Code],
 (select shortNameFrSite from tblSiteNames where sid = SiteId) as [Site Name], Sum(DebitAmount) as [Expense Amount] 
 from [dbo].[tblPettyCashNew] 
 where SiteID is not null 
 group by SiteID 
 order by [Project Code]

 end