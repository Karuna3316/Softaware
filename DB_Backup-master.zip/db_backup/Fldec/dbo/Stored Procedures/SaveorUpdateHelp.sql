﻿
CREATE procedure [dbo].[SaveorUpdateHelp] (@HelpId int,@HelpmenuId int,@Document NVARCHAR(MAX))
as
begin

if(@HelpId > 0)
begin
update tblhelp set HelpmenuId=@HelpmenuId,Document=@Document,UpdatedDate = getdate() where HelpId = @HelpId
select 2
end
else
begin

if not exists (select HelpId from tblhelp with (nolock) where HelpId=@HelpId)
begin
	insert into tblhelp(HelpmenuId, Document,createddate)
	select @HelpmenuId,@Document,Getdate()
	Select 1
end
else
begin
Select 3
	end

end

end