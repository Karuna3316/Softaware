﻿


CREATE procedure [dbo].[GetNewRegularizationDataADB]
as
begin

--select top 50 * from tblReconciliationNew 

Declare @Total int, @Approved int, @Declined int, @Pending int

select @Total = count(*) from tblReconciliationNew where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) 
select @Approved = count(*) from tblReconciliationNew where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) and status = 1
select @Declined = count(*) from tblReconciliationNew where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) and status = 2
select @Pending = count(*) from tblReconciliationNew where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) and status = 0

Select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending


end