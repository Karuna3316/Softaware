﻿CREATE proc GetLatecheckin   (@userid int)

As 
begin

(select Convert(varchar(12), Checkindate, 103) as Date, CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0) as Time from tblAAttendance with(nolock) where userid = @userId and year(checkindate) = year(getdate()) and  month(checkindate) = month(getdate()) and checkin =1  and 
((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51)  or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) >=0 ) or  (DATEPART(hour, CheckInDate) = 11 and   DATEPART(MINUTE, CheckInDate) >=0 )) and ( DATEPART(hour, CheckInDate) <= 12))




end