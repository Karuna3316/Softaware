﻿
--[dbo].[GetLeaveRequestforAdmin] '2022-11-02','2022-10-28', 2, 'Employee'

CREATE procedure [dbo].[GetLeaveLogforAdminLogWP]  (@stDate datetime ,@endDate datetime , @EmployeeId int = null)
as
BEGIN

if(@stDate > 0 and @endDate >0 and @EmployeeId >0)
begin
select  reqLId,
userId,
[dbo].[fn_username](userId) as EmployeeName,
[dbo].[fn_Dropdown](leaveType) as LeaveMode,
[dbo].[fn_Dropdown](leaveDaysType) as NoofDays,
[dbo].[fn_Dropdown](leaveCategory) as Leavetype,
[dbo].[fn_username](reportingTo) as ReportingUser,
convert(varchar(12),leaveStartedOn,103) as StartDate, 
Convert(varchar(12), leaveEndsOn,103) as EndDate,
isApproved,reason
from [tblRequestLeave]  where userid = @EmployeeId  and convert(varchar(10),leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),leaveStartedOn,101) <= convert(varchar(10),@endDate,101)
order by  leaveStartedOn 
end
if(@stDate > 0 and @endDate >0)
begin
select reqLId,
userId,
[dbo].[fn_username](userId) as EmployeeName,
[dbo].[fn_Dropdown](leaveType) as LeaveMode,
[dbo].[fn_Dropdown](leaveDaysType) as NoofDays,
[dbo].[fn_Dropdown](leaveCategory) as Leavetype,
[dbo].[fn_username](reportingTo) as ReportingUser,
convert(varchar(12),leaveStartedOn,103) as StartDate, 
Convert(varchar(12), leaveEndsOn,103) as EndDate,
isApproved,reason
from [tblRequestLeave]  where convert(varchar(10),leaveStartedOn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),leaveStartedOn,101) <= convert(varchar(10),@endDate,101)
order by  leaveStartedOn 
end

END