﻿Create procedure [dbo].[GetDrpLeaveMode]
as
begin
select Id , Description  from tblDropdown where Dropdowntype = 'LeaveMode'
end