﻿--[GetAssets] 'Admin'
CREATE proc [dbo].[GetAssets](@rName varchar(100))
as
Begin

select assestcode, assestname, Convert(varchar(12),purchasedate,103) as Purchasedate,
dbo.fn_sitename(siteid) as sitename, dbo.fn_username(userid) as username from tblassest  order by assestcode

end
--select * from tblassest

--select dbo.fn_username(25)