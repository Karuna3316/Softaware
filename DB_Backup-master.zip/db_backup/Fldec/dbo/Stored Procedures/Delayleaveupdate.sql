﻿CREATE proc [dbo].[Delayleaveupdate]
AS
begin



update tblAttendance set DelayLeave = 0 where month(checkindate) = month(getdate()) and checkin =1  and Convert(varchar(10), datediff(minute, convert(varchar(10),Checkindate,121)+' 09:45:00.000', Checkindate)) <= 0
update tblAttendance set DelayLeave = 1 where month(checkindate) = month(getdate()) and checkin =1  and Convert(varchar(10), datediff(minute, convert(varchar(10),Checkindate,121)+' 09:45:00.000', Checkindate)) > 1

end