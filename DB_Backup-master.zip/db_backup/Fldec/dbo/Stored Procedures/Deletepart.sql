﻿CREATE proc [dbo].[Deletepart]
(@PartId int)
as
begin
delete from InvtblPartNo where PartId = @PartId
end