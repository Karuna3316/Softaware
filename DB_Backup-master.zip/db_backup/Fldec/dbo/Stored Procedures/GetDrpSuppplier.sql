﻿CREATE procedure [dbo].[GetDrpSuppplier]
as
begin
select SID,SupplierName  from tblfdss_SupplierMaster
end