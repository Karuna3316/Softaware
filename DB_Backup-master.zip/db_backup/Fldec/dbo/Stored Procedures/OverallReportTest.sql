﻿CREATE proc [dbo].[OverallReportTest]-- 2
@Siteid int

as

begin



WITH expression_name(PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,[Pending Billable Supply], SignedOffJMR, SignedOffDC,SignvsbillJMR)   

AS   

(   

  

select SLNO, dbo.fn_Description(Slno), Quantity, Unit,isnull(dbo.fn_BilledDC(slno),0), isnull(dbo.fn_BilledJMR(slno),0), Isnull(convert(decimal(18,2),dbo.fn_BilledDC(slno)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno)),0)  
,  isnull(dbo.fn_SignedOffJMR(slno),0), isnull([dbo].[fn_SignedOffDC](slno),0),Isnull(convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno)),0)

from tblShortBOQ where SiteId = @Siteid and Slno <> 1000 --and Quantity <> 0 

 )  



 --select PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,SignedOffJMR,SignedOffDC,ABS([Pending Billable Supply]) As [Billable Supply], abs(SignvsbillJMR) as [Billable installation]from expression_name 

 --select PONo, Description, BOQQty, Unit,BilledJMR, case when BilledJMR > BOQQty then BilledJMR - BOQQty else 0 end as MorethanBoqqty from expression_name  where BilledJMR - BOQQty  >0
  select PONo, Description, BOQQty, Unit,BilledJMR,SignedoffJmr, case when SignedOffJMR > BOQQty then SignedOffJMR - BOQQty else 0 end as AmendmentQty from expression_name  where SignedOffJMR - BOQQty  >0

 end

 --147	Lacquered Glass	146.00	SQMT	1.00
-- 11	Grade M30 SCON	20.00	M3	5.49
--29	20mm dia Hilti Bolt	8.00	NOS	4.00
--137	Cell Ceiling	327.00	SQMT	2.09