﻿CREATE proc [dbo].[ReminderMeeting]
as
begin
DECLARE @Result AS NVARCHAR(MAX)   
DECLARE @colsIS AS NVARCHAR(MAX)        
  
  Set @colsIS = '*_Meeting Reminder_*' 
     
 select @colsIS = @colsIS + STUFF(  (SELECT  ',  (' + convert(varchar(12),Date,103) + ' - ' +  Description  + ' ) '      
 from tblMeetings  where   convert(varchar(12),Date,103) = convert(varchar(12),getdate() + 1,103)
        
 FOR XML PATH('')),1,1,'')

 if @colsIS is not null
 set @Result = @colsIS

 if  @Result is not null
 begin
 insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('919962222745',@colsIS,1,getdate())
 insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('919884340231',@colsIS,1,getdate())
 insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('919940544644',@colsIS,1,getdate())
 insert into  [dbo].[tblMobileNos] (mobileNo, msg,active,createdDate) values('917010633708',@colsIS,1,getdate())
   end


   end