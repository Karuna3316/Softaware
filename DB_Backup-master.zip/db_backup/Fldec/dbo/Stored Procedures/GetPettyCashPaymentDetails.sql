﻿CREATE proc [dbo].[GetPettyCashPaymentDetails] (@uId int, @role varchar(100))
as
begin
if @role='admin'
select  U.userId, Username, CreditAmount,P.Createddate from [dbo].[tblPettyCashNew] P
inner join tblUsers U
on P.UserID = U.userId where CreditAmount is not null and CreditAmount <> 0 and PettyCashID not in (12,17,18,20,22,23,24,28)
Order by P.Createddate desc
else
select  U.userId, Username, CreditAmount,P.Createddate from [dbo].[tblPettyCashNew] P
inner join tblUsers U
on P.UserID = U.userId where P.UserID = @uId and CreditAmount is not null and CreditAmount <> 0 and PettyCashID not in (12,17,18,20,22,23,24,28)
Order by P.Createddate desc

end