﻿--GetWorkTimingsFrAMonth 7



--[GetWorkTimingsFrAMonth] 6
CREATE procedure [dbo].[GetWorkTimingsFrAMonth](@mon int)

as

begin

select dbo.fn_username(userid) as [ Employee Name ],  format(CheckInDate,'dd-MMM-yyyy') as [ Check In Date ],
FORMAT(CheckinDate,'hh:mm tt') as [ Check In Time ],
FORMAT(checkoutdate,'hh:mm tt') as [ Check Out Time ],
convert(varchar,DATEDIFF(MINUTE,  convert(datetime,convert(time,'9:30')),cast(CheckinDate as time)) ) [ Late Coming ],
convert(varchar,DATEDIFF(MINUTE, cast(checkoutdate as time), convert(datetime,convert(time,'19:30')))) [ Before Leaving ],

 case when reason is not null then reason else '' end as [ Remarks ]
  from [dbo].[tblAttendance] where 
  UserID in ( select userId from tblUsers where isoffice = 0) and 
  month(checkindate)=@mon and checkin = 1 
  order by UserID, CheckInDate

 end