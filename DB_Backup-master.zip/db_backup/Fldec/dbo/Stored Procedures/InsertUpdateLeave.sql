﻿CREATE procedure [dbo].[InsertUpdateLeave](@lBId int,@CasualLeave int,@SickLeave int,@Userid int)
as
begin

if @lBId >0
begin
update [tblLeaveBalanceMaster] set UserId = @Userid,CasualLeave=@CasualLeave,SickLeave=@SickLeave
 where lBId=@lBId
end
else
begin
	insert into [tblLeaveBalanceMaster](year, userid,CasualLeave,SickLeave)
	select year(getdate()),@Userid,@CasualLeave,@SickLeave


	select @lBId=max(lBId) from [tblLeaveBalanceMaster]
	
end

end