﻿CREATE procedure [dbo].[GetLabourADayReport]
as
begin

Declare     @siteTot decimal(18,2),
            @sitename nvarchar(350),
            @total decimal(18,2),
			@labourRptMsg nvarchar(2000)
set @labourRptMsg = ''
set @siteTot =0
set @total =0

Declare curP cursor For

select sum(isnull(Engineer,0)) + sum(isnull(Safety,0)) + sum(isnull(Housekeeping,0)) + sum(isnull(Carpenter,0)) + sum(isnull( Painter,0)) + sum(isnull(Pop,0)) + sum(isnull(Plumber,0)) + sum(isnull(Mason,0)) + sum(isnull(Helper,0)) + sum(isnull(Other,0)) + sum(isnull(OTMason,0)) + sum(isnull(OTHelper,0)) 
+ sum(isnull(OTHousekeeping,0)) as sTot,
case SiteName 
when 'Iopex 4th floor' then '_Iopex_'
when 'Krish Banquet Hall ECR' then '_Krish_'
when 'Kewaunee Pfizer' then '_Pfizer_'
when 'Stelis Bio Pharma Bangalo' then '_Stelis_'
when 'SVPHC - THANJAVUR' then '_SVPHC_'
when 'Laurus kewaunee vizag' then '_Laurus_'
when 'Prodapt' then '_Prodapt_'
when 'L & W Shriram GOP' then '_L and W Shriram GOP_'
else  SiteName end as SiteName
from tbllabourreport
where convert(varchar,Createddate,103) =  convert(varchar,getdate(),103)
group by SiteName

OPEN curP 
Fetch Next From curP Into @siteTot, @sitename
While @@Fetch_Status = 0 Begin  
set @labourRptMsg =@labourRptMsg + ' ' + @sitename + ' - *_' + convert(varchar,@siteTot) + '_*,'
set @total += @siteTot    
Fetch Next From curP Into @siteTot, @sitename
End -- End of Fetch
Close curP
Deallocate curP

Declare @name as varchar(2000)= @labourRptMsg
set @labourRptMsg = left(@name, len(@name)-1) 


Declare @result varchar(2000)
--Set @result = (select '*Manpower details of all the sites*  ( ' + @labourRptMsg + ' ) *Total*'  + ' - *' + convert(varchar,@total) as resM) +'*'
Set @result = (select '*Total Manpowers in all the Sites*'  + ' - *' + convert(varchar,@total) as resM) +'*  + ( ' + @labourRptMsg + ' )' 

Declare @Details varchar(2000) = (select '*_Engineer_* - '+Convert(varchar(10),sum(isnull(Engineer,0))) +
', _*Safety*_ - '+Convert(varchar(10),sum(isnull(Safety,0))) +
', _*Housekeeping*_ - '+Convert(varchar(10),sum(isnull(Housekeeping,0))) +
', _*Painter*_ - '+Convert(varchar(10),sum(isnull(Painter,0))) +
', _*Carpenter*_ - '+Convert(varchar(10),sum(isnull(Carpenter,0))) +
', _*Pop*_ - '+Convert(varchar(10),sum(isnull(Pop,0))) +
', _*Plumber*_ - '+Convert(varchar(10),sum(isnull(Plumber,0))) +
', _*Mason*_ - '+Convert(varchar(10),sum(isnull(Mason,0))) +
', _*Helper*_ - '+Convert(varchar(10),sum(isnull(Helper,0))) 
from tbllabourreport
where convert(varchar,Createddate,103) =  convert(varchar,getdate(),103))



Declare @Remarks varchar(300) =  STUFF((select ', ' + remarks  
 from tbllabourreport  where convert(varchar,Createddate,103) =  convert(varchar,getdate(),103)   and remarks is not null and Remarks <> ''
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
  

  set @result += '                        '+'```Details -```' + '( '+  @Details +', '+@Remarks + ')'
insert into [tblMobileNos] ([mobileNo], [msg], [active], [createdDate]) values ('919962222745', @result, 1, GETDATE())
--insert into [tblMobileNos] ([mobileNo], [msg], [active], [createdDate]) values ('918939746695', @result, 1, GETDATE())
end

--select * from [dbo].[tblMobileNos] order by createddate desc

--delete from  [dbo].[tblMobileNos]