﻿CREATE proc [dbo].[InvDescription] (@Partno nvarchar(150))
as
begin
--select top 1 Desciption as Description from [dbo].[InvInwardRegister] where PartNo = (select dbo.fn_PartNo(@Partno))
select top 1  Quantity, Description from 
	(select (select sum(Quantity) from [dbo].[InvInwardRegister] II where II.InventoryId = I.InventoryId) -  (select sum(Qty) from [dbo].InvOutwardRegister OO where OO.InventoryId = I.InventoryId) as Quantity
,I.Desciption as Description	from [dbo].[InvInwardRegister] I inner join 
[dbo].[InvOutwardRegister] O on O.InventoryId = I.InventoryId where  PartNo = (select dbo.fn_PartNo(@Partno)) group by PartNo,I.InventoryId,Desciption ) as test

--select top 1 Desciption as Description,Quantity from InvInwardRegister where PartId=@PartId

end