﻿CREATE proc [dbo].[GetLeaveBenefitforedit](@LBId int)
as
begin

Select LBId, FORMAT (CreatedDate, 'yyyy-MM-dd') as Date, UserId, dbo.fn_username(userid) as EmployeeName from tblLeaveBalanceMaster where LBId = @LBId

end