﻿CREATE proc [dbo].[GetLocationList]
as
begin
Select MasterID,Description as Location ,MasterType,[dbo].[fn_username](CreatedBy) as  CreatedBy,case when UpdatedBy is null then  createddate  else   UpdatedDate  end as createddate from tblfdss_Master where MasterType='Location' order by createddate desc


end