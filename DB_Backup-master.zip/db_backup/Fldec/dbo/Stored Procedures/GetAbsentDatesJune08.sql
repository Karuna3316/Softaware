﻿
create procedure [dbo].[GetAbsentDatesJune08](@userId int)
as
begin
declare @tDates table(strDate date)
declare @stDate datetime, @endDate datetime

select @endDate =  getdate()
select  @stDate = DATEADD(m, DATEDIFF(m, 0, GETDATE()), 0) --convert(datetime,DATEADD(MONTH,-1,GETDATE()))

while @stDate <=@endDate
begin
insert into @tDates select CONVERT(date,@stDate)
set @stDate = @stDate + 1
end

select strDate from @tDates where strdate not in 
(select CONVERT(date,CheckInDate) from tblAAttendance where userid=@userId and CheckInDate > DATEADD(MONTH,-1,GETDATE()))
end