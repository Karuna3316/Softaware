﻿CREATE proc [dbo].[GetBOM] (@ProjectID int)
as
begin
	
select Item, Quantity, value as ValueB, reference as ReferenceB, PartNo, Manufacturer, pcbfootprint, Description from INVtblBOMS where ProjectId = @ProjectID

end

--select * from INVtblBOMS