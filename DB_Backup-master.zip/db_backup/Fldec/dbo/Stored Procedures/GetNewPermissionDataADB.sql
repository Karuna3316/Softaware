﻿


CREATE procedure [dbo].[GetNewPermissionDataADB]
as
begin

--select top 50 * from tblPermission order by pid desc

Declare @Total int, @Approved int, @Declined int, @Pending int

select @Total = count(*) from tblPermission with(nolock) where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) 
select @Approved = count(*) from tblPermission with(nolock) where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) and status = 1
select @Declined = count(*) from tblPermission with(nolock) where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) and status = 2
select @Pending = count(*) from tblPermission with(nolock) where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) and status = 0

Select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending


end