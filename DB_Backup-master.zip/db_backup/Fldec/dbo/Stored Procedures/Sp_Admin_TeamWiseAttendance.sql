﻿CREATE proc [dbo].[Sp_Admin_TeamWiseAttendance]
as
begin
select  1 as TeamId, 'Software' as Team, '2' as NoOfPersons, 1 as NoOfPresents, 1 as NoOfAbsents, 0 as NoOfCheckins
union
select  2 as TeamId,'Network' as Team, '2' as NoOfPersons, 1 as NoOfPresents, 1 as NoOfAbsents, 0 as NoOfCheckins
end