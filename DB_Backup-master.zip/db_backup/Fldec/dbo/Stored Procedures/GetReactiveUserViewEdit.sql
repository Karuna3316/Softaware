﻿CREATE procedure [dbo].[GetReactiveUserViewEdit] (@userId int)
as
begin
 select userId,UserName,Designation,Convert(varchar(12), ResignationDate, 103) as ResignationDate from tblUsers where userId= @userId

 end