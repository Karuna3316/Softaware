﻿CREATE procedure GetUnloadingAt
as
begin
select ClientId as cId, ClientName as cVal from [dbo].[VECtblClient] 
union
select '0' as cId,'select' as cVal
end