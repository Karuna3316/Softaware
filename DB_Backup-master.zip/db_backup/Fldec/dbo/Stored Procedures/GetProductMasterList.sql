﻿CREATE procedure [dbo].[GetProductMasterList]
as
begin
  select ProductsID,[dbo].[fn_fdssMaster](MakeId) as MakeId,[dbo].[fn_suppliername](SupplierId) as SupplierId,ProductsName,Size,Hsn,LPrice,MinQty,
case when Updatedby is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(Updatedby) end as CreatedBy,
case when Updatedby is null then CreatedDate  else  UpdatedDate  end as UpdatedDate
from tblfdss_ProductsMaster order by UpdatedDate desc
end