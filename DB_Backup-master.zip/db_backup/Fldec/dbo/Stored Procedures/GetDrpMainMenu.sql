﻿CREATE procedure [dbo].[GetDrpMainMenu]
as
begin
SELECT parentId as MMID,SUBSTRING(menu, CHARINDEX('</i>', menu) + 5, LEN(menu) - CHARINDEX('</i>', menu) - 4) AS MMName FROM tblmenus WHERE isMainMenu = 1;
end