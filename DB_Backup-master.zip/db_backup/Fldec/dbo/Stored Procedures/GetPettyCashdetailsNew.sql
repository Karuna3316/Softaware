﻿CREATE proc [dbo].[GetPettyCashdetailsNew](@uId int, @role varchar(100))
as
begin
if(@role ='admin')
begin
	WITH expression_name(UserID, Creditamount, ExpenseAmount) 
	AS 
	(
	select P.userId, isnull(sum(CreditAmount),0) -   (select Isnull(Sum(DebitAmount),0) from [dbo].[tblPettyCashNew] where 
	Status in (4) and UserID = P.UserID), Isnull(Sum(DebitAmount),0) from [dbo].[tblPettyCashNew] P 
	inner join tblusers U 
	on P.Userid = U.Userid and ( P.Status  =2  or P.Status is null)
	group by  P.UserID
	 )

	 select U.userId, UserName,Creditamount, ExpenseAmount , (Creditamount-ExpenseAmount ) as [AvailableBalance]from expression_name E
 inner join [dbo].[tblUsers] U
 on U.userId = E.UserID where Creditamount <> 0 
 order by U.UserID
end
else
begin
	WITH expression_name(UserID, Creditamount, ExpenseAmount) 
	AS 
	(
	select P.userId, isnull(sum(CreditAmount),0) -   (select Isnull(Sum(DebitAmount),0) from [dbo].[tblPettyCashNew] where 
	Status in (4) and UserID = P.UserID), Isnull(Sum(DebitAmount),0) from [dbo].[tblPettyCashNew] P 
	inner join tblusers U 
	on P.Userid = U.Userid and ( P.Status  =2  or P.Status is null)
	where p.UserID = @uId
	group by  P.UserID
	 )

	 select U.userId, UserName,Creditamount, ExpenseAmount , (Creditamount-ExpenseAmount ) as [AvailableBalance]from expression_name E
 inner join [dbo].[tblUsers] U
 on U.userId = E.UserID where Creditamount <> 0 
 --order by U.UserID

end

 



 end