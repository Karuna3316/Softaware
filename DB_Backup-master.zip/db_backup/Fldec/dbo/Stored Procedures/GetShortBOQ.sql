﻿CREATE proc [dbo].[GetShortBOQ](@usId int,@rName varchar(100))
as
Begin
	if  @rName='Admin'
	begin
		select 
	(select SiteName from tblSiteNames where sId = siteId) as sN , SLNO as [BOQNo], Description, Quantity,Unit 
	from [tblShortBOQ] 
	end
	else
	begin
	
		declare @projId varchar(200)
		select @projId =projId from tblUsers where userId=@usId
	select 
	(select SiteName from tblSiteNames where sId = siteId) as sN , SLNO as [BOQNo], Description, Quantity,Unit 
	from [tblShortBOQ] where siteId in (select item from [dbo].[fnSplitString](@projId,','))
	end
End