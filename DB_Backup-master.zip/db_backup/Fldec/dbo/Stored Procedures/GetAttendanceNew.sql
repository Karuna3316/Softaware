﻿
CREATE Procedure [dbo].[GetAttendanceNew] 

as

begin

select 31 as [Noofworkingdays]
 
end