﻿CREATE proc [dbo].[Sp_EmployeeView]  (@userId int)
as
begin

select EMPID ,userId, UserName as EmployeeName ,DesignationId,dbo.fn_Designation(DesignationId) as Designation,TeamId,dbo.fn_Team(TeamId) as Team,
[dbo].[fn_Role](userid) as Role , Mobile,EmailId,DOJ,DOB,MaritalStatus,PersornalEmailId,Phone,PermanentAddress,TemporaryAddress,
PANNo,UANNo,PFNO,WorkStationFloor,TenuredorFresher,EduQualification,CertificateNo,YearOfPassing,BankAccNo,BankBranchName,BankIFSCCode,PreviousEmployement,PreEmployDOE,EmergContactName,EmergContactNo,
Relationship,BloodGroup,
case when dbo.fn_Designation(DesignationId) is null then 'NA'  else  dbo.fn_Designation(DesignationId) end as [Designation],
case when Mobile is null then 'NA' else Mobile end as [Mobile Number],
case when EmailId is null then 'NA' else EmailId end as [Official E-Mail ID],
case when dbo.fn_Team(TeamId) is null then 'NA'  else dbo.fn_Team(TeamId) end as [Team],
case when DOJ is null then 'NA' else Convert(varchar(12), DOJ,103) end as [Date Of Joining],
case when DOB is null then 'NA' else Convert(varchar(12), DOB,103) end as [Date Of Birth],
case when Age is null then '0' else Age end as Age,
case when MaritalStatus = 1 then 'Single' when MaritalStatus = 2 then 'Married' end as [Martial Status],
case when PersornalEmailId is null then 'NA' else PersornalEmailId end as [Personal E-Mail ID],
case when Phone is null then 'NA' else Phone end as [Personal Number],
case when PermanentAddress is null then 'NA' else PermanentAddress end as [Permanent Address],
case when TemporaryAddress is null then 'NA' else TemporaryAddress end as [City],

case when PANNo is null then 'NA' else PANNo end as [PAN No],
case when UANNo is null then 'NA' else UANNo end as [UAN No],
case when PFNO is null then 'NA' else PFNO end as [PF NO],
case when WorkStationFloor is null then 'NA' else WorkStationFloor end as [Work Station Floor],
case when TenuredorFresher = 1 then 'Tenured' when TenuredorFresher = 2 then 'Fresher' else 'NA' end as [Tenured / Fresher],
case when EduQualification is null then 'NA' else EduQualification end as [Education Qualification],
case when CertificateNo is null then 'NA' else CertificateNo end as [Certificate No],
case when YearOfPassing is null then 'NA' else YearOfPassing end as [Year Of Passing],
case when BankAccNo is null then 'NA' else BankAccNo end as [Bank A/C No],
case when BankBranchName is null then 'NA' else BankBranchName end as [Bank Branch Name],
case when BankIFSCCode is null then 'NA' else BankIFSCCode end as [Bank IFSC Code],
case when PreviousEmployement is null then 'NA' else PreviousEmployement end as [Previous Employement],
case when dbo.fn_Designation(DesignationId) is null then 'NA'  else  dbo.fn_Designation(DesignationId) end as [Designation],
case when PreEmployDOE is null then 'NA' else Convert(varchar(12), PreEmployDOE,103) end as [Previous Employeement DOE],
case when EmergContactName is null then 'NA' else EmergContactName end as [Emergency Contact Name],
case when EmergContactNo is null then 'NA' else EmergContactNo end as [Emergency Contact No],
case when Relationship is null then 'NA' else Relationship end as [Relation ship],
case when BloodGroup is null then 'NA' else BloodGroup end as [Blood Group]

 from tblUsers with(nolock) where  userId = @userId

 end