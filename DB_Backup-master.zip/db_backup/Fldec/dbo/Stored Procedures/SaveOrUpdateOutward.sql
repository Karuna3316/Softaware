﻿CREATE procedure [dbo].[SaveOrUpdateOutward](  @OutwardId int, @CustomerId int,@OutwardTypeId int,@ProductsId nvarchar(max),@OutwardedQty nvarchar(max) ,@userId int)

as
begin

if(@OutwardId > 0)
begin
update tblfdss_Outward set CustomerId = @CustomerId, OutwardTypeId= @OutwardTypeId, UpdatedDate=GETDATE(),Updatedby=@userId where OutwardId =@OutwardId

select 2

IF @ProductsId IS NOT NULL AND LEN(@ProductsId) > 0
BEGIN TRY
    BEGIN TRAN 

DELETE FROM [tblfdss_OutwardProducts] WITH (TABLOCK) WHERE OutwardId= @OutwardId

INSERT INTO tblfdss_OutwardProducts WITH (TABLOCK) (OutwardId,CreatedDate,CreatedBy,OutwardedQty,ProductsId)
SELECT @OutwardId, GETDATE(),@userId,s.Item,t.Item 
FROM dbo.fnSplitString(@OutwardedQty, ',') s
JOIN dbo.fnSplitString(@ProductsId, ',') t ON s.ID = t.ID;
COMMIT TRAN 
END TRY
BEGIN CATCH
    ROLLBACK TRAN 
END CATCH

end

else
begin
if not exists (select OutwardId from tblfdss_Outward where OutwardId =@OutwardId )
begin
	insert into [tblfdss_Outward]( CustomerId, OutwardTypeId,CreatedDate,Createdby)
	select @CustomerId, @OutwardTypeId, GETDATE(),@userId
	Select 1


	DECLARE @OutwId int
   SET @OutwId = SCOPE_IDENTITY()

   if @ProductsId is not null and len(@ProductsId)>0
begin
	insert into [tblfdss_OutwardProducts](OutwardId,CreatedDate,CreatedBy,OutwardedQty,ProductsId)
	select @OutwId,GETDATE(),@userId,

    n.Item AS OutwardedQty,
	t.Item AS ProductsId
FROM dbo.fnSplitString(@OutwardedQty, ',') n

JOIN dbo.fnSplitString(@ProductsId, ',') t ON n.ID = t.ID;
	
	end
	end


else
begin
Select 3

end

end
end

--select * from tblfdss_Outward
--select * from tblfdss_OutwardProducts