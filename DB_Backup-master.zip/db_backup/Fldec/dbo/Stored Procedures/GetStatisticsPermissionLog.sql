﻿/*

Select * from [tblPermission] lR  with(nolock)
Select count(*) from [tblPermission] lR  with(nolock) where  convert(varchar(10),lR.CheckIn,101) >= convert(varchar(10),'2022-10-01 00:00:00.000',101)
	and convert(varchar(10),lR.CheckIn,101) <= convert(varchar(10),'2022-12-31 00:00:00.000',101) 

*/

--GetStatisticsPermissionLog '2022-10-01','2022-12-31',1, null

--Select count(*) from [tblPermission] lR  with(nolock) where (userId = @EmployeeId ) and  lR.CheckIn between @stDate and @endDate

CREATE procedure [dbo].[GetStatisticsPermissionLog](@stDate datetime,@endDate datetime,@userId int,@EmployeeId int = null)
as
begin

set @endDate = @endDate + 1

declare @Total int, @Approved int, @Declined int, @Pending int
if (select roleName from tblRoles where roleId = (select top 1 roleId from tblRoleMapping where userid = @userId))  = 'admin'
begin
if(@EmployeeId > 0)
begin

set @Total = (Select count(*) from [tblPermission] lR  with(nolock) where (userId = @EmployeeId ) and  lR.CheckIn between @stDate and @endDate)
set @Approved = (Select count(*) from [tblPermission] lR with(nolock) where (userId = @EmployeeId ) and  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblPermission] lR with(nolock) where (userId = @EmployeeId ) and  lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblPermission] lR with(nolock) where (userId = @EmployeeId) and  lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
else
begin

set @Total = (Select count(*) from [tblPermission] lR  with(nolock) where  lR.CheckIn between @stDate and @endDate )
set @Approved = (Select count(*) from [tblPermission] lR with(nolock) where  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblPermission] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblPermission] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end

end
else
begin
if(@EmployeeId > 0)
begin
set @Total = (Select count(*) from [tblPermission] lR  with(nolock) where  lR.CheckIn between @stDate and @endDate )
set @Approved = (Select count(*) from [tblPermission] lR with(nolock) where  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblPermission] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblPermission] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
else
begin
set @Total = (Select count(*) from [tblPermission] lR  with(nolock) where  lR.CheckIn between @stDate and @endDate )
set @Approved = (Select count(*) from [tblPermission] lR with(nolock) where  lR.CheckIn between @stDate and @endDate and status = 1 )
set @Declined = (Select count(*) from [tblPermission] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 2)
set @Pending = (Select count(*) from [tblPermission] lR with(nolock) where   lR.CheckIn between @stDate and @endDate and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
end
end