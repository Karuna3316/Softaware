﻿
--GetStatisticsRegularize 4
CREATE procedure [dbo].[GetStatisticsPermission](@userId int)
as
begin
declare @Total int, @Approved int, @Declined int, @Pending int
if (select roleName from tblRoles where roleId = (select top 1 roleId from tblRoleMapping where userid = @userId))  <> 'admin'
begin


set @Total = (Select count(*) from tblPermission with(nolock) where (userId = @userId or reportingTo = @userId) and year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate())  )
set @Approved = (Select count(*) from tblPermission with(nolock) where (userId = @userId or reportingTo = @userId) and year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate()) and status = 1 )
set @Declined = (Select count(*) from tblPermission with(nolock) where (userId = @userId or reportingTo = @userId) and year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate()) and status = 2)
set @Pending = (Select count(*) from tblPermission with(nolock) where (userId = @userId or reportingTo = @userId) and year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate()) and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending, 'employee' as Role
end
else
begin
set @Total = (Select count(*) from tblPermission with(nolock) where (userId = @userId or reportingTo = @userId) and  year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate())  )
set @Approved = (Select count(*) from tblPermission with(nolock) where (userId = @userId or reportingTo = @userId) and year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate()) and status = 1 )
set @Declined = (Select count(*) from tblPermission with(nolock) where (userId = @userId or reportingTo = @userId) and  year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate()) and status = 2)
set @Pending = (Select count(*) from tblPermission with(nolock) where  (userId = @userId or reportingTo = @userId) and year(CheckIn)= year(getdate()) and month(CheckIn) = month(getdate()) and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending, 'admin' as Role
end
end