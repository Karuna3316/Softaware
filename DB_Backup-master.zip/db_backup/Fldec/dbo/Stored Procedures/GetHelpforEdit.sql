﻿CREATE proc [dbo].[GetHelpforEdit](@HelpId int)
as
begin

select HelpId,HelpmenuId,dbo.fn_Help(HelpmenuId) as Description,Document  from tblhelp where HelpId=@HelpId

end