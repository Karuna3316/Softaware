﻿
CREATE procedure [dbo].[SaveOrUpdateHolidays] (@Date datetime,  @Description nvarchar(2000), @DimId int)
as
begin

if(@DimId > 0)
begin
update tblDim set date = @Date, Description = @Description where DimId = @DimId

select 2
end
else
begin
if not exists (select dimid from tblDim with (nolock) where convert(varchar(12), date, 103) = convert(varchar(12), @Date, 103))
begin
	insert into [tblDim](Date, Description)
	select @Date,@Description
	Select 1
	end
	else
	Select 3

	end

end