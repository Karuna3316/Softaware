﻿CREATE proc [dbo].[Sp_Admin_Leave_Pendings]
as
begin


select UPPER(UserName) as EmployeeName, [dbo].[fn_LeavePendingCount](userId) as Count  from tblUsers with (nolock) where isTeamLead = 1 order by [dbo].[fn_LeavePendingCount](userId) desc

end