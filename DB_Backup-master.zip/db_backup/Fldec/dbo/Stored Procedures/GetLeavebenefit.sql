﻿CREATE procedure [dbo].[GetLeavebenefit]
AS
begin  
select UserId as EmployeeId , Year, CreatedDate  from tblLeaveBalanceMaster 

end