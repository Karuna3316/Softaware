﻿CREATE procedure [dbo].[GetInvoiceList]
AS
begin  

SELECT InvoiceId, dbo.fn_SupplierName(SupplierId) as SupplierName, dbo.fn_PONumber(PONumberId) as PONumberId ,InvoiceNo, 
CONVERT(varchar(12), InvoiceDate, 103) AS InvoiceDate,(Igst+Cgst+Sgst+GVInvoice) as total,FileName, 
case when UpdatedBy is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(UpdatedBy) end as CreatedBy,case when UpdatedBy is null then  createddate  else   UpdatedDate  end as createddate 
from tblfdss_Invoice order by createddate desc

end