﻿CREATE Procedure [dbo].[GetCreditedPettyCash](@usId int)
as
begin
declare @roleN varchar(200)
select  @roleN= roleName from tblRoles tR
where roleId in (select roleId from tblrolemapping where userId=@usId)

if @roleN = 'Accounts' or @roleN='Admin'
begin
select tU.UserName, tPCM.CreditedAmount
 from [dbo].[tblPettyCashMasterNew] tPCM
join tblUsers tU on tU.userId = tPCM.UserID
order by tPCM.Createddate desc
end
else
begin
select tU.UserName, tPCM.CreditedAmount
 from [dbo].[tblPettyCashMasterNew] tPCM
join tblUsers tU on tU.userId = tPCM.UserID
where tPCM.UserID = @usId
order by tPCM.Createddate desc
end
end