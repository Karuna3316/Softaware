﻿CREATE proc [dbo].[GetLatecheckinABD]
as
begin
select 'Test1' as EmployeeName,'9:51AM'as Time
union
select 'Test2' as EmployeeName,'10:51AM'as Time
union
select 'Test3' as EmployeeName,'9:55AM'as Time
union
select 'Test4' as EmployeeName,'10:1AM'as Time

end