﻿CREATE proc GetTLEmailID  (@userid int)
AS
begin
select emailid from tblUsers where userid = @userid
end