﻿create proc Halfdayleave
as
begin
update tblAttendance set Reason = 'Half Day Leave'  where leaverequst like '%half%'  and Month(checkindate) = Month(getdate())  
end