﻿CREATE proc [dbo].[OverallReportPutDCandJMR]--2
@Siteid int

as

begin



WITH expression_name(PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,[Pending Billable Supply], SignedOffJMR, SignedOffDC,SignvsbillJMR, PutDC,PutJMR)   

AS   

(   

  

select SLNO, dbo.fn_Description(Slno), Quantity, Unit,isnull(dbo.fn_BilledDC(slno),0), isnull(dbo.fn_BilledJMR(slno),0), Isnull(convert(decimal(18,2),dbo.fn_BilledDC(slno)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno)),0)  
,  isnull(dbo.fn_SignedOffJMR(slno),0), isnull([dbo].[fn_SignedOffDC](slno),0),Isnull(convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno)),0)
,case when Convert(decimal(18,2),dbo.fn_SignedOffJMR(slno)) < Convert(decimal(18,2),dbo.fn_BilledDC(slno)) then 0.00 else isnull(Convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno)) - Convert(decimal(18,2),dbo.fn_BilledDC(slno)),0  )end
,case when Convert(decimal(18,2),dbo.fn_BilledDC(slno)) < Convert(decimal(18,2),dbo.[fn_SignedOffjmr](slno)) then  0.00 else  isnull(Convert(decimal(18,2),dbo.fn_BilledDC(slno)) - Convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno)),0  ) end

from tblShortBOQ where SiteId = @Siteid and Slno <> 1000 --and Quantity <> 0 

  

 )  



 select PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,SignedOffJMR,SignedOffDC, abs(PutDC) as PutDC, abs(PutJMR) as PutJMR from expression_name where PutDC <> 0.00 Or PutJMR <> 0.00



 end