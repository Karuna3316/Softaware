﻿CREATE procedure [dbo].[SaveReporting](@userId int,@isTeamLead int)
as
begin
if(@userId > 0)
begin
update tblUsers set isTeamLead = 1  where userId = @userId
select 1

end

end