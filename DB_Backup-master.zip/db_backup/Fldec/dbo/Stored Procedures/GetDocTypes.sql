﻿create Procedure GetDocTypes
as
begin
select docTypeId, docType from tblDocumentTypes order by docType
end