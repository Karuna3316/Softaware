﻿CREATE proc [dbo].[OverallReport]--2
@Siteid int

as

begin



WITH expression_name(PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,[Pending Billable Supply], SignedOffJMR, SignedOffDC,SignvsbillJMR, PutDC,PutJMR)   

AS   

(   

  

select SLNO, dbo.fn_Description(Slno,@Siteid), Quantity, Unit,isnull(dbo.fn_BilledDC(slno,@Siteid),0), isnull(dbo.fn_BilledJMR(slno,@Siteid),0), Isnull(convert(decimal(18,2),dbo.fn_BilledDC(slno,@Siteid)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno,@Siteid)),0)  
,  isnull(dbo.fn_SignedOffJMR(slno,@Siteid),0), isnull([dbo].[fn_SignedOffDC](slno,@Siteid),0),Isnull(convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno,@Siteid)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno,@Siteid)),0)
,case when Convert(decimal(18,2),dbo.fn_SignedOffJMR(slno,@Siteid)) < Convert(decimal(18,2),dbo.fn_BilledDC(slno,@Siteid)) then 0.00 else Case when (Convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno,@Siteid)) - Convert(decimal(18,2),dbo.fn_SignedOffDC(slno,@Siteid))) < 0 then 0.00 else isnull(Convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno,@Siteid)) - Convert(decimal(18,2),dbo.fn_SignedOffDC(slno,@Siteid)),0  ) end end
--, isnull(Convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno)) - Convert(decimal(18,2),dbo.fn_SignedOffDC(slno)),0  )
,case when Convert(decimal(18,2),dbo.fn_BilledDC(slno,@Siteid)) < Convert(decimal(18,2),dbo.[fn_SignedOffjmr](slno,@Siteid)) then  0.00 else  isnull(Convert(decimal(18,2),dbo.fn_BilledDC(slno,@Siteid)) - Convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno,@Siteid)),0  ) end

from tblShortBOQ where SiteId = @Siteid and Slno <> 1000 --and Quantity <> 0 

  

 )  



 select PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,SignedOffDC,SignedOffJMR, abs(PutDC) as PutDC, abs(PutJMR) as PutJMR from expression_name-- where putdc <> 0.00 or putjmr <> 0.00



 end