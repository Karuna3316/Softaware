﻿CREATE proc [dbo].[DeleteLeaveBenefit]
(@LBid int)
as
begin
delete from tblLeaveBalanceMaster where LBid = @LBid
end