﻿CREATE proc [dbo].[GetPartforedit](@PartId int)
as
begin

Select PartId,PartNo, Description from [InvtblPartNo] where PartId = @PartId

end