﻿Create proc [dbo].[DeleteMake]
(@MasterID int)
as
begin
delete from tblfdss_Master where MasterID = @MasterID
end