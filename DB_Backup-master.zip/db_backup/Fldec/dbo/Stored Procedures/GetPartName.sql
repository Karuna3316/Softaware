﻿create proc [dbo].[GetPartName]
as
begin
select ProjectId as cId, ProjectName as cVal from InvtblProject
union
select '0' as cId,'select' as cVal
end