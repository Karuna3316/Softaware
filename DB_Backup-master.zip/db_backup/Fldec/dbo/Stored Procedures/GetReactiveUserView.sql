﻿create procedure [dbo].[GetReactiveUserView]
as
begin
 select userId,UserName,Designation,Convert(varchar(12), ResignationDate, 103) as ResignationDate from tblUsers where active=0

end