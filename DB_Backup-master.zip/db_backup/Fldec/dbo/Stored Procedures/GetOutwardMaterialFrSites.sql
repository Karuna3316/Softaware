﻿CREATE Procedure [dbo].[GetOutwardMaterialFrSites](@sN varchar(200))

as

begin

select O.InventoryId,MaterialName, O.Createddate as conDate, I.Unit, O.Quantity  from Mt_MaterialOutward O
inner join Mt_MaterialInwardNew I
on O.InventoryId = I.InventoryId 
where SiteId = (select sid from [dbo].[tblSiteNames] where snCode=@sN)


end