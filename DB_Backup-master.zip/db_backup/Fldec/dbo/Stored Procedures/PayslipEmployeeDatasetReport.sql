﻿CREATE proc PayslipEmployeeDatasetReport
as
begin
select top 1 Username as EmployeeName, EMPID as EmployeeNo, Designation,TemporaryAddress, convert(varchar(12), DOJ,103) as DateofJoining, PANNo as PAN from tblUsers-- where userid = @userid
end