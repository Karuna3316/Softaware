﻿CREATE proc [dbo].[GetInvSupplierForEdit](@SuppID int) 
as
begin

Select SuppID,SupplierId,PONumber,PODate,FileName,
ProductsId = STUFF((SELECT ',' + ProductsId FROM tblfdss_Products where SuppID=@SuppID FOR XML PATH ('')), 1, 1, ''),

LPrice = STUFF((SELECT ',' + LPrice FROM tblfdss_Products where SuppID=@SuppID FOR XML PATH ('')), 1, 1, ''),

Qty = STUFF((SELECT ',' + Qty FROM tblfdss_Products where SuppID=@SuppID FOR XML PATH ('')), 1, 1, ''),

Discount = STUFF((SELECT ',' + Discount FROM tblfdss_Products where SuppID=@SuppID FOR XML PATH ('')), 1, 1, '') 


from tblfdss_Supplier where SuppID = @SuppID
end