﻿
--GetStatisticsSupport 1
CREATE procedure [dbo].[GetStatisticsSupport](@userId int)
as
begin
declare @Total int, @Approved int, @Declined int, @Pending int
if (select roleName from tblRoles where roleId = (select roleId from tblRoleMapping where userid = @userId))  <> 'admin'
begin


set @Total = (Select count(*) from tblSupport with(nolock) where Createdby = @userId   and year(date)= year(getdate()) and month(date) = month(getdate())  )
set @Approved = (Select count(*) from tblSupport with(nolock) where Createdby = @userId and year(date)= year(getdate()) and month(date) = month(getdate()) and status = 1 )
set @Declined = (Select count(*) from tblSupport with(nolock) where Createdby = @userId and year(date)= year(getdate()) and month(date) = month(getdate()) and status = 2)
set @Pending = (Select count(*) from tblSupport with(nolock) where Createdby = @userId and year(date)= year(getdate()) and month(date) = month(getdate()) and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
else
begin
set @Total = (Select count(*) from tblSupport with(nolock) where  year(date)= year(getdate()) and month(date) = month(getdate())  )
set @Approved = (Select count(*) from tblSupport with(nolock) where  year(date)= year(getdate()) and month(date) = month(getdate()) and status = 1 )
set @Declined = (Select count(*) from tblSupport with(nolock) where  year(date)= year(getdate()) and month(date) = month(getdate()) and status = 2)
set @Pending = (Select count(*) from tblSupport with(nolock) where  year(date)= year(getdate()) and month(date) = month(getdate()) and status = 0)

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end
end