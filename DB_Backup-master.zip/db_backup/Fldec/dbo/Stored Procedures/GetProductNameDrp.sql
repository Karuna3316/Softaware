﻿CREATE procedure [dbo].[GetProductNameDrp]
as
begin
select distinct ProductsId, [dbo].[fn_productName](ProductsId) as ProductsName  from [dbo].[tblfdss_InwardProducts]

end