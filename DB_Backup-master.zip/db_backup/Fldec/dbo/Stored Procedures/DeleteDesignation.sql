﻿CREATE proc [dbo].[DeleteDesignation]
(@DesignationID int)
as
begin
delete from tblDesignation where DesignationID = @DesignationID
end