﻿CREATE proc [dbo].[GetSupplier]
as
begin
Select case when Updatedby is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(Updatedby) end as CreatedBy, SID, SupplierName,CPName,GstNo,CPNumber,Address,
case when Updatedby is null then CreatedDate  else  UpdatedDate  end as UpdatedDate from tblfdss_SupplierMaster order by UpdatedDate desc


end