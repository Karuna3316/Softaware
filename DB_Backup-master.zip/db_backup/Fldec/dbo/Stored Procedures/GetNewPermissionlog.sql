﻿--select * from tblPermission
CREATE procedure [dbo].[GetNewPermissionlog] (@stDate datetime,@endDate datetime, @userid int, @roleName varchar(50), @EmployeeId int = null)
as
begin
set @endDate = @endDate + 1

if @roleName ='admin'
begin
if(@EmployeeId > 0)
begin 

select  userid, (select username from tblUsers where userid = PR.userId) as username , PDatewithhour as checkin, reason, createddate, status , PId, reportingTo, 
(select username from tblUsers where userid = PR.reportingTo) as reportingUser from tblPermission PR 
where userid = @EmployeeId and
CheckIn between @stDate and @endDate 
 order by [status]   
	end
	else
begin
	 
select  userid, (select username from tblUsers where userid = PR.userId) as username , PDatewithhour as checkin, reason, createddate, status , PId, reportingTo, 
(select username from tblUsers where userid = PR.reportingTo) as reportingUser from tblPermission PR where
 	CheckIn between @stDate and @endDate order by [status] 
 
end

end

else
begin

if(@EmployeeId > 0)
begin



select userid, (select username from tblUsers where userid = PR.userId) as username , PDatewithhour as checkin, reason, createddate, status , PId, reportingTo, 
(select username from tblUsers where userid = PR.reportingTo) as reportingUser from tblPermission PR where
 	CheckIn between @stDate and @endDate  order by [status] 
end
else
begin
 
select  userid, (select username from tblUsers where userid = PR.userId) as username , PDatewithhour as checkin, reason, createddate, status , PId, reportingTo, 
(select username from tblUsers where userid = PR.reportingTo) as reportingUser from tblPermission PR where
CheckIn between @stDate and @endDate     order by [status] 
end
end
end