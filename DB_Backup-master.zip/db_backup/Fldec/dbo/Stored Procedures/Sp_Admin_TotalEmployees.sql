﻿
CREATE proc Sp_Admin_TotalEmployees

as

begin

select 

(select count(*) from tblUsers U 
inner join tblRoleMapping RM on U.userId = RM.userId
inner join tblRoles R on R.roleId = RM.roleId where active = 1 and projId is null and R.roleId in ( 2,10)) as Employee ,

(select count(*) from tblUsers U 
inner join tblRoleMapping RM on U.userId = RM.userId
inner join tblRoles R on R.roleId = RM.roleId where active = 1 and projId is null and R.roleId = 9) as Intern,

(select count(*) from tblUsers U 
inner join tblRoleMapping RM on U.userId = RM.userId
inner join tblRoles R on R.roleId = RM.roleId where active = 1 and projId is null and R.roleId = 11) as PaidIntern,

(select count(*) from tblUsers U 
inner join tblRoleMapping RM on U.userId = RM.userId
inner join tblRoles R on R.roleId = RM.roleId where active = 1 and projId is null and R.roleId in (2,9,10,11)) as Total

end