﻿create procedure [dbo].[DeleteInward](@InwardId int)
as
begin  

delete from tblfdss_Inward where InwardId = @InwardId
delete from tblfdss_InwardProducts where InwardId = @InwardId


end