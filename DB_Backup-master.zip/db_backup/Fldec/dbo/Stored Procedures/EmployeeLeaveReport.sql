﻿


  
  CREATE proc [dbo].[EmployeeLeaveReport]   (@ReportType int,  @year int)
as

begin

declare @tTblSE table(EmployeeName nvarchar(500), JAN int, FEB int, MAR int, APR int, MAY int, JUN int, JUL int, AUG int, SEP int, OCT int, NOV int, DEC int, Total int)      


if @ReportType = 1 

begin


insert into @tTblSE 

SELECT [EmployeeName], isnull([1],0) as [JAN], isnull([2],0) as [FEB], isnull([3],0) as [MAR], isnull([4],0) as [APR], isnull([5],0) as [MAY], isnull([6],0) as [JUN]
, isnull([7],0) as [JUL], isnull([8],0) as [AUG]
, isnull([9],0) as [SEP], isnull([10],0) as [OCT]
, isnull([11],0) as [NOV], isnull([12],0) as [DEC], isnull([1],0) + isnull([2],0) + isnull([3],0)+ isnull([4],0)
+ isnull([5],0) + isnull([6],0) + isnull([7],0) + isnull([8],0) + isnull([9],0) + isnull([10],0) + isnull([11],0) + isnull([12],0)  as Total

FROM (
    select dbo.fn_username(userid) as [EmployeeName], Themonth ,  case 
  when TheMonth = 1 then  case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) end
  when TheMonth = 2 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) end
    when TheMonth = 3 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
	  when TheMonth = 4 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
	    when TheMonth = 5 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
		  when TheMonth = 6 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
		    when TheMonth = 7 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
			  when TheMonth = 8 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
			    when TheMonth = 9 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
				  when TheMonth = 10 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
				    when TheMonth = 11 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
					  when TheMonth = 12 then case when (case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear)) <=0 then 0 else(case when Theyear = @year and TheMonth = month(getdate()) then day(getdate()) else  day(TheLastOfMonth) end  - Count(*) - [dbo].[fn_Noofholiday](userid,Themonth,TheYear))end
end  as Done
  from DateDimension D inner join tblAAttendance A with(nolock)
  on D.TheDate = Convert(date, A.CheckInDate) where TheYear =  @year 
  group by userid, dbo.fn_username(userid),TheYear, Themonth,TheLastOfMonth, TheYear-- order by dbo.fn_username(userid)
) as s
PIVOT
(
    SUM(Done)
    FOR [Themonth] IN ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])
)AS pvt

select * from @tTblSE
union
select '     TOTAL DAYS' , SUM(JAN), Sum(FEB) , Sum(MAR), Sum(APR),SUM(MAY), Sum(JUN) , Sum(JUL), Sum(AUG), Sum(SEP), Sum(OCT), Sum(NOV), Sum(DEC), SUM(Total)  from @tTblSE
end

else if @ReportType = 2
begin

declare @tTblSENew table(EmployeeName nvarchar(500), TheMonth int, Done int)      

;with cte as ( 
select userid,   CheckInDate
 from tblAAttendance where year(Checkindate) = @year and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where year(date) = @year 
) 
 and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) 
union all
select userid,   CheckInDate
from tblAAttendance where year(Checkindate) = @year

 and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where year(date) = @year ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1)
)

insert into @tTblSENew
select  dbo.fn_username(userid) as [EmployeeName] , month(checkindate) as TheMonth , count(*) as Done  from cte where userid not in (33,48,49,95,131, 148)   group by dbo.fn_username(userid)  , month(checkindate) order by count(*) desc



insert into @tTblSE 

SELECT [EmployeeName], isnull([1],0) as [JAN], isnull([2],0) as [FEB], isnull([3],0) as [MAR], isnull([4],0) as [APR], isnull([5],0) as [MAY], isnull([6],0) as [JUN]
, isnull([7],0) as [JUL], isnull([8],0) as [AUG]
, isnull([9],0) as [SEP], isnull([10],0) as [OCT]
, isnull([11],0) as [NOV], isnull([12],0) as [DEC], isnull([1],0) + isnull([2],0) + isnull([3],0)+ isnull([4],0)
+ isnull([5],0) + isnull([6],0) + isnull([7],0) + isnull([8],0) + isnull([9],0) + isnull([10],0) + isnull([11],0) + isnull([12],0)  as Total

FROM (



select  [EmployeeName] ,  Themonth ,  Done from  @tTblSENew 
) as s2
PIVOT
(
    SUM(Done)
    FOR [Themonth] IN ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])
)AS pvt2




select * from @tTblSE
union
select '     TOTAL' , SUM(JAN), Sum(FEB) , Sum(MAR), Sum(APR),SUM(MAY), Sum(JUN) , Sum(JUL), Sum(AUG), Sum(SEP), Sum(OCT), Sum(NOV), Sum(DEC), SUM(Total)  from @tTblSE
end

else if @ReportType = 3
begin


insert into @tTblSE 

SELECT [EmployeeName], isnull([1],0) as [JAN], isnull([2],0) as [FEB], isnull([3],0) as [MAR], isnull([4],0) as [APR], isnull([5],0) as [MAY], isnull([6],0) as [JUN]
, isnull([7],0) as [JUL], isnull([8],0) as [AUG]
, isnull([9],0) as [SEP], isnull([10],0) as [OCT]
, isnull([11],0) as [NOV], isnull([12],0) as [DEC], isnull([1],0) + isnull([2],0) + isnull([3],0)+ isnull([4],0)
+ isnull([5],0) + isnull([6],0) + isnull([7],0) + isnull([8],0) + isnull([9],0) + isnull([10],0) + isnull([11],0) + isnull([12],0)  as Total

FROM (


select dbo.fn_username(userid) as [EmployeeName] , month(checkindate) as Themonth , count(*) as Done from  tblAAttendance where userid in (select userid from tblusers with(nolock) where IsRegularise is null)  and  year(Checkindate) = @year
and ((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)
group by dbo.fn_username(userid), month(checkindate) 

) as s1
PIVOT
(
    SUM(Done)
    FOR [Themonth] IN ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])
)AS pvt1




select * from @tTblSE
union
select '     TOTAL' , SUM(JAN), Sum(FEB) , Sum(MAR), Sum(APR),SUM(MAY), Sum(JUN) , Sum(JUL), Sum(AUG), Sum(SEP), Sum(OCT), Sum(NOV), Sum(DEC), SUM(Total)  from @tTblSE

end
end