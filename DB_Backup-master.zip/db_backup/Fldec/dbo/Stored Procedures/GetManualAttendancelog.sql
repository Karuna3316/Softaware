﻿CREATE Procedure [dbo].[GetManualAttendancelog](@stDate datetime,@endDate datetime)
as
begin

select AttendanceID,UserID,dbo.fn_username(UserID) as EmployeeName,CheckInDate,CheckOutDate,createddate,dbo.fn_username(Createdby) as Createdby from tblAAttendance_History where FORMAT(createddate,'yyyy-MM-dd') between @stDate and @endDate

end


--select * from tblAAttendance_History