﻿CREATE Procedure [dbo].[GetAttendanceList] 

as

begin

select 31 as [NoofEmployees], 30 as [TotalPresent], 30 as [TotalAbsent], 5 as [TotalLateCheckIn]
 
end