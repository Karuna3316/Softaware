﻿CREATE proc GetPresendDays  (@userid int)

As 
begin

select convert(varchar(12), checkindate, 103) as Date, [dbo].[fn_DBDay] (CheckInDate) as DayName from tblAAttendance with(nolock) where userid = @userid and Year(CheckInDate) = year(getdate()) and month(CheckInDate) = month(getdate())
order by CheckInDate


end