﻿CREATE procedure [dbo].[GetOutwardQtyprice](@OutwardId int,@ProductsId nvarchar(20))
as
BEGIN
if(@OutwardId>0)
begin
SELECT SUM(CAST(ReceievedQty AS DECIMAL(18, 2)))AS ReceievedQty FROM tblfdss_InwardProducts  WHERE ProductsID = @ProductsId 
end
else
begin

--select top 1 ReceievedQty from  tblfdss_InwardProducts  where ProductsId =@ProductsId

SELECT top 1
    ISNULL((SELECT SUM(CAST(ReceievedQty AS DECIMAL(18, 2))) FROM tblfdss_InwardProducts WHERE ProductsID = @ProductsId), 0) -
    ISNULL((SELECT SUM(CAST(OutwardedQty AS DECIMAL(18, 2))) FROM tblfdss_OutwardProducts WHERE ProductsID = @ProductsId), 0) AS ReceievedQty;
end
END