﻿CREATE procedure [dbo].[GetReconciliation](@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userid, RId, 
--format(CheckIn,'dd/MM/yyyy')
   CheckIn, 
   --format(CheckOut,'dd/MM/yyyy') as
    CheckOut,Reason,AttendanceID,[Status],createddate,
 (select username from tblUsers where userid=tR.userid) as userName 
 from tblReconciliation tR
end
else
begin
declare @userName nvarchar(250)
select @userName = username from tblUsers where userid=@userId
 select userid, RId,
 --format(CheckIn,'dd/MM/yyyy') as 
 CheckIn,
 -- format(CheckOut,'dd/MM/yyyy') as 
 CheckOut,Reason,AttendanceID,[Status],createddate,@userName as userName 
 from tblReconciliation
 where userid=@userId
 end
 -- Convert(varchar(12),CheckIn,105) as CheckIn
 --Convert(varchar(12),CheckOut,105) as CheckOut
end