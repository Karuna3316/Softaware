﻿CREATE proc [dbo].[DeleteTeam]
(@TeamID int)
as
begin
delete from tblTeam where TeamID = @TeamID
end