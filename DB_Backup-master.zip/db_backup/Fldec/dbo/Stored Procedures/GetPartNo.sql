﻿CREATE proc [dbo].[GetPartNo]
as
begin
select distinct InventoryId as cId, PartNo as cVal from InvInwardRegister
union
select '0' as cId,'select' as cVal
end