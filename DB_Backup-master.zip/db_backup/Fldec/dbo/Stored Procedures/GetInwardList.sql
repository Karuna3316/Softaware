﻿CREATE procedure [dbo].[GetInwardList]
AS
begin  

Select InwardId, dbo.fn_SupplierName(SupplierId) as SupplierName, dbo.fn_PONumber(PONumberId) as PONumberId , case when UpdatedBy is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(UpdatedBy) end as CreatedBy,case when UpdatedBy is null then  createddate  else   UpdatedDate  end as createddate from tblfdss_Inward order by createddate desc

end