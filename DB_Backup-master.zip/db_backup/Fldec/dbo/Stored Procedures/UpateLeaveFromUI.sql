﻿
CREATE procedure [dbo].[UpateLeaveFromUI](@userId int,@CasualLeave int,@SickLeave int,@LeaveBalanceID int)
as
begin
if @LeaveBalanceID >0
begin

update [tblLeaveBalanceMaster] set CasualLeave=@CasualLeave,SickLeave=@SickLeave
where lBId=@LeaveBalanceID
end
else
begin



	insert into [tblLeaveBalanceMaster](userId,CasualLeave,SickLeave, Year)
	select @userId,@CasualLeave,@SickLeave,year(getdate())

	select @LeaveBalanceID=max(lBId) from [tblLeaveBalanceMaster]
	end
end


update [tblLeaveBalanceMaster] set CasualLeave='1',SickLeave='0.5'