﻿
create procedure [dbo].[GetLeaveRequestOnduty]  (@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,leaveDaysType 
from [tblRequestLeave] lR 
where lR.reportingTo = @userId  and leaveType = 5
and month(leaveStartedOn) in ( month(getdate()))  and year(leaveStartedOn) = year(getdate())   
order by isApproved

end


end