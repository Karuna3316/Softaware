﻿
--[GetAttendenceDailyFrMonth] 8
create Procedure [dbo].[GetAttendenceDailyFrMonthBackUpOct27](@mon int)
as
begin
declare @tDates table(strDate varchar(50))
declare @sD int, @eD int,@curDay int

declare @curMon int
select @curMon =month(getdate())

declare @currentDayNo int
SELECT  @currentDayNo = DATENAME(d,getdate());

declare @dateToStartFrMon datetime
SELECT @dateToStartFrMon = GETDATE() - @currentDayNo
--select @dateToStartFrMon = DATEADD(m,1, GETDATE() - @currentDayNo)

select @dateToStartFrMon = dateadd(m, -(@curMon-@mon)+1,@dateToStartFrMon) 


SELECT @curDay = DATENAME(d,@dateToStartFrMon);
set @sD = 0
set @eD = @curDay

while @sD <@eD
begin
insert into @tDates select convert(varchar,@dateToStartFrMon-(@eD-1),103)
set @eD = @eD - 1
end
--select * from @tDates
declare @totalDays int
select  @totalDays = count(strDate)  from @tDates
   declare @dCols varchar(3000),@eQry nvarchar(max)
   declare @totCols varchar(3000)

    set @totCols = STUFF(
 (select '+[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') 
 
 set @dCols = STUFF(
 (select ',[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
 
 --select @dCols

 declare @sCols varchar(max)
 set @sCols = STUFF(
 (select ',case when [' + strDate + ']=0 then ''A'' else ''P'' end as [' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')

 declare @nQry nvarchar(max)
 
 set @eQry=' declare @tDates1 table(strDate datetime)
declare @sD1 int, @eD1 int,@curDay1 int


declare @curMon1 int
select @curMon1 =month(getdate())

declare @currentDayNo1 int
SELECT  @currentDayNo1 = DATENAME(d,getdate());

declare @dateToStartFrMon1 datetime
SELECT @dateToStartFrMon1 = GETDATE() - @currentDayNo1
--select @dateToStartFrMon1 = DATEADD(m,1, GETDATE() - @currentDayNo1)

select @dateToStartFrMon1 = dateadd(m, -(@curMon1-' + convert(varchar,@mon) + ')+1,@dateToStartFrMon1) 
--select @dateToStartFrMon1
SELECT @curDay1 = DATENAME(d,@dateToStartFrMon1);
set @sD1 = 0
set @eD1 = @curDay1

while @sD1 <@eD1
begin
insert into @tDates1 select @dateToStartFrMon1-(@eD1-1)
set @eD1 = @eD1 - 1

end

declare @totalDays int
select  @totalDays = count(strDate)  from @tDates1

 declare @sundayCount int
select @sundayCount = count(strDate) from @tDates1 
where DATENAME(dw,strDate) =''sunday''

 
	SELECT [UserName],' + @sCols + ',((' + @totCols +') -(hL*0.5))-(@sundayCount-[sunday]) as [Total Present], (@totalDays- (convert(int,( ' + @totCols  + '))+(@sundayCount-(@sundayCount-sunday)))) + (hL*0.5)  as [Total Absent], @sundayCount-[sunday] as [Sunday Worked]
FROM (SELECT  
tU.UserName ,
       convert(varchar, checkindate,103) as [Days],
Checkin as [Presence]       
      FROM [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
       group by UserName,convert(varchar, checkindate,103),Checkin) A
      PIVOT( count(A.Presence)   
    FOR [Days] IN (' + @dCols +')
	) AS MNamePivot  join 
	(
	select sC.uname, [working days],[Leave],[sunday],hL from (
	select tU.UserName as uname, sum(case when checkin=1 then 1 end) as [working days] , isnull(sum(case when checkin is null then 1 end),0) as [Leave],
@sundayCount  - (select count(checkindate) FROM [tblAttendance] where
 CheckIn = 1 and UserID= tA.userID and month(checkindate) =' + convert(varchar,@mon) + '
 and convert(varchar,checkindate,103) in (
select convert(varchar,strDate,103) from  @tDates1 
where DATENAME(dw,strDate) =''sunday'')) as [sunday]
	   from [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where 
		--tA.userid in (25,28) and 
		month(checkindate) =' + convert(varchar,@mon) + '
	   group by tU.UserName,tA.userID) sC
	   
	   join
	   (
	   select tU.UserName as uname,  sum(case when reason=''Half day Leave'' then 1 else 0 end ) as hL 
 
	   from [tblAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where  
		--tA.userid in (25,28) and 
		month(checkindate) =' + convert(varchar,@mon) + '
	   group by tU.UserName,tA.userID) hC on sC.uname = hC.uname
	   ) tL  on MNamePivot.UserName = tL.uname
	 '

print @eQry

	exec(@eQry)
end