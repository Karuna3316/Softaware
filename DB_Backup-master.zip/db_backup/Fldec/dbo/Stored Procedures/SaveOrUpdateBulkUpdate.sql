﻿
CREATE PROCEDURE [dbo].[SaveOrUpdateBulkUpdate]
(
    @CheckOutDate DATETIME,
    @CheckOutTime DATETIME,
    @Type INT
)
AS
BEGIN
    IF (@Type = 12)
    BEGIN
        UPDATE tblAAttendance
        SET CheckOutDate = CONVERT(DATETIME, CONVERT(VARCHAR(12), @CheckOutDate, 103) + ' ' + '19:30', 103)
        WHERE AttendanceId IN (
                SELECT AttendanceId
                FROM tblAAttendance
                WHERE CONVERT(VARCHAR(12), CheckInDate, 103) = CONVERT(VARCHAR(12), @CheckOutDate, 103)
                    AND ((DATEPART(HOUR, CheckOutDate) = DATEPART(HOUR, @CheckOutTime) AND DATEPART(MINUTE, CheckOutDate) >= DATEPART(MINUTE, @CheckOutTime))
                        OR (DATEPART(HOUR, CheckOutDate) = 19 AND DATEPART(MINUTE, CheckOutDate) <= 30))
            )
        SELECT 2
    END
END