﻿--[GetEmployeeList] 1
CREATE procedure [dbo].[GetEmployeeList](@reqUserId int)
as
begin

if (select roleName from tblRoles where roleId = (select top 1 roleId from tblRoleMapping where userid = @reqUserId))  = 'admin'
begin
select userid, username from tblUsers where active = 1 and userid in (select distinct userid from tblRequestLeave) order by username
end
else
begin
select userid, username from tblUsers where active = 1  and userid in (select distinct userid from tblRequestLeave where userId = @reqUserId or reportingTo = @reqUserId) order by username
end
end