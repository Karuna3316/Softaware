﻿CREATE procedure [dbo].[GetMobileNos]
as
begin
declare @msg nvarchar(2000), @tId int
select top 1  @msg = mobileNo + ' : ' + msg, @tId = tId from tblMobilenos where active = 1 
--order by createdDate desc
--if @msg is null
--begin
----	update tblMobilenos set active = 1
----	select top 1  @msg = mobileNo + ' : ' + msg, @tId = tId from tblMobilenos where active = 1 
----	order by createdDate desc
--set @msg = '1'

--end
update tblMobilenos set active = 0 where tId = @tId
select @msg
end

--select * from tblMobilenos