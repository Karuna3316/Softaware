﻿
CREATE procedure [dbo].[SaveDeviceMappingBulk] (@EmployeeId int, @EmployeeName nvarchar(500),@DeviceCode nvarchar(500),@UpdatedDate datetime,@UpdatedBy int)
as

begin
--BEGIN TRY
    BEGIN TRAN 
    --DELETE FROM tblDeviceMappingBulk WITH (TABLOCK) WHERE EmployeeId = @EmployeeId

	insert into tblDeviceMappingBulk (EmployeeId,EmployeeName,DeviceCode,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy)
	select @EmployeeId,@EmployeeName,@DeviceCode,GETDATE(),1,@UpdatedDate,@UpdatedBy
	COMMIT TRAN 
--END TRY
--BEGIN CATCH
--    ROLLBACK TRAN 
--END CATCH
	end