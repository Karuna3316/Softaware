﻿CREATE proc GetStocklist
as
begin
	select ProjectType,BoxType, PartNo,Quantity, Description from 
	(select dbo.fn_ProjectType(ProjectTypeId) as ProjectType, dbo.fn_BoxType(BoxTypeId) as BoxType,   PartNo, (select sum(Quantity) from [dbo].[InvInwardRegister] II where II.InventoryId = I.InventoryId) -  (select sum(Qty) from [dbo].InvOutwardRegister OO where OO.InventoryId = I.InventoryId) as Quantity
,I.Desciption as Description	from [dbo].[InvInwardRegister] I inner join 
[dbo].[InvOutwardRegister] O on O.InventoryId = I.InventoryId where projecttypeid in (1,2) group by PartNo ,I.InventoryId,dbo.fn_ProjectType(ProjectTypeId),dbo.fn_BoxType(BoxTypeId),I.Desciption) as test
end