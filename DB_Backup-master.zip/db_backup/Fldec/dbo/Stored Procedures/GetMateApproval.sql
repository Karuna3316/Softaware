﻿
CREATE proc [dbo].[GetMateApproval](@usId int,@rName varchar(100))
as
Begin
	if  @rName='Admin'
	begin
		select 
	(select SiteName from tblSiteNames where sId = siteId) as sN , MaterialName, Make, convert(varchar,Createddate,103) as creDate
	from [tblMaterialApproval] order by Createddate desc
	end
	else
	begin
	
		declare @projId varchar(200)
		select @projId =projId from tblUsers where userId=@usId
	select 
	(select SiteName from tblSiteNames where sId = siteId) as sN ,  MaterialName, Make, convert(varchar,Createddate,103) as creDate 
	from [tblMaterialApproval] where siteId in (select item from [dbo].[fnSplitString](@projId,','))  order by Createddate desc
	end
End