﻿CREATE procedure [dbo].[AddNewDoc](@uId int, @sId int, @docN varchar(500), @dFileName varchar(200),@dTId int)
as
begin
	insert into tblDocuments(userId,siteId,docName,docFileName,docTypeId)
	select @uId,@sId,@docN,@dFileName,@dTId
end