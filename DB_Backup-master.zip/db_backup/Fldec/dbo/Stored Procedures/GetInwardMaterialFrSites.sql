﻿CREATE Procedure [dbo].[GetInwardMaterialFrSites] (@sN varchar(200))

as

begin

--declare @sName varchar(200)

--select @sName=siteName from tblSiteNames where snCode=@sN

if exists(select siteName from tblSiteNames where snCode=@sN)

--if (@sN = 'OBJGUJFXSAQEFH') or (@sN = 'IOJJNBJFRDGGGF') or (@sN = 'MNJGHGHFHHXCDF') or (@sN = 'KHKHYRWDHHJGBI') or (@sN = 'JUIBJGYUBFYJBG') or (@sN = 'HNKSFDJLKHXIDXI') or (@sN = 'UHIGKJHKHKGYKGIU') or (@sN = 'YHUGIJHGFDWRUI') or (@sN = 'HLHKHKHKJHKJH')
 or (@sN = 'HLJKLJKHKHLKH') or (@sN = 'SIYUOUSDOFSOU')

begin



--select  MaterialName, Unit, Quantity, FORMAT(Createddate,'dd/MM/yyyy hh:mm') as conDate

----,SiteName 

--from [dbo].[Mt_MaterialInward] where SiteName = @sName order by Createddate desc



with MaterialGrid

(InventoryId,MaterialName, Unit, Quantity, conDate)

as

(





select '', MaterialName, Unit, Quantity, FORMAT(Createddate,'dd/MM/yyyy hh:mm') as conDate

--,SiteName 

from [dbo].[Mt_MaterialInward] where SiteName = (select siteName from tblSiteNames where snCode=@sN) -- order by Createddate desc



union --All



select InventoryId,  MaterialName, Unit, Quantity, FORMAT(Createddate,'dd/MM/yyyy hh:mm') as conDate

--,SiteName 

from [Mt_MaterialInwardNew] where SiteName = (select sid from [dbo].[tblSiteNames] where SiteName = (select siteName from tblSiteNames where snCode=@sN))-- order by Createddate desc



)



select * from MaterialGrid order by conDate desc

end



end