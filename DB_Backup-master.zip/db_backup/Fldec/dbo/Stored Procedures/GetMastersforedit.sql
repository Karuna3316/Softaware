﻿CREATE proc [dbo].[GetMastersforedit](@TeamId int,@DesignationID int,@ProbationStatusID int)
as
begin
Select TeamId, Team from tblTeam where TeamID = @TeamId
--select DesignationID,Designation from tblDesignation where DesignationID=@DesignationID
--select ProbationStatusID,ProbationStatus from tblProbationStatus where ProbationStatusID=@ProbationStatusID

end