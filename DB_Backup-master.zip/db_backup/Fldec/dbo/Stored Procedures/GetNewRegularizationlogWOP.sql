﻿CREATE procedure [dbo].[GetNewRegularizationlogWOP] 
as
begin


select top 100 userid, 

(select username from tblusers where userid=lR.userId) as userName,Convert(varchar(12), CheckIn,103) as CheckIn, CheckIn as Date,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userid = lR.reportingTo) as reportingUser 
from [tblReconciliationNew] lR 
order by RId desc


	end