﻿
--[tblReconciliationNew]([RId] [int] IDENTITY(1,1) NOT NULL,[CheckIn] [datetime] not NULL,
--	[CheckOut] [datetime] not NULL, [Reason] [nvarchar](200) not NULL, userId int, reportingTo int,
--	status int not null default 0, approvedDate datetime, createddate datetime default getdate(),approvedUser

create procedure [dbo].[GetNewPermissionDatabakup]  (@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,CheckIn,--CheckOut,
reason,createdDate,[status],PId,reportingTo, PDatewithhour,
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblPermission lR where lR.userId = @userId or lR.reportingTo = @userId order by [status] 
end
else
begin
--declare @userName nvarchar(250)
--select @userName = username from tblUsers where userid=@userId
select userId, 
(select username from tblusers where userId=lR.userId) as userName,CheckIn, 0 as isTeamLead,-- (select isTeamLead from tblusers where userId=@userId) as isTeamLead,
reason,createdDate,[status],PId,reportingTo, PDatewithhour,
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblPermission lR
where lR.userId = @userId or lR.reportingTo = @userId order by [status]
end

end

--truncate table tblPermission