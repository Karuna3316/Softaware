﻿
--[tblReconciliationNew]([RId] [int] IDENTITY(1,1) NOT NULL,[CheckIn] [datetime] not NULL,
--	[CheckOut] [datetime] not NULL, [Reason] [nvarchar](200) not NULL, userId int, reportingTo int,
--	status int not null default 0, approvedDate datetime, createddate datetime default getdate(),approvedUser

CREATE procedure [dbo].[GetNewRegularizationData] (@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,Convert(varchar(12), CheckIn, 103 ) as CheckIn,--CheckOut,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblReconciliationNew lR
where  Year(CheckIn) = Year(getdate()) and Month(CheckIn) = month(getdate())  and  lR.reportingTo = @userId order by Status, CheckIn

end
else
begin
--declare @userName nvarchar(250)
--select @userName = username from tblUsers where userid=@userId
select userId, 
(select username from tblusers where userId=lR.userId) as userName,Convert(varchar(12), CheckIn, 103 ) as CheckIn,--CheckOut,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblReconciliationNew lR
where 
 Year(CheckIn) = Year(getdate()) and Month(CheckIn) = month(getdate()) and lR.userId = @userId or lR.reportingTo = @userId order by Status, CheckIn
end

end