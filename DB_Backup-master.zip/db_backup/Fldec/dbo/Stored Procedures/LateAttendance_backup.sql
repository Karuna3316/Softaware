﻿create proc [dbo].[LateAttendance_backup]--2
 @userid int
as
begin

 --declare @userid int 
 --set @userid = 25
 declare @vLatsDelayLeave nvarchar(max)  
 select @vLatsDelayLeave =   STUFF((select  Char(10) +  Convert(varchar(20), CheckInDate,103)  + ' - ' +  isnull(CONVERT(VARCHAR(10), CAST(CheckInDate AS TIME), 0),'') + ' - ' +  CONVERT(VARCHAR(10), 
 CAST(CheckOutDate AS TIME), 0)  from tblAttendance A right join tbldimdate D on Convert(varchar(12),A.Checkindate,103) = Convert(varchar(12),D.Date,103) where MONTH(checkindate) = 10 and UserID = @userid and checkin = 1 
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  

 set @vLatsDelayLeave = '_*Dear ' + dbo.fn_username(@userid)  +  ',*_'  + Char(10) + Char(10) + 'Please find your attandance record for month October' +   Char(10) + Char(10) +'*_[Date]       -   [In Time]  -  [Out Time]_*' + Char(10) + Char(10) + @vLatsDelayLeave + Char(10) + Char(10) + ' _Total late checked in :_ *' + 
  ( select  Convert(varchar(10),(Sum(delayleave))) from tblAttendance where MONTH(checkindate) = 10 and UserID = @userid and  CheckIn = 1) + '*' + 

  +  Char(10) + Char(10) + ' _Grace late Period Allowed :_ ' +  '*2*'  + Char(10) + Char(10) + 

  ' _Leave for late checked in :_ ' +  ' *' + (select Convert(varchar(10),(Sum(delayleave) - 2)*0.5) from tblAttendance where MONTH(checkindate) = 10 and UserID = @userid   and CheckIn = 1) + '*' + ' Day(s)'

     select @vLatsDelayLeave

  end