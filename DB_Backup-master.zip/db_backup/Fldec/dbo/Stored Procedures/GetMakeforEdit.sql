﻿CREATE proc [dbo].[GetMakeforEdit](@MasterID int)
as
begin
Select MasterID,FORMAT (CreatedDate, 'yyyy-MM-dd') as CreatedDate,Description, MasterType from tblfdss_Master where MasterID = @MasterID


end