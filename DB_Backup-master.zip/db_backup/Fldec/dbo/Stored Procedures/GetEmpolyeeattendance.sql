﻿
CREATE proc [dbo].[GetEmpolyeeattendance]
as
begin
select (select Username from tblUsers where UserId = A.UserID) as [Employee Name], case when A.CheckIn = 1 then 'Present' else 'Absent'end  as Status, 
Case when CheckIn = 1 then (Select [siteName] from [dbo].[tblSiteNames] where Sid = A.SiteId) when CheckIn = 0 then '' when OD = 1 then Reason end as [Work Place],
case when CheckIn = 1 then Convert(varchar(5), CheckInDate,108) else '' end as [ChkIn] , case when CheckOut = 1 then Convert(varchar(5), CheckOutDate,108) else '' end as CheckOut, 
case when Reason is null then '' else reason end as Remarks
from [dbo].[tblAttendance] A where convert(varchar(12), A.CheckInDate, 103) = convert(varchar(12), getdate(), 103)
order by 
case 
when A.CheckIn = 1 then 'Present' else 'Absent'end 
end
--where LeaveRequst = ' CL '

---update [tblAttendance] set CheckIn = 1 where Permission = 1


--select * from tblAttendance where LeaveRequst = ' CL '