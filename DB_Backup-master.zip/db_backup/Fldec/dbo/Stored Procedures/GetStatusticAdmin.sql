﻿
--GetStatusticAdmin 15
CREATE procedure [dbo].[GetStatusticAdmin]
as
begin

declare @Absentcount decimal(18,0), @Presentcount decimal(18,0), @Holidayscount int, @mon int, @Timepercentage int
set @mon = month(getdate())



set @Holidayscount = (select count(*) from tblAAttendance with(nolock) where convert(varchar(12),checkindate,103) = convert(varchar(12), getdate(),103) and checkin =1  and 
((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51)  or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) >=0 ) or  (DATEPART(hour, CheckInDate) = 11 and   DATEPART(MINUTE, CheckInDate) >=0 )) and ( DATEPART(hour, CheckInDate) <= 12))

declare @NoofHolidays int
select @NoofHolidays=  Count(*) from  tblusers with(nolock) where active = 1 and projId is null

declare @dName int
select @dName=case @mon 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end

;with CTE as

(
select convert(varchar(12), Date, 103) as Date from tblDim with(nolock) where DAY(Date)<= DAY(getdate()) and Month(Date)= Month(getdate())
union
select Convert(varchar(12),CheckInDate, 103) as Date from tblAAttendance with(nolock) where  CheckIn = 1 and Month(CheckInDate)= Month(getdate())
) 

 select @Absentcount = day(getdate()) - count(*) + (select  count(UserID) * 0.5 from tblAAttendance with(nolock) where day(CheckInDate) not in (select day(checkindate) from tbldim with(nolock) where year(date) = year(getdate()) and month(date) = month(getdate())) and year(checkindate)= year(getdate()) and month(checkindate)= month(getdate()) and day(checkindate) <> day(getdate()) 
and (CAST(checkindate as time) >= CAST('12:00' as time) or 
CAST(isnull(checkoutdate,'16:59') as time) <= CAST('16:59' as time)) and convert(varchar(12), checkindate, 103) not in (select convert(varchar(12), Date, 103) from dbo.tbldim with(nolock) where  month(date)= month(getdate())  and year(date)= year(getdate())))
 from CTE

 select @Presentcount = (select  count(UserID) from tblAAttendance with(nolock) where convert(varchar(12), checkindate, 103)  = convert(varchar(12), getdate(), 103))

 select @Timepercentage = 10--(select [dbo].[fn_TimePercentageCalc]  (@userId))


 declare @NoOfRegularization int
Declare @NoofRegularizeApplied int
Declare @NoOfPermission int
Declare @NoOfPermissionApplied int
Declare @NoOfMissingCheckOut int
Declare @WorkedinHolidays int
Declare @NewEmployees int
Declare @NewIntern int
Declare @PaidIntern int
Declare @RelievingCount int


set @NoOfRegularization = (select Count(*) 
from tblAAttendance A with(nolock) where  year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and
((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)
)

set @NoofRegularizeApplied = (select Count(*) from tblReconciliationNew R with(nolock) where  year(CheckIn) = year(getdate()) and  month(CheckIn)=month(getdate()) )


set @NoOfMissingCheckOut = (select count(*) from tblDim with(nolock) where year(date) = year(getdate()) and month(date) = month(getdate())) --(select count(*) from tblAAttendance where  userid = @userid and CheckOut is null and year(checkindate) = year(getdate()) and  month(checkindate)=month(getdate()) and day(checkindate) <> day(getdate()) )

set @NoOfPermission =  [dbo].[fnPermissionCountADB]()

set @NoOfPermissionApplied =  (select count(*) from tblPermission with(nolock) where  year (Checkin) = year (getdate()) and month(Checkin) = month(getdate()) )

set @WorkedinHolidays = (select count(*) from tblAAttendance with(nolock) where  Convert(varchar(12), Checkindate, 103) in (select convert(varchar(12), date, 103) from tblDim with(nolock) where year(date) = year(getdate()) and month(date) = month(getdate()) ))

set @NewEmployees = (select isnull(count(*), 0) from tblUsers with(nolock) where year(createdDate) = year(getdate()) and month(createddate) = month(getdate()) )
set @NewIntern = (select isnull(count(*), 0) from tblUsers U
inner join tblRoleMapping RM on
Rm.userId = U.Userid
inner join tblRoles R
on R.roleId = RM.roleId where r.roleId = 9 and year(U.createdDate) = year(getdate()) and month(U.createddate) = month(getdate()) )
set @PaidIntern= (select isnull(count(*), 0) from tblUsers U
inner join tblRoleMapping RM on
Rm.userId = U.Userid
inner join tblRoles R
on R.roleId = RM.roleId where r.roleId = 11 and year(U.createdDate) = year(getdate()) and month(U.createddate) = month(getdate()) )
set @RelievingCount = (select isnull(count(*), 0) from tblUsers with(nolock) where DateOfLeaving is not null  and year(createdDate) = year(getdate()) and month(createddate) = month(getdate()) )



    select  @NoofHolidays as [Noofdays] , @Presentcount  as [Present], isnull( @NoofHolidays - @Presentcount,0) as [Absent], @Holidayscount as Holidays, @Timepercentage as TimePercentage,ISNULL( @NoOfRegularization ,0)as NoOfRegularization,  isnull(@NoofRegularizeApplied,0) as NoofRegularizeApplied, isnull( @NoOfPermission,0) as NoOfPermission, isnull(@NoOfPermissionApplied,0) as NoOfPermissionApplied,
isnull(@NoOfMissingCheckOut,0) as NoOfMissingCheckOut, Isnull(@WorkedinHolidays,0) as WorkedinHolidays, @NewEmployees as NewEmployees, @NewIntern as NewIntern, @PaidIntern as PaidIntern,  @RelievingCount as RelievingCount, (select Count(*) from tblAAttendance with (nolock) where year(checkindate)= year(getdate()) and month(checkindate) = month(getdate()) and LeaveRequst like '%OnDuty%') as OnDuty , (select Count(*) from tblAAttendance with (nolock) where year(checkindate)= year(getdate()) and month(checkindate) = month(getdate()) and LeaveRequst like '%Comp Off%') as CompOff 



end