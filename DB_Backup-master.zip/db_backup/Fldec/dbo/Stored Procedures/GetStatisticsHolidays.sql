﻿

CREATE procedure [dbo].[GetStatisticsHolidays]
as
begin
declare @Total int, @Approved int, @Declined int, @Pending int

set @Total = (Select count(*) from tblDim with(nolock) where  year(date)= year(getdate()) )
set @Approved = (Select count(*) from tblDim with(nolock) where  year(date)= year(getdate()) and DATENAME(weekday ,date) not IN ('saturday') and DATENAME(weekday ,date) not IN ('sunday') )
set @Declined = (Select count(*) from tblDim with(nolock) where  year(date)= year(getdate()) and DATENAME(weekday ,date)  IN ('saturday'))
set @Pending = (Select count(*) from tblDim with(nolock) where  year(date)= year(getdate()) and DATENAME(weekday ,date)  IN ('sunday'))

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end