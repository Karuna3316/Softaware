﻿
--[tblReconciliationNew]([RId] [int] IDENTITY(1,1) NOT NULL,[CheckIn] [datetime] not NULL,
--	[CheckOut] [datetime] not NULL, [Reason] [nvarchar](200) not NULL, userId int, reportingTo int,
--	status int not null default 0, approvedDate datetime, createddate datetime default getdate(),approvedUser
/**
[dbo].[GetNewPermissionData] 15,'Employee' 
[dbo].[GetNewPermissionData] 113,'Admin' 
[dbo].[GetNewPermissionData] 2,'Employee' 
**/

CREATE procedure [dbo].[GetNewPermissionData]  (@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,CheckIn,  1 as isTeamLead,--CheckOut,
reason,createdDate,[status],PId,reportingTo, PDatewithhour,
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblPermission lR --where lR.userId = @userId or lR.reportingTo = @userId 
order by [status] 
end
else
begin

	declare @IsteamLead int 
	select @IsteamLead =  isTeamLead from tblUsers where userid = @userId

	if @IsteamLead = 1
	begin

select userId, 
(select username from tblusers where userId=lR.userId) as userName,Convert(varchar(12), CheckIn, 103) as CheckIn, @IsteamLead as isTeamLead,-- (select isTeamLead from tblusers where userId=@userId) as isTeamLead,
reason,createdDate,[status],PId,reportingTo, PDatewithhour,
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblPermission lR
where lR.userId = @userId or lR.reportingTo = @userId order by [status]
end
else 
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,Convert(varchar(12), CheckIn, 103) as CheckIn, 0 as isTeamLead,-- (select isTeamLead from tblusers where userId=@userId) as isTeamLead,
reason,createdDate,[status],PId,reportingTo, PDatewithhour,
(select UserName from tblUsers where userId = reportingTo) as reportingUser 
from tblPermission lR
where lR.userId = @userId or lR.reportingTo = @userId order by [status]
end

end

end