﻿


create procedure [dbo].[GetNewPermissionDataDB] (@userId int)
as
begin

if (day(getdate()) > 2)

begin



select PDatewithhour as Date,
Convert(varchar(12),createdDate, 103) as AppliedDate, case when status = 0 then 'Pending' when status = 1 then 'Approved' else 'Declined' end as Status
from tblPermission lR
where 
 Year(CheckIn) = Year(getdate()) and Month(CheckIn) in ( month(getdate())) and (lR.userId = @userId) order by [status],CheckIn




end






else

begin



select PDatewithhour as Date,
Convert(varchar(12),createdDate, 103) as AppliedDate, case when status = 0 then 'Pending' when status = 1 then 'Approved' else 'Declined' end as status
from tblPermission lR
where 
 Year(CheckIn) = Year(getdate()) and Month(CheckIn) in (  month(getdate()), month(getdate())-1) and (lR.userId = @userId ) order by [status],CheckIn
end




end