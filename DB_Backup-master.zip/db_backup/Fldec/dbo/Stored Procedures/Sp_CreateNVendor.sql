﻿



CREATE proc [dbo].[Sp_CreateNVendor]
@Jobnature nvarchar(500),
@NSiteid int
as
begin

 insert into tblNVendor(jobnature, vendorno)
values(@Jobnature,(select max(VendorNo) + 1 from tblNvendor with(nolock)))

  Declare  @Childloopid int
  DECLARE @Counter INT , @Vendorid int


set @Childloopid = 1;
        While(@Childloopid <= 5)
		begin
		   insert into tblNvendorlabour(vendorid, labourname, createddate, siteid) values((select max(VendorId) from tblNvendor), 'Name' + CONVERT(varchar(10),@Childloopid), getdate(),@NSiteid)

		Set @Childloopid = @Childloopid + 1
		   
        End


--  insert into tblNVendor(vendorname, jobnature, CompanyName, vendorno)
--values('Testvendor2', 'Carpent2','TestCompany2',(select max(VendorNo) + 1 from tblNvendor with(nolock)))

--  Declare @Mainloopid int, @MainloopMax int, @Childloopid int
--  DECLARE @Counter INT , @Vendorid int

--SET @Counter=1
--  set @MainloopMax = (select max(sId) from tblNSiteNames)
--  set @Mainloopid = 1
--    While(@Mainloopid <= @MainloopMax)
--    Begin  
--set @Childloopid = 1;
--        While(@Childloopid <= 5)
--		begin
--		   insert into tblNvendorlabour(vendorid, labourname, createddate, siteid) values((select max(VendorId) from tblNvendor), 'Name' + CONVERT(varchar(10),@Childloopid), getdate(),@Mainloopid)

--		Set @Childloopid = @Childloopid + 1
--		end
--		   Set @Mainloopid = @Mainloopid + 1        
--        End

		end