﻿CREATE proc [dbo].[DeleteMenuMaster]
(@menuId int)
as
begin
delete from tblmenus  where menuId = @menuId
end