﻿create procedure [dbo].[GetReconciliationBkUpApr29]
as
begin




 select RId,Convert(varchar(12),CheckIn,105) as CheckIn,Convert(varchar(12),CheckOut,105) as CheckOut,Reason from tblReconciliation


end