﻿CREATE proc [dbo].[Getboxforedit](@BoxtypeId int)
as
begin

select BoxtypeId,ProjectTypeId,dbo.fn_ProjectType(ProjectTypeId) as ProjectType,BoxTypeName from InvtblBoxType where BoxtypeId=@BoxtypeId

end