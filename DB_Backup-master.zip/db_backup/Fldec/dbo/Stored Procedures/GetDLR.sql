﻿--[GetDLR] 1,'admin'
CREATE proc [dbo].[GetDLR](@usId int,@rName varchar(100))
as
begin
if  @rName='Admin' or @rName='Accounts'
begin
	select SiteName, Isnull(Engineer,0) as Engineer, Isnull(safety,0) as Safety,Isnull(Housekeeping,0) + Isnull(OTHousekeeping,0) as Housekeeping,
	Isnull(Carpenter,0) as Carpenter,Isnull(Painter,0) as Painter,Isnull(Pop,0) as POP,Isnull(Plumber,0) as Plumber,
	Isnull(Mason,0) + Isnull(OTMason,0) as Mason, Isnull(Helper,0) + Isnull(OTHelper,0) as Helper,Isnull(Other,0) as Others, Isnull(Remarks,'') 
	as Remarks,totalManpower as Total from [dbo].[tblLabourReport] where convert(varchar(12),createddate,103) = convert(varchar(12),getdate(),103)
	union
	Select 'Total Manpower', Sum(Isnull(Engineer,0)) as Engineer, Sum(Isnull(safety,0)) as Safety,Sum(Isnull(Housekeeping,0)) as Housekeeping, 
	Sum(Isnull(Carpenter,0)) as Carpenter,Sum(Isnull(Painter,0)) as Painter,Sum(Isnull(Pop,0)) as POP,Sum(Isnull(Plumber,0)) as Plumber,
	Sum(Isnull(Mason,0)) as Mason, Sum(Isnull(Helper,0)) as Helper,Sum(Isnull(Other,0)) as Others,'',Sum(Isnull(totalManpower,0)) as Total 
	from [dbo].[tblLabourReport] where convert(varchar(12),createddate,103) = convert(varchar(12),getdate(),103)
end
else
begin
		declare @projId varchar(200)
		select @projId =projId from tblUsers where userId=@usId

		select SiteName, Isnull(Engineer,0) as Engineer, Isnull(safety,0) as Safety,Isnull(Housekeeping,0) + Isnull(OTHousekeeping,0) as Housekeeping,
		Isnull(Carpenter,0) as Carpenter,Isnull(Painter,0) as Painter,Isnull(Pop,0) as POP,Isnull(Plumber,0) as Plumber,
		Isnull(Mason,0) + Isnull(OTMason,0) as Mason, Isnull(Helper,0) + Isnull(OTHelper,0) as Helper,Isnull(Other,0) as Others, Isnull(Remarks,'') 
		as Remarks,totalManpower as Total 
		from [dbo].[tblLabourReport] 
		where convert(varchar(12),createddate,103) = convert(varchar(12),getdate(),103) and
		SiteName in(select siteName from tblSiteNames where sId in (
		select item from [dbo].[fnSplitString](@projId,',')))


		
end
end