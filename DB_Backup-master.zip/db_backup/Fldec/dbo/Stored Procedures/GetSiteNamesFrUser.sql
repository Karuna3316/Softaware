﻿create procedure [dbo].[GetSiteNamesFrUser](@uId int)
as
begin
select shortNameFrSite as [Site], sId  from tblSiteNames
where sid in (select item from dbo.fnSplitString((select projId from tblusers where userId=@uId),','))
order by shortNameFrSite
end