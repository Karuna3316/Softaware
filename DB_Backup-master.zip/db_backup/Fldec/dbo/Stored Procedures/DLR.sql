﻿  CREATE proc DLR --2
  @Siteid int
AS
Begin


  
  declare @vManpower nvarchar(max)  
select @vManpower = stuff((select char(10)+ '_' + [dbo].[fn_VendorNamewithid](VendorId) + '_' + ' : ' +  '*' + Convert(varchar(10),count(userid))  + '*'  from tbllAttendance where convert(varchar(12),CheckInDate,103) = convert(varchar(12),getdate(),103)  and siteid = 2  group by VendorId order by  [dbo].[fn_VendorNamewithid](VendorId)
 for xml path('')),1,1,'')   

 --select isnull(@vManpower,'')


   declare @vManpowerE nvarchar(2000)  
select @vManpowerE = stuff((select char(10)+ '_Engineer_' + ' : ' +  '*' + Convert(varchar(10),count(userid))  + '*'  from tblAttendance where userid in (select userid from tblusers where Designation not like '%EHS%') and convert(varchar(12),CheckInDate,103) = convert(varchar(12),getdate(),103)  and siteid =@Siteid
 for xml path('')),1,1,'')   

    declare @vManpowerS nvarchar(2000)  
select @vManpowerS = stuff((select char(10)+ '_Safety_' + ' : ' +  '*' + Convert(varchar(10),count(userid))  + '*'  from tblAttendance where userid in (select userid from tblusers where Designation  like '%EHS%') and convert(varchar(12),CheckInDate,103) = convert(varchar(12),getdate(),103)  and siteid =@Siteid
 for xml path('')),1,1,'')   

    declare @vManpowerH nvarchar(2000)  
select @vManpowerH = stuff((select char(10)+ '_Housekeeping_' + ' : ' +  '*' + Convert(varchar(10),count(userid))  + '*'  from tblAAttendance where  convert(varchar(12),CheckInDate,103) = convert(varchar(12),getdate(),103)  and siteid =@Siteid
 for xml path('')),1,1,'')   

 declare @vManpowerT nvarchar(2000)  

 select @vManpowerT = (select  count(userid)   from tbllAttendance where convert(varchar(12),CheckInDate,103) = convert(varchar(12),getdate(),103)  and siteid = @Siteid) +
(select count(userid) from tblAttendance where   convert(varchar(12),CheckInDate,103) = convert(varchar(12),getdate(),103)  and siteid =@Siteid) + 
(select count(userid) from tblAAttendance where  convert(varchar(12),CheckInDate,103) = convert(varchar(12),getdate(),103)  and siteid =@Siteid)

 set @vManpowerT = '_*Today''s Labour Report*_' + Char(10) + Char(10) + COALESCE(@vManpowerE, '')  + char(10) + COALESCE(@vManpowerS, '')  + Char(10) +  COALESCE(@vManpowerH, '') + Char(10) +  COALESCE(@vManpower, '') + Char(10) + Char(10) + '*Total Manpower : ' +  COALESCE(@vManpowerT, '') + '*'

 select @vManpowerT

 end