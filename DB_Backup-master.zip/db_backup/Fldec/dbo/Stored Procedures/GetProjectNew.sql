﻿CREATE proc [dbo].[GetProjectNew] 
as
begin
select ProjectTypeId as cId, ProjectTypeName as cVal from InvProjectType 
end