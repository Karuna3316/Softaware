﻿CREATE procedure [dbo].[GetProcurementData]
as
begin

--select Make, MaterialName as [Material Name], Rate, Unit from tblProcurementelectrical

select  MaterialName as [Material Name], Rate, Unit,Make as [Created BY],
 FORMAT(Createddate,'dd/MM/yyyy hh:mm') as [Created Date],
dbo.fn_username(Updatedby) as [Updated By], 
FORMAT(Updateddate,'dd/MM/yyyy hh:mm') as [Updated Date] 
from tblProcurementelectrical where active = 1

--select Description as [Material Name], Rate, Unit,dbo.fn_username(Createdby) as [Created BY],
-- FORMAT(Createddate,'dd/MM/yyyy hh:mm') as [Created Date],
--dbo.fn_username(Updatedby) as [Updated By], 
--FORMAT(Updateddate,'dd/MM/yyyy hh:mm') as [Updated Date] from tblprocurement


End