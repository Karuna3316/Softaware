﻿CREATE proc [dbo].[SaveOrUpdateProbation] (  @ProbationStatus nvarchar(2000), @ProbationStatusID int)
as
begin
if(@ProbationStatusID > 0)
begin
update tblProbationStatus set  ProbationStatus = @ProbationStatus where ProbationStatusID = @ProbationStatusID

select 2
end
else
begin
--if not exists (select ProbationStatusID from tblProbationStatus with (nolock))
--begin
	insert into [tblProbationStatus]( ProbationStatus)
	select @ProbationStatus
	Select 1
	--end
	--else
	--Select 3

	end

end