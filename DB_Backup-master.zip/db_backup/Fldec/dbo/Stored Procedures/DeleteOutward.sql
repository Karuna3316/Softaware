﻿Create procedure [dbo].[DeleteOutward](@OutwardId int)
as
begin  

delete from tblfdss_Outward where OutwardId = @OutwardId
delete from tblfdss_OutwardProducts where OutwardId = @OutwardId


end