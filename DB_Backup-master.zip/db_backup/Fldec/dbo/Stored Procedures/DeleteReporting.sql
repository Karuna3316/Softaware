﻿CREATE procedure [dbo].[DeleteReporting](@userId int,@isTeamLead int)
as
begin
if(@userId > 0)
begin
update tblUsers set isTeamLead = 0  where userId = @userId
end
end