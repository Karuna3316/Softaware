﻿CREATE proc [dbo].[GetHolidaysforedit](@DimId int)
as
begin

Select DimId, FORMAT (Date, 'yyyy-MM-dd') as Date, description from tbldim where DimId = @DimId

end