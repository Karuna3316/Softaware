﻿
CREATE procedure [dbo].[SaveOrUpdateInvSupplier] (@SuppID int,  @SupplierId int,@PONumber nvarchar(100),@PODate datetime=null,@FileName nvarchar(max)=null,@CreatedBy int,@Updatedby int,@ProductsId nvarchar(max),@LPrice nvarchar(max),

@Qty nvarchar(max),@Discount nvarchar(max))
as
begin

if(@SuppID > 0)
begin
update tblfdss_Supplier set SupplierId = @SupplierId, PONumber = @PONumber, PODate = @PODate, FileName = @FileName,Updatedby = @Updatedby, UpdatedDate = getdate() where SuppID = @SuppID

select 2

IF @ProductsId IS NOT NULL AND LEN(@ProductsId) > 0
BEGIN TRY
    BEGIN TRAN 

DELETE FROM tblfdss_Products WITH (TABLOCK) WHERE SuppID = @SuppID

INSERT INTO tblfdss_Products WITH (TABLOCK) (SuppID,CreatedDate,CreatedBy, LPrice, Discount, Qty,ProductsId)
SELECT @SuppID, GETDATE(),@CreatedBy,s.Item,a.Item,n.Item,t.Item 
FROM dbo.fnSplitString(@LPrice, ',') s
JOIN dbo.fnSplitString(@Discount, ',') a ON s.ID = a.ID
JOIN dbo.fnSplitString(@Qty, ',') n ON s.ID = n.ID
JOIN dbo.fnSplitString(@ProductsId, ',') t ON s.ID = t.ID;
COMMIT TRAN 
END TRY
BEGIN CATCH
    ROLLBACK TRAN 
END CATCH

end
else

begin
if not exists (select SuppID from tblfdss_Supplier with (nolock) where SuppID = @SuppID)
begin
	insert into tblfdss_Supplier(SupplierId,PONumber,PODate,FileName,CreatedBy,CreatedDate)
	select @SupplierId,@PONumber,@PODate,@FileName,@CreatedBy,getdate()
	Select 1

	DECLARE @ScopeID int
   SET @ScopeID = SCOPE_IDENTITY()

   if @ProductsId is not null and len(@ProductsId)>0
begin
	insert into tblfdss_Products(SuppID,LPrice,Discount,Qty,CreatedDate,CreatedBy,ProductsId)	
	select @ScopeID,		
	s.Item AS LPrice,
    a.Item AS Discount,
    n.Item AS Qty,
	GETDATE(),
	@CreatedBy,
	t.Item AS ProductsId
FROM dbo.fnSplitString(@LPrice, ',') s
JOIN dbo.fnSplitString(@Discount, ',') a ON s.ID = a.ID
JOIN dbo.fnSplitString(@Qty, ',') n ON s.ID = n.ID
JOIN dbo.fnSplitString(@ProductsId, ',') t ON s.ID = t.ID;
	end
	end
	else
	Select 3

	end

end