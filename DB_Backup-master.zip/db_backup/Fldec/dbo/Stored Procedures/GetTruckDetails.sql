﻿CREATE procedure GetTruckDetails
as
begin
select TruckId as cId, TruckNo as cVal from [dbo].[VECtblTruck]
union
select '0' as cId,'select' as cVal
end