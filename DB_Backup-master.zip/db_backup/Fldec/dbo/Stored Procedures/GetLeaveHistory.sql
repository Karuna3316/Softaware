﻿CREATE procedure [dbo].[GetLeaveHistory]
as
begin
select 
 lbid, lBM.UserId as userid, (select UserName from tblUsers where userId=lBM.UserId) as EmployeeName,
CasualLeave as CasualLeave,
SickLeave as SickLeave,
tblLeavesTaken.casualLeavesTaken as LeaveAvailedCL,
 tblLeavesTaken.sickleavesTaken as LeaveAvailedSL,
 CasualLeave - tblLeavesTaken.casualLeavesTaken as AvailableBalanceCL,
 SickLeave - tblLeavesTaken.sickleavesTaken as AvailableBalanceSL
 from [tblLeaveBalanceMaster] lBM join
(select userId, sum(casualLeavesTaken) as casualLeavesTaken, sum(sickleavesTaken) as sickleavesTaken from(select userId, case when leaveCategory=1 then sum(case leavetype when 3 then 0.5 when 2 then datediff(day,leaveStartedOn,leaveEndsOn)+1 else 1 end) else 0 end as casualLeavesTaken,
case when leaveCategory=2 then sum(case leavetype when 3 then 0.5 when 2 then datediff(day,leaveStartedOn,leaveEndsOn)+1 else 1 end) else 0 end as sickleavesTaken
 from [dbo].[tblRequestLeave] where isApproved=1 and leaveCategory in (1,2)
 group by userid,leaveCategory) a group by userId) tblLeavesTaken on lBM.UserId = tblLeavesTaken.userId
 end