﻿
--Sep15NEWAttenRPt 2022,12
CREATE procedure [dbo].[Sep15NEWAttenRPt](@vYear int,@mon int)
as
begin
declare @dateToStartFrMon datetime
--declare @vYear int, @mon int
--set @vYear=2022;set @mon =8
declare @dName int
select @dName=case @mon 
when 12 then 31 when 11 then 30 when 10 then 31 when 9 then 30 when 8 then 31 when 7 then 31 
when 6 then 30 when 5 then 31 when 4 then 30 when 3 then 31 when 2 then 28 when 1 then 31 
end

if (year(getdate()) = @vYear and month(getdate()) = @mon)
set @dName=day(getdate())
declare @tDates table(strDate varchar(50))
declare @sD int, @eD int,@curDay int

declare @dv nvarchar(50)
set @dv='yy-mm-dd'
select @dv = replace(@dv,'yy',@vYear)
select @dv = replace(@dv,'mm',@mon)
select @dv = replace(@dv,'dd',@dName)
select @dateToStartFrMon = convert(datetime,@dv)

set @sD = 0
set @eD = @dName

while @sD <@eD
begin
insert into @tDates select convert(varchar,@dateToStartFrMon-(@eD-1),103)
set @eD = @eD - 1
end

declare @totalDays int
select  @totalDays = count(strDate)  from @tDates
   declare @dCols varchar(3000),@eQry nvarchar(max)
   declare @totCols varchar(3000)

    set @totCols = STUFF(
 (select '+[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') 
 
 set @dCols = STUFF(
 (select ',[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
 
 --select @dCols

 declare @sCols varchar(max)
 --set @sCols = STUFF(
 --(select ',case when [' + strDate + ']=0 then ''A'' else ''P'' end as [' + strDate + ']' from @tDates           
 --FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')
 set @sCols = STUFF(
 (select ',dbo.testPivot(''' + strDate + ''',Stbl.userId,[' + strDate + '])  as [' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')
 --select @sCols
 set @eQry ='SELECT Stbl.EmpId as [Employee ID], Stbl.[UserName] as [Employee Name],'+ convert(varchar,@dName) +' [No of Days in the Month], DaysWorked as [No of Days Present], NoOfHolidays as [No Of Holidays] , WorkedOnHolidays as [Worked On Holidays],HalfDay as [Half Day Leave],  ' 
 + convert(varchar,@dName) +' - DaysWorked - NoOfHolidays as [Full Day Leave], [Regularize LOP],  [Permission LOP], 
 ([HalfDay] + (' + convert(varchar,@dName) +' - DaysWorked - NoOfHolidays) + [Regularize LOP] +  [Permission LOP]) as [Total Leave Taken],
 [Leave availed CL] + [Leave availed SL] as [Total Leave Availed],
 ([HalfDay] + (' + convert(varchar,@dName) +' - DaysWorked - NoOfHolidays) + [Regularize LOP] +  [Permission LOP]) - ([Leave availed CL] + [Leave availed SL]) as [LOP],
' + convert(varchar,@dName) +'-(([HalfDay] + (' + convert(varchar,@dName) +' - DaysWorked - NoOfHolidays) + [Regularize LOP] +  [Permission LOP]) - ([Leave availed CL] + [Leave availed SL]))  as [To be Paid],
 [Opening balance CL], [Opening balance SL],[Leave availed CL],[Leave availed SL], ([Opening balance CL] - [Leave availed CL]) as [Closing Balance CL],
 ([Opening balance SL] - [Leave availed SL]) as [Closing Balance SL],'+@sCols+'
FROM (SELECT  
tU.UserName ,tU.userId,isnull(tU.EmpId,'''') as EmpId,
       convert(varchar, checkindate,103) as [Days],
Checkin as [Presence]       
      FROM [tblAAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
       group by tU.userId,UserName,isnull(tU.EmpId,''''),convert(varchar, checkindate,103),Checkin) A
      PIVOT( count(A.Presence)   
    FOR [Days] IN ('+ @dCols +' )) Stbl' +
	' join
(select  A1.userId ,
[dbo].[fn_Daysworked](A1.userId,' + convert(varchar,@mon) +',' + convert(varchar, @vYear) +')  as [DaysWorked],
[dbo].[fn_WorkedonHolidays](A1.userId,' + convert(varchar,@mon) +',' + convert(varchar, @vYear) +') as workedOnHolidays,
[dbo].[fn_HalfDayLeave](A1.userId,' + convert(varchar,@mon) +',' + convert(varchar, @vYear) +') as [HalfDay], 
 [dbo].clOpeningOnCurMnth(userId,' + convert(varchar,@mon) +') [Opening balance CL], [dbo].slOpeningOnCurMnth(userId,' + convert(varchar,@mon) +')  [Opening balance SL],clAvail [Leave availed CL],slAvail [Leave availed SL], 
  dbo.[fnCalcLOPFrLateChkIn](userId,' + convert(varchar,@mon) +') as [Regularize LOP], 
  [dbo].[fnCalcLOPFrPermissionRpt](userId,' + convert(varchar,@mon) +',' + convert(varchar, @vYear) +') as [Permission LOP], 
  [dbo].[fn_Noofholiday](A1.userId,' + convert(varchar,@mon) +',' + convert(varchar, @vYear) +')  as [NoOfHolidays]
from( select 
tblU.userId, 

isnull(sum(case when leaveDaysType = 1 and leaveCategory=2 and isApproved=1 then 1	
			when leaveDaysType = 3 and leaveCategory=2  then 0.5
			when leaveDaysType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,' + convert(varchar,@mon) +')
			else 0 end),0) + 
isnull(sum(case when leaveType = 1 and leaveCategory=2 and isApproved=1 then 1	
			when leaveType = 3 and leaveCategory=2  then 0.5
			when leaveType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,' + convert(varchar,@mon) +')
			else 0 end),0) slAvail,
		
			isnull(sum(case when leaveDaysType = 1 and leaveCategory=1 then 1
			when leaveDaysType = 3 and leaveCategory=1 then 0.5
			when leaveDaysType= 2 and leaveCategory=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,' + convert(varchar,@mon) +') 
			else 0 end),0) + 
			isnull(sum(case when leaveType = 1 and leaveCategory=1 then 1
			when leaveType = 3 and leaveCategory=1  then 0.5
			when leaveType= 2 and leaveCategory=1  then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,' + convert(varchar,@mon) +') 
			else 0 end),0) clAvail 
			
from
tblusers tblU left join  
tblRequestLeave  rL  on tblU.userid = rL.userId and isApproved=1 and
 year(leaveStartedOn)=' +convert(varchar, @vYear)+' and month(leaveStartedOn) = '+convert(varchar,@mon)+'
 group by tblU.userId) A1  
 ) GG on GG.[UserId] = Stbl.userId and DaysWorked > 0 order by  Stbl.[UserName]'
--select @eQry

exec(@eQry)
end
/*
(select count(DimId) from tblDim where month(date) = ' + convert(varchar,@mon) +' and year(date) = ' + convert(varchar, @vYear) +' 
and Convert(varchar(12),date, 103) >= (select Convert(varchar(12),createdDate, 103) from tblusers where userid = A1.userId)
and day([date]) not in (select day(CheckInDate)  from tblAAttendance where  month(CheckInDate) = ' + convert(varchar,@mon) +' and year(CheckInDate) = ' + convert(varchar, @vYear) +' and UserID = A1.userId
and day(checkindate) in 
(select  day([date]) from tblDim where month(date) = ' + convert(varchar,@mon) +' and year(date) = ' + convert(varchar, @vYear) +' )))
*/