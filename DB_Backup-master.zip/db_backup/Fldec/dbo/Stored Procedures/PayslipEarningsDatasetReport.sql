﻿CREATE proc [dbo].[PayslipEarningsDatasetReport]
as
begin
select 'Basic' as Earnings, '37,567' as Amount, 'Employee PF Contribution' as Deductions, '1,800' as DAmount
union
select 'House Rent Allowance', '28,177', '',''
union
select 'Conveyance', '1,573', '',''
union
select 'Medical Allowance', '1,229', '',''
union
select 'Special Allowance', '25,375', '',''
end