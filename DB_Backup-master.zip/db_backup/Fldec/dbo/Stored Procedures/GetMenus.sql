﻿CREATE procedure [dbo].[GetMenus](@userId int)
as
begin
declare @roleId int, @roleName varchar(100)
--check for admin starts
select @roleId = rM.roleid, @roleName = tR.roleName from [tblRoleMapping] rM
join tblRoles tR on tR.roleId = rM.roleId 
where rM.userId=@userId

if @roleName = 'admin' 
begin
	select menu, case when menuId = 3 then 'admindashboard.aspx' else  url end as url, parentId,menuId from tblmenus where active =1 order by menuId
end
else
begin
select menu, url, parentId,tM.menuId from tblmenus tM 
join tblMenuMappingFrRole tMMR on tMMR.menuId = tM.menuId
where tM.active =1 and tMMR.roleId = @roleId

end
--check for admin ends

end