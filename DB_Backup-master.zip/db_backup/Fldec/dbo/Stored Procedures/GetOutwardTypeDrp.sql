﻿CREATE procedure [dbo].[GetOutwardTypeDrp]
as
begin
select Id, Description  from [dbo].[tblfdss_Dropdown]
end


--select * from tblfdss_Dropdown