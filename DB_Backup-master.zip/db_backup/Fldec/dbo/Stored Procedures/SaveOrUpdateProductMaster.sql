﻿
create procedure [dbo].[SaveOrUpdateProductMaster] 
(@ProductsID int,  
@MakeId int, 
@SupplierId int,
@ProductsName nvarchar(500),
@Size nvarchar(250),
@Hsn nvarchar(250),
@LPrice decimal(18,2),
@MinQty int,
@CreatedBy int,
@Updatedby int)
as
begin

if(@ProductsID > 0)
begin
update tblfdss_ProductsMaster set MakeId = @MakeId, SupplierId = @SupplierId, ProductsName = @ProductsName, Size = @Size, Hsn = @Hsn, LPrice = @LPrice, MinQty = @MinQty, Updatedby = @Updatedby, UpdatedDate = getdate() where ProductsID = @ProductsID

select 2
end
else
begin
if not exists (select ProductsID from tblfdss_ProductsMaster with (nolock) where ProductsID = @ProductsID)
begin
	insert into tblfdss_ProductsMaster(MakeId, SupplierId,ProductsName,Size,Hsn,LPrice,MinQty,CreatedBy,CreatedDate)
	select @MakeId,@SupplierId,@ProductsName,@Size,@Hsn,@LPrice,@MinQty,@CreatedBy,getdate()
	Select 1
	end
	else
	Select 3

	end

end