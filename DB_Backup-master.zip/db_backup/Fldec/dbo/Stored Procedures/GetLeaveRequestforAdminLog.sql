﻿
--[dbo].[GetLeaveRequestforAdmin] '2022-11-02','2022-10-28', 2, 'Employee'

CREATE procedure [dbo].[GetLeaveRequestforAdminLog]   (@stDate datetime,@endDate datetime, @userid int,@roleName varchar(50), @EmployeeId int = null)
as
begin
if @roleName ='admin'
begin
if(@EmployeeId > 0)
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
[dbo].[fn_Dropdown](leaveType) as leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,[dbo].[fn_Dropdown](leaveCategory) as leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,[dbo].[fn_Dropdown](leaveDaysType) as leaveDaysType 
from [tblRequestLeave] lR 

 where  userid = @EmployeeId  and  	 convert(varchar(10),lR.leaveStartedOn,111) >= convert(varchar(10),@stDate,111)
	and convert(varchar(10),lR.leaveStartedOn,111) <= convert(varchar(10),@endDate,111)
order by  lR.leaveStartedOn 
end
else
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
[dbo].[fn_Dropdown](leaveType) as leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,[dbo].[fn_Dropdown](leaveCategory) as leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,[dbo].[fn_Dropdown](leaveDaysType) as leaveDaysType 
from [tblRequestLeave] lR 

 where 	 convert(varchar(10),lR.leaveStartedOn,111) >= convert(varchar(10),@stDate,111)
	and convert(varchar(10),lR.leaveStartedOn,111) <= convert(varchar(10),@endDate,111)
order by  lR.leaveStartedOn 
end

end
else
begin

if(@EmployeeId > 0)
begin

select userId, 
(select username from tblusers where userId=lR.userId) as userName,
[dbo].[fn_Dropdown](leaveType) as leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,[dbo].[fn_Dropdown](leaveCategory) as leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,[dbo].[fn_Dropdown](leaveDaysType) as leaveDaysType 
from [tblRequestLeave] lR 

 where  userid = @EmployeeId  and	 (convert(varchar(10),lR.leaveStartedOn,111) >= convert(varchar(10),@stDate,111)
	and convert(varchar(10),lR.leaveStartedOn,111) <= convert(varchar(10),@endDate,111)) and (lR.userId = @userId or lR.reportingTo = @userId)
order by lR.leaveStartedOn 
end
else
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
[dbo].[fn_Dropdown](leaveType) as leaveType,convert(varchar(12),leaveStartedOn,103) as leaveStartedOn, Convert(varchar(12), leaveEndsOn,103) as leaveEndsOn,
reason,createdDate,isApproved,reqLId,[dbo].[fn_Dropdown](leaveCategory) as leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser,[dbo].[fn_Dropdown](leaveDaysType) as leaveDaysType 
from [tblRequestLeave] lR 

 where  	 (convert(varchar(10),lR.leaveStartedOn,111) >= convert(varchar(10),@stDate,111)
	and convert(varchar(10),lR.leaveStartedOn,111) <= convert(varchar(10),@endDate,111)) and (lR.userId = @userId or lR.reportingTo = @userId)
order by lR.leaveStartedOn 
end
end
end