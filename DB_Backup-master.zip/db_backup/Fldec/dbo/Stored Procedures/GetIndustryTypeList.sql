﻿CREATE proc [dbo].[GetIndustryTypeList]
as
begin
Select MasterID,Description as Industry,MasterType,[dbo].[fn_username](CreatedBy) as  CreatedBy,case when UpdatedBy is null then  createddate  else   UpdatedDate  end as createddate from tblfdss_Master where MasterType='Industry' order by createddate desc


end