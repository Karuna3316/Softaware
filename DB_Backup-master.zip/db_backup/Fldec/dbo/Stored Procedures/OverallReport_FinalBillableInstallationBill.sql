﻿CREATE proc 
  --select 603.26 -381.90
  --go

[dbo].[OverallReport_FinalBillableInstallationBill]--2
@Siteid int

as

begin



WITH expression_name(PONo, Description, SACCode, BOQQty, Unit, Unitprice, BilledDC, BilledJMR,[Pending Billable Supply], SignedOffJMR,SignedDC, SignvsbillJMR)   

AS   

(   



select SLNO, dbo.[fn_DescriptioninDetail](Slno,@Siteid),SACCode, Quantity, Unit,UnitpriceI,isnull(dbo.fn_BilledDC(slno,@Siteid),0), 
isnull(dbo.fn_BilledJMR(slno,@Siteid),0),
 Isnull(convert(decimal(18,2),dbo.fn_BilledDC(slno,@Siteid)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno,@Siteid)),0)
   ,  isnull(dbo.fn_SignedOffJMR(slno,@Siteid),0), isnull(dbo.[fn_SignedOffDC](slno,@Siteid),0),
 Isnull(convert(decimal(18,2),dbo.[fn_SignedOffJMR](slno,@Siteid)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno,@Siteid)),0)

from tblShortBOQ where SiteId = @Siteid and Slno <> 1000 and Quantity <> 0 



 )  

 select PONo, Description,SACCode, Unit,  case when BOQQty < SignedOffJMR then BOQQty - BilledJMR else abs(SignvsbillJMR) end  as Qty, Unitprice as Rate,
 
 
 case when BOQQty < SignedOffJMR then  Convert(decimal(18,2),abs((BOQQty - BilledJMR )* Unitprice))  else Convert(decimal(18,2),ABS(SignvsbillJMR) * Unitprice) end as [Taxable Value] ,
   '18%' as IGSTRate , 
   case when BOQQty < SignedOffJMR then  Convert(decimal(18,2),abs((BOQQty - BilledJMR)* Unitprice * 0.18)) else Convert(decimal(18,2),ABS(SignvsbillJMR) * Unitprice * 0.18) end as IGSTAmount,

   case when BOQQty < SignedOffJMR then  Convert(decimal(18,2),abs((BOQQty - BilledJMR)* Unitprice + ((BOQQty - BilledJMR)* Unitprice *0.18))) else Convert(decimal(18,2),ABS((SignvsbillJMR * Unitprice) +(SignvsbillJMR) * Unitprice * 0.18)) end as Total from expression_name   where SignvsbillJMR >0 and  case when BOQQty < SignedOffJMR then BOQQty - BilledJMR else abs(SignvsbillJMR) end <> 0.00


  --select PONo, Description, Unit, abs(SignvsbillJMR)  as Qty, Unitprice as Rate,
  --Convert(decimal(18,2),ABS(SignvsbillJMR) * Unitprice) as [Taxable Value] , '9%' as CGSTRate ,  Convert(decimal(18,2),ABS(SignvsbillJMR) * Unitprice * 0.09) as CGSTAmount,
  --'9%' as SGSTRate ,  Convert(decimal(18,2),ABS(SignvsbillJMR) * Unitprice * 0.09) as SGSTAmount,  Convert(decimal(18,2),ABS((SignvsbillJMR * Unitprice) +(SignvsbillJMR) * Unitprice * 0.18)) as Total from expression_name   where SignvsbillJMR >0



 end