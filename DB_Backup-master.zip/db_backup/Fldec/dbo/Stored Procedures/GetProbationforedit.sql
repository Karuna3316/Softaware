﻿CREATE proc [dbo].[GetProbationforedit](@ProbationStatusID int)
as 
begin

Select ProbationStatusID, ProbationStatus from tblProbationStatus where ProbationStatusID = @ProbationStatusID

end