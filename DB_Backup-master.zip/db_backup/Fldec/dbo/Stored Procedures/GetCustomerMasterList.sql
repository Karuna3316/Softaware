﻿CREATE proc [dbo].[GetCustomerMasterList]
as
begin
Select CID,[dbo].[fn_fdssMaster](IndusTypeId) as IndusTypeId,CompanyName,CPName,GstNo,CPNumber,Address,case when Updatedby is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(Updatedby) end as CreatedBy,
case when Updatedby is null then CreatedDate  else  UpdatedDate  end as UpdatedDate from tblfdss_CustomerMaster order by UpdatedDate desc


end