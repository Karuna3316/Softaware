﻿CREATE PROCEDURE [dbo].[GetMenuMasterforedit] (@menuId INT)
AS
BEGIN
    SELECT 
        menuId,
        CONCAT('icon-', SUBSTRING(menu, CHARINDEX('icon-', menu) + LEN('icon-'), 
            CHARINDEX('"></i>', menu, CHARINDEX('icon-', menu) + LEN('icon-')) - CHARINDEX('icon-', menu) - LEN('icon-'))) AS FileName,
        CASE WHEN isMainMenu = 1 THEN SUBSTRING(menu, CHARINDEX('</i>', menu) + 5, LEN(menu) - CHARINDEX('</i>', menu) - 4) END AS MainMenuText,
		CASE WHEN isMainMenu = 0 THEN SUBSTRING(menu, CHARINDEX('<span class="pcoded-mtext">', menu) + LEN('<span class="pcoded-mtext">'), CHARINDEX('</span> </a> </li>', menu) - CHARINDEX('<span class="pcoded-mtext">', menu) - LEN('<span class="pcoded-mtext">')) END AS SubMenuText,
        url,
        parentId,
        active
    FROM tblmenus
    WHERE menuId = @menuId;
END