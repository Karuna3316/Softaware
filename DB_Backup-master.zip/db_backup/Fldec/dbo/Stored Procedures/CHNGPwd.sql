﻿
create procedure [dbo].[CHNGPwd] (@userId int,@newPwd nvarchar(50))
as

begin
update tblUsers set Password = @newPwd  where userId = @userId

select 2
end