﻿CREATE proc [dbo].[GetDesignationforedit](@DesignationID int)
as
begin

Select DesignationID, FORMAT (createdDate, 'yyyy-MM-dd') as createdDate, Designation from tblDesignation where DesignationID = @DesignationID

end