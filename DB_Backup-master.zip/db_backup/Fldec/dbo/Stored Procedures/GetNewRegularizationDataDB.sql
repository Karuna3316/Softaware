﻿


create procedure [dbo].[GetNewRegularizationDataDB](@userId int)
as
begin

if (day(getdate()) > 2)

begin




select Convert(varchar(12), CheckIn, 103 ) as Date,
 Convert(varchar(12), createdDate, 103 ) as AppliedDate ,case when status = 0 then 'Pending' when status = 1 then 'Approved' else 'Declined' end as Status
from tblReconciliationNew lR
where 
( year(CheckIn) = year(getdate()) ) and Month(CheckIn) in ( month(getdate())) and (lR.userId = @userId or lR.reportingTo = @userId) order by Status, CheckIn


end

else
begin



select Convert(varchar(12), CheckIn, 103 ) as Date,
 Convert(varchar(12), createdDate, 103 ) as AppliedDate ,case when status = 0 then 'Pending' when status = 1 then 'Approved' else 'Declined' end as Status
from tblReconciliationNew lR
where 
( year(CheckIn) = year(getdate()) ) and Month(CheckIn) in ( month(getdate()), month(getdate())-1) and (lR.userId = @userId or lR.reportingTo = @userId) order by Status, CheckIn
end




end