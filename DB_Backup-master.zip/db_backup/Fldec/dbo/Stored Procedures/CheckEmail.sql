﻿
CREATE procedure [dbo].[CheckEmail](@Email nvarchar(2000))
as
begin
SELECT EmailId FROM tblUsers WHERE EmailId LIKE @Email;
select 1
end