﻿CREATE procedure [dbo].[DeleteMastersList](@TeamID int, @DesignationID int, @ProbationStatusID int)
as
begin

delete from tblTeam where TeamID = @TeamID
delete from tblDesignation where DesignationID = @DesignationID
delete from tblProbationStatus where ProbationStatusID = @ProbationStatusID
end
select * from tblTeam