﻿CREATE procedure [dbo].[Deleteinvoicelist](@InvoiceId int)
AS
begin  

delete from tblfdss_Invoice where InvoiceId = @InvoiceId
delete from tblfdss_ProductsInvoice where InvoiceId = @InvoiceId

end