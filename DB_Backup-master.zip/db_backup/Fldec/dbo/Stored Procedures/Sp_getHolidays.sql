﻿CREATE proc Sp_getHolidays
as
begin

Select DimId, convert(varchar(12), date, 103) as Date, description from tbldim where year(date) = year(getdate())

end