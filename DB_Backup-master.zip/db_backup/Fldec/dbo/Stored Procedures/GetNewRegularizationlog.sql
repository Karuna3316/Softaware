﻿
--[tblReconciliationNew]([RId] [int] IDENTITY(1,1) NOT NULL,[CheckIn] [datetime] not NULL,
--	[CheckOut] [datetime] not NULL, [Reason] [nvarchar](200) not NULL, userId int, reportingTo int,
--	status int not null default 0, status datetime, createddate datetime default getdate(),approvedUser

CREATE procedure [dbo].[GetNewRegularizationlog] (@stDate datetime, @endDate datetime, @userid int, @roleName varchar(50), @EmployeeId int = null)
as
begin
set @endDate = @endDate + 1

if (@roleName)  ='admin'
begin

if(@EmployeeId > 0 )

begin 

select userid, 

(select username from tblusers where userid=lR.userId) as userName,Convert(varchar(12), CheckIn,103) as CheckIn, CheckIn as Date,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userid = lR.reportingTo) as reportingUser 
from [tblReconciliationNew] lR where  userid = @EmployeeId and  
	CheckIn between @stDate and @endDate   
	order by [Date]
	end
	else
begin
	select userid, 
(select username from tblusers where userid=lR.userId) as userName,Convert(varchar(12), CheckIn,103) as CheckIn, CheckIn as Date,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userid = lR.reportingTo) as reportingUser 
from [tblReconciliationNew] lR where  
 --	( convert(varchar(10),CheckIn,101) >= convert(varchar(10),@stDate,101)
	--and convert(varchar(10),CheckIn,101) <= convert(varchar(10),@endDate,101))   
	CheckIn between @stDate and @endDate  
	order by [Date]
 
end

end

else
begin

if(@EmployeeId > 0)

begin

select userId, 

(select username from tblusers where userid=lR.userId) as userName,Convert(varchar(12), CheckIn,103) as CheckIn, CheckIn as Date,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userid = lR.reportingTo) as reportingUser 
from [tblReconciliationNew] lR where 
 	 convert(varchar(10),CheckIn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),CheckIn,101) <= convert(varchar(10),@endDate,101) order by [Date]
	end
else
begin
select userid, 
(select username from tblusers where userid=lR.userId) as userName,Convert(varchar(12), CheckIn,103) as CheckIn, CheckIn as Date,
reason,createdDate,[status],RId,reportingTo, 
(select UserName from tblUsers where userid = lR.reportingTo) as reportingUser 
from [tblReconciliationNew] lR where  
 	( convert(varchar(10),CheckIn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),CheckIn,101) <= convert(varchar(10),@endDate,101))     order by [Date]
 
end
end
end