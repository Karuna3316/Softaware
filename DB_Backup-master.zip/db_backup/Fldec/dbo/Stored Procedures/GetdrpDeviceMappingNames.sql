﻿
CREATE procedure [dbo].[GetdrpDeviceMappingNames]
as
begin


select userid,username from tblusers where active=1

end