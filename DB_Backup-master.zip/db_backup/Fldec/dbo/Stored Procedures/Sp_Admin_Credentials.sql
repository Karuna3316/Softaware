﻿create proc Sp_Admin_Credentials(@Emailid nvarchar(100))
as

begin
select tU.userId, UserName, tR.roleId, 

(select roleName from tblRoles where roleId=tR.roleId) as roleName, EmailId

from tblusers tU

join tblRoleMapping tR on tU.userId = tR.userId

where EmailId = @Emailid and active=1



end