﻿CREATE proc Sp_EmployeeReport  (@mon int, @vYear int)
as
begin

select EMPID as [EMP ID], EmployeeName as [Employee Name], 
[dbo].[fn_Role](userid) as Role , 
case when InternshipStartDate is null then 'NA' else Convert(varchar(12), InternshipStartDate,103) end as [Intership Start Date],
case when InternshipEndDate is null then 'NA' else Convert(varchar(12), InternshipEndDate,103) end as [Intership End Date],
case when DOJ is null then 'NA' else Convert(varchar(12), DOJ,103) end as [Date Of Joining],
case when Age is null then '0' else Age end as Age,
case when Fathername is null then 'NA' else Fathername end as [Father's Name],
case when Gender = 1 then 'Male' when gender = 2 then 'Female' else '0' end as [Gender],
case when MaritalStatus = 1 then 'Single' when MaritalStatus = 2 then 'Married' else 'NA' end as [Martial Status],
case when TenuredorFresher = 1 then 'Tenured' when TenuredorFresher = 2 then 'Fresher' else 'NA' end as [Tenured / Fresher],
case when dbo.fn_Team(TeamId) is null then 'NA'  else dbo.fn_Team(TeamId) end as [Team],
case when dbo.fn_Designation(DesignationId) is null then 'NA'  else  dbo.fn_Designation(DesignationId) end as [Designation],
--case when dbo.fn_Username(ReportingManagerId) is null then 'NA'  else dbo.fn_Username(ReportingManagerId) end as [Reporting Manager],
case when EmailId is null then 'NA' else EmailId end as [Official E-Mail ID],
case when [dbo].[fn_Probation] (ProbationStatusId) is null then 'NA'  else [dbo].[fn_Probation] (ProbationStatusId) end as [Probation Status],
case when ProbationPeriod is null then 'NA' else ProbationPeriod end as [Probation Period],
case when FLDECTenured is null then 'NA' else FLDECTenured end as [FLDEC Tenured],
case when PermanentAddress is null then 'NA' else PermanentAddress end as [Permanent Address],
case when TemporaryAddress is null then 'NA' else TemporaryAddress end as [Temporary Address],
case when AadhaarNo is null then 'NA' else AadhaarNo end as [Aadhaar No],
case when PANNo is null then 'NA' else PANNo end as [PAN No],
case when PFNO is null then 'NA' else PFNO end as [PF NO],
case when BankAccNo is null then 'NA' else BankAccNo end as [Bank A/C No],
case when BankIFSCCode is null then 'NA' else BankIFSCCode end as [Bank IFSC Code],
case when BankBranchName is null then 'NA' else BankBranchName end as [BankBranchName]
  
 from tblUsers with(nolock) where userid <> 1

 end