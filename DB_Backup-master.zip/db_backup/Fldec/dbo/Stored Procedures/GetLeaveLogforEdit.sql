﻿
CREATE procedure [dbo].[GetLeaveLogforEdit]   (@reqLId int)
as

begin
SELECT 
    reqLId, 
    (
        SELECT 
            CONVERT(VARCHAR(12), compOffDate, 103) + '  ' AS [text()]
        FROM 
            tblCompOffTakenFr
        WHERE 
            reqLId = @reqLId
        FOR XML PATH('')
    ) AS compOffTakenFrMultiple, 
    userId, 
    leaveType, 
    leaveDaysType, 
    leaveCategory,
    ISNULL(reportingTo, 0) AS reportingUser,
    CONVERT(VARCHAR(12), leaveStartedOn, 103) AS leaveStartedOn, 
    CONVERT(VARCHAR(12), leaveEndsOn, 103) AS leaveEndsOn,
    reason
FROM 
    tblRequestLeave 
WHERE 
    reqLId = @reqLId


end

--select(select item from [dbo].fnSplitString(convert(varchar(12),compOffDate,103),',')) as compOffTakenFrMultiple from tblCompOffTakenFr where reqLId = 156

--select * from tblRequestLeave order by createdDate desc

--select * from tblCompOffTakenFr