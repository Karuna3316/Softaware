﻿CREATE procedure [dbo].[UpateJobFromUI](@JOBID int, @docId int,@ResdexID1File nvarchar(500),@ResdexID2File nvarchar(500),@Name nvarchar(500),@FatherName nvarchar(500),@MobileNumber nvarchar(500),
@ScreeningID int,@ScreeningName nvarchar(500),@StatusID int,@Status nvarchar(500))
as
begin
if @JOBID >0
begin
update [tblJobdetails] set Name= @Name,ScreeningName=@ScreeningName,ScreeningID = @ScreeningID,Status=@Status,StatusID=@StatusID,@FatherName = @FatherName,MobileNumber = @MobileNumber,ResdexID#1 = @ResdexID1File,ResdexID#2 = @ResdexID2File
 where JOBID=@JOBID
end
else
begin
	insert into [tblJobdetails](Name,ScreeningID,ScreeningName,Status,StatusID,FatherName,MobileNumber,ResdexID#1,ResdexID#2)
	select @Name,@ScreeningID,@ScreeningName,@Status,@StatusID,@FatherName,@MobileNumber,@ResdexID1File,@ResdexID2File

	select @JOBID=max(JOBID) from [tblJobdetails]
	
end

if @docId >0
	update [tbldocument] set ResdexID#1 = @ResdexID1File,ResdexID#2 = @ResdexID2File,JOBID = @JOBID where docId = @docId
else
begin

insert into [tbldocument](JOBID,ResdexID#1,ResdexID#2)
select @JOBID, @ResdexID1File, @ResdexID2File
end
end