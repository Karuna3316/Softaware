﻿

CREATE procedure [dbo].[GetStatisticsLeaveBenefit]
as
begin
declare @Total int, @Approved int, @Declined int, @Pending int

set @Total = (Select  count(*) from tblLeaveBalanceMaster with(nolock) where  year(CreatedDate)= year(getdate()) and month(createddate) = month(getdate()))
set @Approved = (Select isnull(sum(CasualLeave),0) from tblLeaveBalanceMaster with(nolock) where  year(CreatedDate)= year(getdate()) and month(createddate) = month(getdate()))
set @Declined = (Select isnull(sum(SickLeave),0) from tblLeaveBalanceMaster with(nolock) where  year(CreatedDate)= year(getdate()) and month(createddate) = month(getdate()))
set @Pending = (Select isnull(sum(CasualLeave + SickLeave),0) from tblLeaveBalanceMaster with(nolock) where  year(CreatedDate)= year(getdate()) and month(createddate) = month(getdate()))

select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end