﻿--[GetAttendenceDailyFrMonthNYearApril26] 4,2022
create Procedure [dbo].[GetAttendenceDailyFrMonthNYear](@mon int,@vYear int)
as
begin
declare @tDates table(strDate varchar(50))
declare @sD int, @eD int,@curDay int

--if @vYear is null
--select @vYear = year(getdate())
if exists(
select tE.cnt from (
select count(AttendanceID) as cnt from tblAAttendance where month(checkindate)=@mon and year(checkindate)=@vYear) tE
where tE.cnt > 0)
begin

declare @dateToStartFrMon datetime

declare @dName int
select @dName=case @mon 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end
--fr a current month, wanted to show till date recs
--begins
if (year(getdate()) = @vYear and month(getdate()) = @mon)
set @dName=day(getdate())

--ends

declare @dv nvarchar(50)
set @dv='yy-mm-dd'
select @dv = replace(@dv,'yy',@vYear)
select @dv = replace(@dv,'mm',@mon)
select @dv = replace(@dv,'dd',@dName)
select @dateToStartFrMon = convert(datetime,@dv)

set @sD = 0
set @eD = @dName

while @sD <@eD
begin
insert into @tDates select convert(varchar,@dateToStartFrMon-(@eD-1),103)
set @eD = @eD - 1
end

declare @totalDays int
select  @totalDays = count(strDate)  from @tDates
   declare @dCols varchar(3000),@eQry nvarchar(max)
   declare @totCols varchar(3000)

    set @totCols = STUFF(
 (select '+[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') 
 
 set @dCols = STUFF(
 (select ',[' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')  
 
 --select @dCols

 declare @sCols varchar(max)
 set @sCols = STUFF(
 (select ',case when [' + strDate + ']=0 then ''A'' else ''P'' end as [' + strDate + ']' from @tDates           
 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'')

 declare @nQry nvarchar(max)
 
 set @eQry=' declare @tDates1 table(strDate datetime)
declare @sD1 int, @eD1 int,@curDay1 int


declare @dateToStartFrMon1 datetime
declare @dName1 int

select @dName1=case ' + convert(varchar,@mon) + ' 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end

if (year(getdate()) = ' + convert(varchar,@vYear)+' and month(getdate()) = ' + convert(varchar,@mon) +')
set @dName1=day(getdate())


declare @dv1 nvarchar(50)
set @dv1=''yy-mm-dd''
select @dv1 = replace(@dv1,''yy'','+convert(varchar,@vYear) +')
select @dv1 = replace(@dv1,''mm'',' + convert(varchar,@mon) + ')
select @dv1 = replace(@dv1,''dd'',@dName1)

select @dateToStartFrMon1 = convert(datetime,@dv1)

set @sD1 = 0
set @eD1 = @dName1

while @sD1 <@eD1
begin
insert into @tDates1 select @dateToStartFrMon1-(@eD1-1)
set @eD1 = @eD1 - 1

end

declare @totalHoliDays int
select @totalHoliDays = count(Date) from tblDim where DAY(Date)<= DAY(getdate()) and Month(Date)= Month(getdate())
 
	SELECT [UserName], [working days] -(hL*0.5) as [Total Present], (day(getdate()) -([working days]+@totalHoliDays)) + (hL*0.5)  as [Total Absent],' + @sCols + '
FROM (SELECT  
tU.UserName ,
       convert(varchar, checkindate,103) as [Days],
Checkin as [Presence]       
      FROM [tblAAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
       group by UserName,convert(varchar, checkindate,103),Checkin) A
      PIVOT( count(A.Presence)   
    FOR [Days] IN (' + @dCols +')
	) AS MNamePivot  join 
	(
	select sC.uname, [working days],hL from (
	select tU.UserName as uname, sum(case when checkin=1 then 1 end) as [working days] 

	   from [tblAAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where 
		--tA.userid in (25,28) and 
		month(checkindate) =' + convert(varchar,@mon) + '
	   group by tU.UserName,tA.userID) sC
	   
	   join
	   (
	   select tU.UserName as uname,  sum(case when reason=''Half day Leave'' then 1 else 0 end ) as hL 
 
	   from [tblAAttendance] tA
	  join tblUsers tU on tU.userId = tA.UserID
	    where  
		--tA.userid in (25,28) and 
		month(checkindate) =' + convert(varchar,@mon) + '
	   group by tU.UserName,tA.userID) hC on sC.uname = hC.uname
	   ) tL  on MNamePivot.UserName = tL.uname
	 '

--print @eQry

	exec(@eQry)
	end
end