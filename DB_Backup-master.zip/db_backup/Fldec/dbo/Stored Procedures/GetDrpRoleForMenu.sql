﻿CREATE procedure [dbo].[GetDrpRoleForMenu]
as
begin
  select roleId as RID,roleName as RName from tblRoles where roleName not in('Admin')
end