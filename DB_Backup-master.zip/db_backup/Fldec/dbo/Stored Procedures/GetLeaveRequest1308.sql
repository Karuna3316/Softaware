﻿create procedure [dbo].[GetLeaveRequest1308]  (@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
leaveType,leaveStartedOn, leaveEndsOn,reason,createdDate,isApproved,reqLId,leaveCategory,reportingTo,[Declined Reason] as DeclinedReason,
(select UserName from tblUsers where userId = reportingTo) as reportingUser from [tblRequestLeave] lR
end
else
begin
--declare @userName nvarchar(250)
--select @userName = username from tblUsers where userid=@userId
select userId, 
(select username from tblusers where userId=lR.userId) as userName,
leaveType,leaveStartedOn, leaveEndsOn,reason,createdDate,isApproved,reqLId,leaveCategory,reportingTo,[Declined Reason] as DeclinedReason, 
(select UserName from tblUsers where userId = reportingTo) as reportingUser from [tblRequestLeave] lR
where lR.userId = @userId or lR.reportingTo = @userId
end

end
--select isTeamLead, * from tblusers where userid=6
--update tblUsers set EmailId='pr@ii.gb' where userid=6
--select * from [tblRequestLeave] order by createddate desc