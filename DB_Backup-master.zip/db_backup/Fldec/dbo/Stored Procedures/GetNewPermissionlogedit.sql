﻿--select * from tblPermission
CREATE procedure [dbo].[GetNewPermissionlogedit] (@PId int)
as
begin

select PId, userid, (select username from tblUsers where userid = PR.userId) as username , PDatewithhour as checkin, reason, createddate , reportingTo,FORMAT (checkIn, 'yyyy-MM-dd') as checkIn ,
(select username from tblUsers where userid = PR.reportingTo) as reportingUser from tblPermission PR where PId =@PId 
  
	end