﻿CREATE procedure [dbo].[GetStatisticsMastersList]
as
begin
declare @Total int, @Approved int, @Declined int, @Pending int

set @Approved = (select count(*) from tblTeam lR with(nolock))
set @Declined =  (select count(*) from tblDesignation lR with(nolock))
set @Pending =(select count(*) from tblProbationStatus lR with(nolock))
set  @Total = (Select @Approved+@Declined+@Pending)
select @Total as Total, @Approved as Approved, @Declined as Declined, @Pending as Pending
end