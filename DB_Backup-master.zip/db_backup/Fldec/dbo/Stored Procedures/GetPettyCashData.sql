﻿CREATE Procedure [dbo].[GetPettyCashData] (@usId int)
as
begin
declare @roleN varchar(200)
select  @roleN= roleName from tblRoles tR
where roleId in (select roleId from tblrolemapping where userId=@usId)

if  @roleN='Admin' or  @roleN = 'Accounts'
begin
	select PettyCashID, (select shortNameFrSite from tblSiteNames where sId=siteid) as siteN,
	Description, DebitAmount, status, 
	convert(varchar,CreatedDate,103)  + ' ' + convert(varchar,CreatedDate,108) as cDate,
	(select UserName from tblUsers where userId= tPc.UserID) as pUName
	from [dbo].[tblPettyCashNew] tPc where [Status]  in (1,2) 
and DebitAmount is not null
	order by CreatedDate desc
end

else
begin
declare @uNa varchar(200)
select @uNa = UserName from tblUsers where userId= @usId
select PettyCashID,(select shortNameFrSite from tblSiteNames where sId=siteid) as siteN,
Description, DebitAmount, case when status = 1 then 'Pending' when status = 2 then 'Approved' when status = 3 then 'Rejected' when status = 4 then 'Verified' end as Status, 
convert(varchar,CreatedDate,103)  + ' ' + convert(varchar,CreatedDate,108) as cDate, @uNa as  pUName
from [dbo].[tblPettyCashNew] where UserID = @usId 
and DebitAmount is not null
and [Status] in (1,2) 
order by CreatedDate desc
end
end