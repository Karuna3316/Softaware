﻿--[GetSupportType] 
CREATE procedure [dbo].[GetSupportType]
as
begin

select SupportTypeId, SupportType from Mt_SupportType
end