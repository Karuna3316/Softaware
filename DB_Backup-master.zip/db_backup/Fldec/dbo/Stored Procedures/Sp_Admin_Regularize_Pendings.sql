﻿CREATE proc [dbo].[Sp_Admin_Regularize_Pendings]
as
begin


select UPPER(UserName) as EmployeeName, [dbo].[fn_RegularizationPendingCount](userId) as Count  from tblUsers with (nolock) where isTeamLead = 1 order by [dbo].[fn_RegularizationPendingCount](userId)  desc

end