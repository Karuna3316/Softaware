﻿Create proc GetWorkingDays (@userid int)

As 
begin

select style103 as Date, TheDayName as Day from datedimension where Theyear = year(getdate()) and Themonth = month(getdate())
and style103 not in (select convert(varchar(12), date, 103) from tblDim where YEAR(date) = year(getdate()) and MONTH(date) = month(getdate()))

end