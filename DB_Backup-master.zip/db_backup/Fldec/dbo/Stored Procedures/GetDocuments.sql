﻿--[GetDocuments] 25
CREATE procedure [dbo].[GetDocuments](@uId int)
as
begin
declare @projId varchar(500)
select @projId =projId from tblUsers where userId=@uId

select docId,
(select shortNameFrSite from tblsitenames where sId=siteId) as siteN,
docName, docFileName,
(select docType from tblDocumentTypes where docTypeId=tD.docTypeId) as docType,
createddate, (select username from tblUsers where userid = tD.userid) as uName
 from tblDocuments tD
where siteId in (select item from [dbo].[fnSplitString](@projId,','))
--userId = @uId 
order by createddate desc
end