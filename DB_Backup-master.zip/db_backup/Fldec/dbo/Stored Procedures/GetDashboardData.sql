﻿
create Procedure [dbo].[GetDashboardData]

as

begin
select 51 as [Header]
end