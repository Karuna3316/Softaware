﻿CREATE procedure [dbo].[GetAvailableLeave] (@userId int)
as
begin
declare @totalLeave int
select @totalLeave = totalLeaveCount from tblusers where userId = @userId
declare @halfDayLeave int, @multipleLeave int, @singleLeave int
select @halfDayLeave = count(reqLId)*0.5 from [tblRequestLeave] where userId=@userId and isApproved = 1 --and isHalfDay = 1
select @multipleLeave = sum(DATEDIFF(day,leaveStartedOn,leaveEndsOn+1)) from [tblRequestLeave] where userId=@userId and isApproved = 1 and leaveType = 2
select @singleLeave = count(reqLId) from [tblRequestLeave] where userId=@userId and isApproved = 1 and leaveType = 1

declare @remainingLeave int
set @remainingLeave = @totalLeave - (@halfDayLeave + isnull(@multipleLeave,0) + @singleLeave)
select @remainingLeave
end