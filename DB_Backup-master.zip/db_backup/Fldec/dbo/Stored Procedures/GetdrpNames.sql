﻿CREATE procedure [dbo].[GetdrpNames]
as
begin

select Id, Description from tblDropdown where Dropdowntype='ManualAttendace'

end