﻿
--select @slAlloted=sum(SickLeave) from [dbo].[tblLeaveBalanceMaster] where UserId=@userId
create procedure [dbo].[GetDashBoardFrAll]
as
begin
select 
(select username from tblUsers where userId=A.userId) [User],
slTot slOpening,slAvail slAvailed,
(slTot - slAvail) slBalance,
clTot clOpening,clAvail clAvailed, 
(clTot - clAvail) clBalance,
pending leaveReqPending,approved leaveReqApproved,rejected leaveReqRejected,totalLeave leaveTakenTillDate,
totalLeave -(slAvail + clAvail) lossOfPay,
(slAvail + clAvail) totSLCLAvailed
from (
select userId, 
(select sum(SickLeave) from [dbo].[tblLeaveBalanceMaster] where UserId=rL.userId) slTot,
sum(case when leaveType = 1 and leaveCategory=2 and isApproved=1 then 1
			when leaveType = 3 and leaveCategory=2 and isApproved=1 then 0.5
			when leaveType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,month(getdate()))
			else 0 end) slAvail,
			(select sum(CasualLeave) from [dbo].[tblLeaveBalanceMaster] where UserId=rL.userId) clTot,
			sum(case when leaveType = 1 and leaveCategory=1 and isApproved=1 then 1
			when leaveType = 3 and leaveCategory=1 and isApproved=1 then 0.5
			when leaveType= 2 and leaveCategory=1 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,month(getdate())) 
			else 0 end) clAvail,
			sum(case  when isApproved is null  then 1 else 0 end) as pending,
			sum(case  when isApproved = 1 then 1 else 0 end) as approved,
			sum(case  when isApproved = 2 then 1 else 0 end) as rejected,
			day(getdate()) -((select count(DimId) from tblDim where year(date)=year(getdate()) and month(date) = month(getdate()) and day(date)<=day(getdate()))+
(select count(UserID) from tblAAttendance where year(checkindate)=year(getdate()) and month(checkindate)=month(getdate()) and UserID=rL.userId
and day(checkindate) not in(select day(date) from tblDim where year(date)=year(getdate()) and month(date) = month(getdate()) and day(date)<=day(getdate()) )
and CAST(checkindate as time) <= CAST('12:30' as time) and 
CAST(checkoutdate as time) >= CAST('17:30' as time)) +
(select count(userId)*0.5 from tblAAttendance where year(checkindate)=year(getdate()) 
and month(checkindate)=month(getdate()) and UserID =rL.userId
and (CAST(checkindate as time) >= CAST('12:30' as time) or 
CAST(checkoutdate as time) <= CAST('17:30' as time)))) totalLeave
			
from tblRequestLeave  rL where    
 year(leaveStartedOn)=year(getdate()) and month(leaveStartedOn) = month(getdate()) 
group by userId) A
end
--and leaveType not in(4,5)
--select @slBalance = isnull(@slAlloted,0) - isnull(@slAvailed,0)