﻿

CREATE proc [dbo].[OverallReport_FinalDC]--2
@Siteid int

as

begin



WITH expression_name(PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,[Pending Billable Supply], SignedOffJMR,SignedDC, PutDC, PutDCMorJMR)   

AS   

(   

  

select SLNO, dbo.fn_Description(Slno), Quantity, Unit,isnull(dbo.fn_BilledDC(slno),0), isnull(dbo.fn_BilledJMR(slno),0), Isnull(convert(decimal(18,2),dbo.fn_BilledDC(slno)) - convert(decimal(18,2),dbo.fn_BilledJMR(slno)),0)  ,  isnull(dbo.fn_SignedOffJMR(slno),0), isnull(dbo.[fn_SignedOffDC](slno),0), 



isnull( Convert(decimal(18,2),dbo.fn_BilledDC(slno))- Convert(decimal(18,2),dbo.[fn_SignedOffDC](slno)),0  ),
isnull( Convert(decimal(18,2),dbo.fn_BilledJMR(slno))- Convert(decimal(18,2),dbo.[fn_SignedOffDC](slno)),0  )

from tblShortBOQ where SiteId = @Siteid and Slno <> 1000 and Quantity <> 0 



 )  



 select PONo, Description, BOQQty, Unit,  BilledDC, BilledJMR,ABS([Pending Billable Supply]) As [Billable Supply], SignedOffJMR, SignedDC,case when BilledDC < BilledJMR then PutDCMorJMR else  PutDC end  as  PutDC from expression_name  where PutDC > 0



 end