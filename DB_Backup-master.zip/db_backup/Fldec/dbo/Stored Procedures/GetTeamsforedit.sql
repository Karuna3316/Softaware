﻿CREATE proc [dbo].[GetTeamsforedit](@TeamId int)
as
begin


Select TeamId, FORMAT (createdDate, 'yyyy-MM-dd') as createdDate, Team from tblTeam where TeamID = @TeamId


end