﻿CREATE procedure GetTblMaterials
as
begin
select MaterialId as cId, MaterialName as cVal from [dbo].[VECtblMaterial]
union
select '0' as cId,'select' as cVal
end