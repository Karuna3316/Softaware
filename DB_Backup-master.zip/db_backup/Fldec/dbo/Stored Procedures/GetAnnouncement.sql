﻿
--GetTimeUtilization 1
create procedure [dbo].[GetAnnouncement](@userId int)
as
begin



select top 1 Text as Announcement from [dbo].[Mt_Announcement] order by AnnouncementId desc



 
end