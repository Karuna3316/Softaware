﻿

--Casual leave, Opening, 	Availed, 	Balance
--[GetDashboardDataFrLeave] 138
CREATE procedure [dbo].[GetDashboardDataFrLeave](@userId int)
as
begin
declare @monthVal int
set @monthVal=month(getdate())

declare @clAvailed decimal(10,1),@clAlloted decimal(10,1), @clBalance decimal(10,1)
select @clAlloted=isnull(sum(CasualLeave),0) from [dbo].[tblLeaveBalanceMaster] where UserId=@userId and month(createddate) <= month(getdate()) and year(CreatedDate)=year(getdate())

select @clAlloted = @clAlloted -isnull((select sum(case when (leaveType = 1 or leaveDaysType=1) then 1
			when (leaveType = 3 or leaveDaysType=3) then 0.5
			when (leaveType= 2 or leaveDaysType=2) then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where  leaveCategory=1 and userId=@userId and year(leaveStartedOn)=year(getdate())
and month(leaveStartedOn) <> @monthVal 
 and isApproved=1),0)

select @clAvailed = sum(case when (leaveType = 1 or leaveDaysType=1) then 1
			when (leaveType = 3 or leaveDaysType=3) then 0.5
			when (leaveType= 2 or leaveDaysType=2) then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where leaveCategory=1 and userId=@userId and year(leaveStartedOn)=year(getdate()) 
and month(leaveStartedOn) = @monthVal 
and isApproved=1
select @clBalance = isnull(@clAlloted,0) - isnull(@clAvailed,0)

declare @slAvailed decimal(10,1),@slAlloted decimal(10,1), @slBalance decimal(10,1)
select @slAlloted=isnull(sum(SickLeave),0) from [dbo].[tblLeaveBalanceMaster] where UserId=@userId and month(createddate) <= month(getdate()) and year(CreatedDate)=year(getdate())


select @slAlloted= @slAlloted -isnull(( select sum(case when (leaveType = 1 or leaveDaysType=1) then 1
			when (leaveType = 3 or leaveDaysType=3) then 0.5
			when (leaveType= 2 or leaveDaysType=2) then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where leaveCategory=2 and userId=@userId  and year(leaveStartedOn)=year(getdate())
 and month(leaveStartedOn) <> @monthVal
and isApproved=1),0)

select @slAvailed = sum(case when (leaveType = 1 or leaveDaysType=1) then 1
			when (leaveType = 3 or leaveDaysType=3) then 0.5
			when (leaveType= 2 or leaveDaysType=2) then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@monthVal) end)
from tblRequestLeave where leaveCategory=2 and userId=@userId  and year(leaveStartedOn)=year(getdate()) 
and month(leaveStartedOn) = @monthVal 
and isApproved=1
select @slBalance = isnull(@slAlloted,0) - isnull(@slAvailed,0)

declare @lPending decimal(10,1), @lApproved decimal(10,1), @lRejected decimal(10,1)
select @lPending = count(reqLId) from tblRequestLeave where userId=@userId and year(leaveStartedOn)=year(getdate()) and month(leaveStartedOn) = @monthVal and isApproved is null
select @lApproved=count(reqLId) from tblRequestLeave where userId=@userId and year(leaveStartedOn)=year(getdate()) and month(leaveStartedOn) = @monthVal and isApproved =1
select @lRejected=count(reqLId) from tblRequestLeave where userId=@userId and year(leaveStartedOn)=year(getdate()) and month(leaveStartedOn) = @monthVal and isApproved =2

declare @leaveTakenTillDate decimal(10,1)
declare @lossOfPay  decimal(10,1)

select @leaveTakenTillDate = day(getdate()) -
(
(select count(DimId) from tblDim where year(date)=year(getdate()) and month(date) = month(getdate()) and day(date)<=day(getdate()))+
(select count(UserID) from tblAAttendance where year(checkindate)=year(getdate()) and month(checkindate)=@monthVal and UserID=@userId
and day(checkindate) not in(select day(date) from tblDim where year(date)=year(getdate()) and month(date) = month(getdate()) and day(date)<=day(getdate()) )
and CAST(checkindate as time) <= CAST('12:00' as time) and 
CAST( case when cast (getdate() as date) = cast(checkindate as date) then isnull(checkoutdate,'17:00')
else checkoutdate  end as time) >= CAST('17:00' as time)) +
(select count(userId)*0.5 from tblAAttendance where year(checkindate)=year(getdate()) 
and month(checkindate)=month(getdate()) and UserID =@userId  and day(checkindate) not in(select day(date) from tblDim where year(date)=year(getdate()) and month(date) = month(getdate()) and day(date)<=day(getdate()) )
and (CAST(checkindate as time) >= CAST('12:00' as time) or 
CAST(checkoutdate as time) <= CAST('17:00' as time)))
)

declare @PermissionLOP decimal(10,1)


set @PermissionLOP =  (select [dbo].[fnCalcLOPFrPermission](@userId, @monthVal))


select @lossOfPay = @leaveTakenTillDate - (isnull(@clAvailed,0)+ isnull(@slAvailed,0)) + @PermissionLOP

 select convert(decimal(18,1),@clAlloted) as clOpening, isnull(@clAvailed,0) as clAvailed, @clBalance as clBalance,
		convert(decimal(18,1),@slAlloted) as slOpening, isnull(@slAvailed,0) as slAvailed , @slBalance as slBalance,
		@lPending as leaveReqPending , @lApproved as leaveReqApproved , @lRejected as leaveReqRejected,
		convert(decimal(18,1),@leaveTakenTillDate) as leaveTakenTillDate,convert(decimal(18,1),@lossOfPay) as lossOfPay, convert(decimal(18,1),(isnull(@clAvailed,0)+isnull(@slAvailed,0))) as totSLCLAvailed


end
--select * from tblRequestLeave where reqLId=7
--select * from tblRequestLeave where userId=20