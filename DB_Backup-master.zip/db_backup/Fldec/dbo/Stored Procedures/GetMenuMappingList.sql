﻿CREATE procedure [dbo].[GetMenuMappingList]
as
begin
SELECT T.menuMappingId, T.roleId, T.roleName
FROM (
    SELECT Rm.menuMappingId, RM.roleId, U.roleName,
           ROW_NUMBER() OVER (PARTITION BY U.roleName ORDER BY Rm.menuMappingId) AS rn
    FROM tblMenuMappingFrRole RM
    LEFT JOIN tblroles U ON RM.roleId = U.roleId
) T
WHERE T.rn = 1;

end