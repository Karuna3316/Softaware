﻿
--[dbo].[GetNewRegularizationData] '2021-02-04','2022-07-14',1,'Admin'

CREATE procedure [dbo].[GetNewRegularizationDatatest]   (@stDate datetime,@endDate datetime,@userId int,@roleName varchar(50))
as
begin
if @roleName ='admin'
begin
select case when userId is null then 0 else userId end as userId,'',
(select username from tblusers where userId=lR.userId) as [userName],CheckIn,--CheckOut,
convert(varchar(12),CheckIn,103) as Date, Status ,RId,ReportingTo, dbo.fn_username(reportingTo) as reportingUser, reason
from tblReconciliationNew lR
where 	 convert(varchar(10),CheckIn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),CheckIn,101) <= convert(varchar(10),@endDate,101)

end
else
begin

select case when userId is null then 0 else userId end as userId,'',
(select username from tblusers where userId=lR.userId) as [userName],CheckIn,--CheckOut,
convert(varchar(12),CheckIn,103) as Date, Status ,RId,ReportingTo, dbo.fn_username(reportingTo) as reportingUser, reason
from tblReconciliationNew lR
where lR.userId = @userId or lR.reportingTo = @userId and  convert(varchar(10),CheckIn,101) >= convert(varchar(10),@stDate,101)
	and convert(varchar(10),CheckIn,101) <= convert(varchar(10),@endDate,101)
end

end