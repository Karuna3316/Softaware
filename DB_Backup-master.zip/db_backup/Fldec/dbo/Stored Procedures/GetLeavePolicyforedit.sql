﻿create proc [dbo].[GetLeavePolicyforedit](@Id int)
as
begin

Select Id, IsPermission Permission,IsRegularise as Regularise,IsLeave as Leave, UserId, dbo.fn_username(userid) as EmployeeName from tblUsers where Id = @Id

end