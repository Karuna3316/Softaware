﻿CREATE proc [dbo].[Sp_PayrollregistratioView]
as
begin
select [dbo].[fn_EMPId](userid) as EMPID, dbo.fn_PayrollId(userid) as PId, dbo.fn_username(userid) as EmployeeName,   dbo.fn_BankAccno(userid) as BankAccNo, dbo.fn_AnnualCTC(userid) as AnnualCTC,
 dbo.fn_MonthlyCTC(userid) as MonthlyCTC,
  dbo.fn_GrossSalary(userid) as GrossSalary,
 dbo.fn_PF(userid)  as PF,
    dbo.fn_ProfessionalTax(userid) as ProfessionalTax,
	 dbo.fn_TotalDeductions(userid) as TotalDeductions,
	 dbo.fn_NetPay(userid) as NetPay
	,
	 [dbo].[fn_PayrollCreatedBy]  (userid) as UpdatedBy , [dbo].[fn_PayrollCreatedDate]  (userid) as UpdatedDate
	 
	  from tblusers where active = 1 and dbo.fn_PayrollId(userid) is not null  order by dbo.fn_username(userid)

	 
end