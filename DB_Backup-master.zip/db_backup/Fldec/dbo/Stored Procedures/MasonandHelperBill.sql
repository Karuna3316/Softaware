﻿CREATE proc MasonandHelperBill --5,5,12,'Stelis Bio Pharma Bangalo'
(@MansonRate int, @HelperRate int, @month int, @StartDate int, @EndDate int, @sitename varchar(150))
As
begin

 

with wagestable (Date,	Mason,	helper,	[Wages per Mason],	[Wages per Helper],	[Total Wages of Mason],	[Total Wages of Helper],	[Total Amount])
as
(
select convert(varchar(12), Createddate, 105) as Date, Mason, helper, @MansonRate as [Mason Wages], @HelperRate  as [Helper Wages] , Mason * @MansonRate as  [Total Wages of Mason] , Helper * @HelperRate as  [Total Wages of Mason] ,  (Mason * @MansonRate + Helper * @HelperRate) as  [Total Amount] from
 [dbo].[tblLabourReport] where month = @month and day between @StartDate and @EndDate and SiteName = @sitename
 )

 select * from wagestable union
 select 'Total', sum(Mason),	Sum(helper), Sum([Wages per Mason]),	Sum([Wages per Helper]),	Sum([Total Wages of Mason]),	Sum([Total Wages of Helper]),	Sum([Total Amount]) from wagestable


 end