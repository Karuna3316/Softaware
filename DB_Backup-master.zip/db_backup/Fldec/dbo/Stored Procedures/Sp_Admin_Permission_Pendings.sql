﻿CREATE proc [dbo].[Sp_Admin_Permission_Pendings]
as
begin


select UPPER(username) as  EmployeeName, [dbo].[fn_PermissionPendingCount](userid) as Count  from tblUsers with(nolock)   where isTeamLead = 1 order by [dbo].[fn_PermissionPendingCount](userid) desc

end