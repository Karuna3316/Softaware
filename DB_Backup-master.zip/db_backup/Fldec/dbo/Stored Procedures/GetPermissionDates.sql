﻿--GetPermissionDates 2
CREATE procedure [dbo].[GetPermissionDates](@userId int)
as
begin

select  convert(varchar(10), checkindate, 103) + ' (' + case when (Convert(varchar(10), datediff(MINUTE, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate))) > 1
 then   [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,  CheckInDate, convert(varchar(10),CheckInDate,121)+' 12:00:00.000')))) end + ')' as CheckInDate
 from tblAAttendance where month(checkindate) = month(getdate())  and -- checkout is not null  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) > 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
AND convert(varchar(10), checkindate, 103) + ' (' + case when (Convert(varchar(10), datediff(MINUTE, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate))) > 1
 then   [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,  CheckInDate, convert(varchar(10),CheckInDate,121)+' 12:00:00.000')))) end + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)
union
select convert(varchar(10), checkindate, 103) + ' (' + case when (Convert(varchar(10), datediff(MINUTE, convert(varchar(10),CheckOutDate,121)+' 17:00:00.000', CheckOutDate))) > 1
 and Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1
 then   [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,CheckOutDate,convert(varchar(10),CheckOutDate,121)+' 19:30:00.000')))) end + ')'  as CheckInDate
from tblAAttendance where month(checkindate) =  month(getdate()) and   checkout is not null  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 17:00:00.000', CheckOutDate)) > 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
AND convert(varchar(10), checkindate, 103) + ' (' + case when (Convert(varchar(10), datediff(MINUTE, convert(varchar(10),CheckOutDate,121)+' 17:00:00.000', CheckOutDate))) > 1
 and Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1
 then   [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,CheckOutDate,convert(varchar(10),CheckOutDate,121)+' 19:30:00.000')))) end + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where UserID =  @userId)
end 

--SELECT * FROM TBLPERMISSION

--insert into tblpermission(checkin, PDatewithhour, Reason, userid) values(CONVERT(DATETIME, SUBSTRING('06/10/2022 (01:24)',1,10),103),'06/10/2022 (01:24)' ,'test', 17)

--06/10/2022 (01:24)

--select * from tblAAttendance where userid = 33 order by CheckInDate desc