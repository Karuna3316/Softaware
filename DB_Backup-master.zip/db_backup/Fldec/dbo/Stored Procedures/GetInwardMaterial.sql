﻿CREATE Procedure [dbo].[GetInwardMaterial](@sN varchar(200)=null)
as
begin

with MaterialGrid
(MaterialName, Unit, Quantity, conDate)
as
(
select  MaterialName, Unit, Quantity, FORMAT(Createddate,'dd/MM/yyyy hh:mm') as conDate
--,SiteName 
from [dbo].[Mt_MaterialInward] where SiteName = isnull(@sN,SiteName)-- order by Createddate desc

union All

select  MaterialName, Unit, Quantity, FORMAT(Createddate,'dd/MM/yyyy hh:mm') as conDate
--,SiteName 
from [Mt_MaterialInwardNew] where SiteName = (select sId from [dbo].[tblSiteNames] where SiteName = isnull(@sN,SiteName))-- order by Createddate desc

)

select * from MaterialGrid order by conDate desc

end