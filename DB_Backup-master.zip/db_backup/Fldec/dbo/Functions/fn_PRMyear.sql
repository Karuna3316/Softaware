﻿create function [dbo].[fn_PRMyear]  
(  
   @Empname nvarchar(300) 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 year(Createddate) from tblPayrollM with(nolock) where EmpName = @Empname order by CreatedDate desc)  
end