﻿CREATE function [dbo].[fn_Dropdown]  
(  
   @Id int 
  
)  
returns nvarchar(500)  
as  
begin return(select Description from tblDropdown where Id = @Id)  
end