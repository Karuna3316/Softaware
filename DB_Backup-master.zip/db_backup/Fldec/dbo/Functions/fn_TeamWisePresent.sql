﻿create function [dbo].[fn_TeamWisePresent]  
(  
   @TeamID int 
  
)  
returns nvarchar(500)  
as  
begin return(
select isnull( Count(*), 0) from tblUsers with(nolock) where active = 1 and  TeamId is not null and TeamId <> 0 and TeamId = @TeamID and userid  in  (select userid from tblAAttendance with(nolock) where 
Convert(varchar(12), checkindate, 103) = Convert(varchar(12), getdate(), 103)) and userid  not  in (select userid from tblusers with(nolock) where active = 1 and projId is not null)


 )
end