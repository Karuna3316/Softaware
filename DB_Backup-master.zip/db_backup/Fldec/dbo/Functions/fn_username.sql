﻿CREATE function [dbo].[fn_username]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 upper(username) from tblusers where userid = @userid)  
end