﻿create function [dbo].[fn_productName]  
(  
   @pid int 
  
)  
returns nvarchar(500)  
as  
begin return(select ProductsName from [tblfdss_ProductsMaster] where ProductsID = @pid)  
end