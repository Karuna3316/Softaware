﻿create function  [dbo].[fn_VendorNowithid]--('1') 
(  
   @Vendorid varchar(150) 
  
)  
returns nvarchar(max)  
as  
begin return(select VendorNo  from tblVendor where Vendorid = @Vendorid)  
end