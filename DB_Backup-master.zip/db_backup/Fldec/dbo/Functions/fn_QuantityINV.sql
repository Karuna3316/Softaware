﻿create function [dbo].[fn_QuantityINV]  
(  
   @InventoryId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 Quantity from InvInwardRegister where InventoryId = @InventoryId)  
end