﻿create function [dbo].[fn_getSundayCount]  
(  
   @Month int ,
   @Year int
  
)  
returns int
as  
begin 


Declare @date datetime;
Set @date= (select cast(cast(@Year*10000 + @Month*100 + 1 as varchar(255)) as date))
Declare @count int
set @count = 0 
while DATEPART(Month,@date)=@Month
Begin

	--Select DATEPART(DAY,@date);
	--Select DATEPART( WEEKDAY, @DATE )
	DECLARE @Name VARCHAR(20)

	SELECT  @Name = CASE ( DATEPART(dw, @Date) + @@DATEFIRST ) % 7
                         WHEN 1 THEN 'Sunday'
                         WHEN 2 THEN 'Monday'
                         WHEN 3 THEN 'Tuesday'
                         WHEN 4 THEN 'Wednesday'
                         WHEN 5 THEN 'Thursday'
                         WHEN 6 THEN 'Friday'
                         WHEN 0 THEN 'Saturday'
                       END 
	If @Name='Sunday'
	Begin
		
		--Insert Data Into Your Table
		Select @count = @count + 1
	--	select @date
	End
	
	Set @date=DATEADD(Day,1,@date);	
End




return(Select @count)  
end