﻿CREATE function [dbo].[fn_MDeductions]  
(  
   @EmpName nvarchar(300) 
  
)  
returns Decimal(18,2)
as  
begin return(select top 1 Deductions from tblPayrollM  with(nolock) where EmpName = @EmpName order by CreatedDate desc)  
end