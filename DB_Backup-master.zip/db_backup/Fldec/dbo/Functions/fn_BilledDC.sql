﻿CREATE function [dbo].[fn_BilledDC]  
(  
   @SLNo nvarchar(30),
   @Siteid int
  
)  
returns nvarchar(500)  
as  
begin return(select Sum(Qty) from tblInvoiceSupply where SLNO = @SLNo and siteId =  @Siteid)  
end