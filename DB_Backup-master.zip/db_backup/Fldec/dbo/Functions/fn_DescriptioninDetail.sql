﻿CREATE function [dbo].[fn_DescriptioninDetail]  
(  
   @SLNo varchar(30) ,
   @SiteId int
  
)  
returns nvarchar(500)  
as  
begin return(select Descriptionindetail from tblShortBOQ where SLNO = @SLNo and SiteId = @SiteId)  
end