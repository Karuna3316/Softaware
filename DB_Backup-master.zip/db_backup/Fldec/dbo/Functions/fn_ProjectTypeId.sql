﻿CREATE function [dbo].[fn_ProjectTypeId]  
(  
   @InventoryId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 ProjectTypeId from InvInwardRegister where InventoryId = @InventoryId)  
end