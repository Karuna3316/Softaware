﻿CREATE function [dbo].[fn_userId]  
(  
   @InventoryId int 
  
)  
returns nvarchar(500)  
as  
begin return(select userId from tblUsers where InventoryId = @InventoryId)  
end