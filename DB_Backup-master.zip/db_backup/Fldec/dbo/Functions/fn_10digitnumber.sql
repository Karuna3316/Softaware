﻿CREATE function [dbo].[fn_10digitnumber]  
(  
   @name varchar(20) 
  
)  
returns nvarchar(500)  
as  
begin 

Declare @result nvarchar(20)
if(len(@name) = 10)
set @result = @name
else
begin
Set @name = REPLACE(REPLACE(@name, '+', ''),' ','')

if(len(@name) = 12)
begin 

Set @result =  right(@name, len(@name)-2)

end
else
begin
Set @result = @name
end
end
return @result
  
end