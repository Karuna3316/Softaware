﻿CREATE function [dbo].[fn_Description]  
(  
   @SLNo varchar(30) ,
   @Siteid int
  
)  
returns nvarchar(500)  
as  
begin return(select Description from tblShortBOQ where SLNO = @SLNo and SiteId = @Siteid)  
end