﻿CREATE function [dbo].[fn_MEmpName]  
(  
   @EmpName nvarchar(300) 
  
)  
returns nvarchar(300)
as  
begin return(select top 1 EmpName from tblPayrollM with(nolock) where EmpName = @EmpName order by CreatedDate desc)  
end