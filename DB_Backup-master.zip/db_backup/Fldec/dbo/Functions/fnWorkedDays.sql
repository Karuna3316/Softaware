﻿create FUNCTION  [dbo].[fnWorkedDays]
(  @userId int,
      @monV int,
      @yearV int 
)
RETURNS int
as
begin
declare @workedDays int
select @workedDays = count(UserID) from tblAAttendance where year(checkindate)=@yearV and month(checkindate)=@monV and UserID=@userId  
and CAST(checkindate as time) <= CAST('12:00' as time) and   CAST(checkoutdate as time) >= CAST('17:00' as time)
return @workedDays
end