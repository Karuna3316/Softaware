﻿create function [dbo].[fn_PayrollId]  
(  
   @userid int 
  
)  
returns int
as  
begin return(select top 1 PayrollID from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end