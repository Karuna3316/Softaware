﻿CREATE function [dbo].[fn_MonthlyCTC]  
(  
   @userid int 
  
)  
returns decimal(18,2) 
as  
begin return(select top 1 convert(decimal(18,2),GrossSalary/12 + isnull(EPFEmployerContribution,0)) from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end