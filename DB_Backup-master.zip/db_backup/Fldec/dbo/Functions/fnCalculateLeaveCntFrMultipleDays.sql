﻿
CREATE FUNCTION  [dbo].[fnCalculateLeaveCntFrMultipleDays]
(  
      @stDate datetime,
      @dateToEnd datetime,@mNo int
)
RETURNS int
as
begin
declare @leaveCnt int
set @leaveCnt =0;
WITH InRange(valD) AS 
(
    SELECT @stDate 
    UNION ALL
    SELECT DATEADD(d,1,valD) 
    FROM InRange 
    WHERE valD < @dateToEnd 
)

SELECT @leaveCnt = count(valD) from InRange where day(valD) not in (select day(date) from tblDim where year(date) = year(@dateToEnd) and month(date) = @mNo)
--where month(valD)=@mNo, this was written to handle [start date in one month and end date in another another month]
OPTION (MAXRECURSION 0)

return @leaveCnt
end

--select [dbo].[fnCalculateLeaveCntFrMultipleDays]('2022-12-24 00:00:00.000',	'2022-12-26 00:00:00.000',12)