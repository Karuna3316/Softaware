﻿CREATE function [dbo].[fn_MNetpay]  
(  
   @Empname nvarchar(300) 
  
)  
returns decimal(18,2)
as  
begin return(select top 1 Netpay from tblPayrollM with(nolock) where EmpName = @Empname order by CreatedDate desc)  
end