﻿CREATE function [dbo].[fn_MBankIFSCcode]  
(  
   @empname nvarchar(300) 
  
)  
returns nvarchar(300)
as  
begin return(select top 1 BankIFSCcode from tblPayrollM with(nolock) where EmpName = @empname order by CreatedDate desc)  
end