﻿CREATE function [dbo].[fn_Designation]  
(  
   @DesignationID int 
  
)  
returns nvarchar(500)  
as  
begin return(select Designation from tblDesignation with (nolock) where DesignationID = @DesignationID  )
end