﻿create function [dbo].[fn_groupname]  
(  
   @groupid int 
  
)  
returns nvarchar(500)  
as  
begin return(select GroupName from tblGroup where GroupId = @groupid)  
end