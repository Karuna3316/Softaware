﻿CREATE function [dbo].[fn_BoxType]  
(  
   @BoxTypeId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 BoxTypeName from InvtblBoxType where BoxTypeId = @BoxTypeId)  
end