﻿CREATE function [dbo].[fn_PONumber]  
(  
   @SuppID int 
  
)  
returns nvarchar(500)  
as  
begin return(select PONumber from tblfdss_Supplier where SuppID = @SuppID)  
end