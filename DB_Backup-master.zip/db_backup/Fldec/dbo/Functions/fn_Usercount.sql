﻿CREATE function [dbo].[fn_Usercount]  
(  
   @EmailId nvarchar(200)
  
)  
returns nvarchar(500)  
as  
begin return(

select (
(select isnull(count(*),0) from tblUsers with(nolock) where EmailId = @EmailId )
+ 
(select isnull(count(*),0) from Fldectest.dbo.tblUsers with(nolock) where EmailId = @EmailId )

) 

)  
end