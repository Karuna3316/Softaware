﻿create function [dbo].[fn_Partcode]  
(  
   @SLNo varchar(30) 
  
)  
returns nvarchar(500)  
as  
begin return(select Partcode from tblShortBOQ where SLNO = @SLNo and SiteId = 2)  
end