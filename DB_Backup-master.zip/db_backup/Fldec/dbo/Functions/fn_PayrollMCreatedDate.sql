﻿CREATE function [dbo].[fn_PayrollMCreatedDate]  
(  
  @EmpName nvarchar(300) 
  
)  
returns nvarchar(300) 
as  
begin return(select top 1 case when UpdatedDate is null then case when ActualCreatedDate is null then  Convert(Varchar(12), CreatedDate, 103) else Convert(Varchar(12), ActualCreatedDate, 103) end  else Convert(Varchar(12), UpdatedDate, 103) end  from tblPayrollM with(nolock) where EmpName = @EmpName order by CreatedDate desc)  
end