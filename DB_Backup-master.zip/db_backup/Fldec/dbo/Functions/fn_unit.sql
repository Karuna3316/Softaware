﻿create function [dbo].[fn_unit]  
(  
   @SLNo varchar(30) 
  
)  
returns nvarchar(500)  
as  
begin return(select Unit from tblShortBOQ where SLNO = @SLNo and SiteId = 2)  
end