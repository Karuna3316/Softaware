﻿create function [dbo].[fn_Part]  
(  
   @PartId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 PartNo from InvtblPartNo where Partid = @PartId)  
end