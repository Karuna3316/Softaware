﻿create function [dbo].[fn_DescriptionINVNew]  
(  
   @PartId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 Description from InvtblPartNo where PartId = @PartId)  
end