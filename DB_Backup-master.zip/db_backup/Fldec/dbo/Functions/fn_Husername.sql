﻿CREATE function [dbo].[fn_Husername]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select username from [dbo].[tblausers] where userid = @userid)  
end