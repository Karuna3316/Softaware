﻿CREATE function [dbo].[fn_Vehicleno]  
(  
   @DriverId int 
  
)  
returns nvarchar(500)  
as  
begin return(select [VehicleNo] from [Menaka].[dbo].tbldriver where Driverid = @DriverId)  
end