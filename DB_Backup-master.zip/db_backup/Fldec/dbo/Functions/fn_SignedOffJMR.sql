﻿CREATE function [dbo].[fn_SignedOffJMR]  
(  
   @SLNo nvarchar(30),
     @Siteid int 
  
)  
returns nvarchar(500)  
as  
begin return(select Sum(Qty) from tblJMR where SLNO = @SLNo and siteId = @Siteid)  
end