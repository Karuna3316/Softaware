﻿CREATE function [dbo].[fn_MEarnings]  
(  
   @EmpName nvarchar(300) 
  
)  
returns decimal(18,2)
as  
begin return(select top 1 Earnings from tblPayrollM with(nolock) where EmpName = @EmpName order by CreatedDate desc)  
end