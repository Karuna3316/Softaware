﻿CREATE function [dbo].[fn_CustomerName]  
(  
   @CID int 
  
)  
returns nvarchar(500)  
as  
begin return(select CompanyName from tblfdss_CustomerMaster where CID = @CID)  
end