﻿CREATE function  [dbo].[fn_VendorNamewithidNew]--('1') 
(  
   @Vendorid varchar(150) 
  
)  
returns nvarchar(max)  
as  
begin return(select ltrim(rtrim(JobNature))   from tblNVendor where Vendorid = @Vendorid)  
end