﻿
CREATE function [dbo].[slOpeningOnCurMnth]  
(  
   @uId int, @mnth int
  
)  
returns decimal(10,1) 
as 
begin 

declare @slTillLM decimal(10,1)
select @slTillLM=sum(SickLeave) from [dbo].[tblLeaveBalanceMaster] where UserId=@uId and month(CreatedDate)<=@mnth

select @slTillLM = @slTillLM - isnull((select sum(case when (leaveType = 1 or leaveDaysType=1) then 1
			when (leaveType = 3 or leaveDaysType=3) then 0.5
			when (leaveType= 2 or leaveDaysType=2) then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mnth) end)
from tblRequestLeave where  leaveCategory=2 and userId=@uId and year(leaveStartedOn)=year(getdate())
and month(leaveStartedOn) < @mnth
 and isApproved=1),0.0)
 
 return isnull(@slTillLM,0.0)
 end