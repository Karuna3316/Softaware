﻿CREATE function [dbo].[fn_Team]  
(  
   @TeamID int 
  
)  
returns nvarchar(500)  
as  
begin return(select Team from tblTeam with (nolock) where TeamID = @TeamID  )
end