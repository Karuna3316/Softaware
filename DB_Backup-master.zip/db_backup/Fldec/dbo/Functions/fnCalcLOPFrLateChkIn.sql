﻿
--select [dbo].[fnCalcLOPFrLateChkIn](9, 11)
CREATE function [dbo].[fnCalcLOPFrLateChkIn](@userId int, @month int)
returns decimal(10,1)
as
begin


declare @totalPenality decimal(10,1)


set @totalPenality = 0

 select @totalPenality =  case when (count(*) >=5  and count(*) < 9) then 1 when (count(*) >=10 and count(*) < 14) then 2 when (count(*) >=15 and count(*) < 19) then 3 when count(*) >=20 then 4 else 0 end 
from tblaattendance where UserID=@userId and month(checkindate)=@month and 
convert(varchar(12), checkindate, 103) not in (select convert(varchar(12), checkin, 103) from tblReconciliationNew where UserID=@userId and month(checkin)=@month and status = 1)
--and CAST(checkindate as time) > CAST('10:00' as time)
and ((DATEPART(hour, CheckInDate) >= 9  and  DATEPART(MINUTE, CheckInDate) >=51) or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) =0 ))  and ( DATEPART(hour, CheckInDate) <= 10)

return @totalPenality 
end