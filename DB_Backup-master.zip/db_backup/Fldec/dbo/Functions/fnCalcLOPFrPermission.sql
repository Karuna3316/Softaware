﻿--select [dbo].[fnCalcLOPFrPermission](17, 12)
create function [dbo].[fnCalcLOPFrPermission](@userId int, @month int)
returns decimal(10,1)
as
begin


declare @totalPenality decimal(10,1)


set @totalPenality = 0

if exists (select Userid from tblusers with(nolock) where active = 1 and IsPermission = 1 and userid = @userId)
set @totalPenality = 0
else if(@userId = 48 or @userId = 49)
begin
;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(CheckInDate) = year(getdate()) and month(checkindate) = @month  and convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)

union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:00')) ))) + ')'  as CheckInDate
from tblAAttendance where year(CheckInDate) = year(getdate()) and  month(checkindate) =  @month and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 18:59:00.000', CheckOutDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)
)
select @totalPenality =   (Count(*) - isnull( [dbo].[fnPermissionAppliedCount](userid),0)) * 0.5   from cte   group by userid having Count(*) - isnull( [dbo].[fnPermissionAppliedCount](userid),0) > 0
end
else if(@userId = 95)
begin
;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(CheckInDate) = year(getdate()) and  month(checkindate) = @month  and convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)

union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'18:30')) ))) + ')'  as CheckInDate
from tblAAttendance where year(CheckInDate) = year(getdate()) and  month(checkindate) =  @month and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 18:29:00.000', CheckOutDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)
)
select @totalPenality =   (Count(*) - isnull( [dbo].[fnPermissionAppliedCount](userid),0)) * 0.5   from cte   group by userid having Count(*) - isnull( [dbo].[fnPermissionAppliedCount](userid),0) > 0
end
else
begin
;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(CheckInDate) = year(getdate()) and  month(checkindate) = @month  and convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)

union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as CheckInDate
from tblAAttendance where year(CheckInDate) = year(getdate()) and  month(checkindate) =  @month and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)
)
select @totalPenality =   (Count(*) - isnull( [dbo].[fnPermissionAppliedCount](userid),0)) * 0.5   from cte   group by userid having Count(*) - isnull( [dbo].[fnPermissionAppliedCount](userid),0) > 0
end

return @totalPenality 
end