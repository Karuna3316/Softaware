﻿CREATE function  [dbo].[fn_VendorId]  --(' 4POP ')
(  
   @Vendorno varchar(150) 
  
)  
returns nvarchar(500)  
as  
begin return(select VendorID from tblVendor where VendorNo = LTRIM(Rtrim(@Vendorno)))  
end