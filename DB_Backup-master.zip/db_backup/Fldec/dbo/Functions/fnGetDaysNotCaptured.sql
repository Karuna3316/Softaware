﻿--declare @toC int
--select @toC = dbo.fnGetDaysNotCaptured(6,20)
--select @toC
create FUNCTION  [dbo].fnGetDaysNotCaptured
(  
      @month int,
      @userId int
)
RETURNS int
as
begin
declare  @tblDaysCaptured TABLE (dayVal int)
insert into @tblDaysCaptured(dayVal)
select day(checkindate) from tblaattendance where UserID=@userId and month(checkindate)=@month

insert into @tblDaysCaptured(dayVal)
select day(Date) from tbldim where month(Date)=@month and day(Date) not in (
select dayVal from @tblDaysCaptured)

insert into @tblDaysCaptured(dayVal)
select day(leaveStartedOn) from tblRequestLeave  where 
UserID=@userId and month(leaveStartedOn)=@month and leaveType <> 2
and day(leaveStartedOn) not in (select dayVal from @tblDaysCaptured)

declare @tblReqLeaveIdFrTypeTwo table(rIdFrLR int identity(1,1),reqId int)
insert into @tblReqLeaveIdFrTypeTwo(reqId)
select reqLId from tblRequestLeave where 
UserID=@userId and month(leaveStartedOn)=@month and leaveType =2

declare @totRows int, @stRow int
select @totRows =max(reqId),@stRow=1 from @tblReqLeaveIdFrTypeTwo

while @stRow <=@totRows
begin
    declare @idToGet int
	select @idToGet = reqId from @tblReqLeaveIdFrTypeTwo where rIdFrLR = @stRow  
	insert into @tblDaysCaptured(dayVal)
	select dayValue from dbo.fnGetValuesWithinRange((select day(leaveStartedOn) from tblRequestLeave where reqLId =@idToGet),(select day(leaveEndsOn) from tblRequestLeave where reqLId =@idToGet))
	where dayValue not in (select dayVal from @tblDaysCaptured)

	
	set @stRow = @stRow+1
end
declare  @daysFrMonth int

select @daysFrMonth=case @month 
when 12 then 31 
when 11 then 30 
when 10 then 31 
when 9 then 30 
when 8 then 31 
when 7 then 31 
when 6 then 30 
when 5 then 31 
when 4 then 30
when 3 then 31 
when 2 then 28 
when 1 then 31 
end

return @daysFrMonth - (select count(dayVal) from @tblDaysCaptured)
end