﻿create function [dbo].[fn_leave]  
(  
   @CreateLeaveBalanceID int 
  
)  
returns nvarchar(500)  
as  
begin return(select CreateLeaveBalance from tblLBC where CreateLeaveBalanceID = @CreateLeaveBalanceID)  
end