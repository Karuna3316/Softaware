﻿--DECLARE @startDay int
--DECLARE @endDay int
--select @StartDateTime = day(leaveStartedOn), @EndDateTime = day(leaveStartedOn) from tblRequestLeave  where UserID=117 and month(leaveStartedOn)=6;
----SET @StartDateTime = '2015-01-01'
----SET @EndDateTime = '2015-01-12';
--select * from fnGetValuesWithinRange(23,27)
create FUNCTION  [dbo].fnGetValuesWithinRange
(  
      @sDay int,
      @eDay int
)
RETURNS @tblRange TABLE (dayValue int)
as
begin
while @sDay <=@eDay
begin
	insert into @tblRange(dayValue) select @sDay
	set @sDay = @sDay+1
end
--WITH InRange(valD) AS 
--(
--    SELECT @sDay as int
--    UNION ALL
--    SELECT @sDay + 1
--    FROM InRange 
--    WHERE valD < @eDay
--)
--insert into @tblRange(dayVal)
--SELECT valD from InRange
--OPTION (MAXRECURSION 0)
return
end