﻿CREATE FUNCTION  dbo.fnSplitString--('Test : Input',':')
(    
      @Input NVARCHAR(MAX),
      @Character CHAR(1)
)
RETURNS @Output TABLE ( ID int , 
      Item NVARCHAR(max)
)
AS
BEGIN
      DECLARE @StartIndex INT, @EndIndex INT, @Rowcount int,@availableRowCount int


      SET @StartIndex = 1
      Set @Rowcount = 1
	  set @availableRowCount = 1
      IF SUBSTRING(@Input, LEN(@Input) - 1, LEN(@Input)) <> @Character
      BEGIN
            SET @Input = @Input + @Character
      END
 
      WHILE CHARINDEX(@Character, @Input) > 0
      BEGIN
            SET @EndIndex = CHARINDEX(@Character, @Input)
           
		    if len(SUBSTRING(@Input, @StartIndex, @EndIndex - 1)) >0
			begin
            INSERT INTO @Output(ID,Item)
            SELECT @availableRowCount , rtrim(ltrim(SUBSTRING(@Input, @StartIndex, @EndIndex - 1) ))
			--where len(SUBSTRING(@Input, @StartIndex, @EndIndex - 1)) >0
			set @availableRowCount = @availableRowCount + 1
            end
            SET @Input = SUBSTRING(@Input, @EndIndex + 1, LEN(@Input))
            Set @RowCount = @RowCount + 1
      END
 
      RETURN
END