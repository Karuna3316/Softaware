﻿create function [dbo].[fn_Probation]  
(  
   @ProbationID int 
  
)  
returns nvarchar(500)  
as  
begin return(select ProbationStatus from tblProbationStatus with (nolock) where ProbationStatusID = @ProbationID  )
end