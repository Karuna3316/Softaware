﻿CREATE FUNCTION [dbo].[fnPermissionCountADB]
()

RETURNS int
AS

BEGIN
DECLARE @AppliedCount int
DECLARE @AppliedCount1 int

;with cte1 as ( 


select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(checkindate) = year(getdate()) and  month(checkindate) = month(getdate()) and  day(checkindate) not in (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid in (15, 17,18,23,33,103,131,25,59,88,98,112)


union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as CheckInDate
from tblAAttendance where year(checkindate) = year(getdate()) and  month(checkindate) = month(getdate())  and   checkout is not null  and  day(checkindate) not in (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid in (15, 17,18,23,33,103,131,25,59,88,98,112)
)

select @AppliedCount1 = (select  ISNULL(count(*),0) from cte1 )

;with cte as ( 


select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(checkindate) = year(getdate()) and  month(checkindate) = month(getdate())   and  day(checkindate) not in (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid not in (15, 17,18,23,33,103,131,25,59,88,98,112)


union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as CheckInDate
from tblAAttendance where year(checkindate) = year(getdate()) and  month(checkindate) = month(getdate())  and   checkout is not null   and  day(checkindate) not in (select day(Date) from dbo.tblDim where month([date])= month(getdate()) and year([Date]) =Year(getdate()))  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid not in  (15, 17,18,23,33,103,131,25,59,88,98,112)
)

select @AppliedCount = (select  ISNULL(count(*),0) from cte )



RETURN @AppliedCount + @AppliedCount1
end

--select [dbo].[fnPermissionCountADB] ()