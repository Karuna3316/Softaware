﻿create FUNCTION [dbo].[fnPermissionCount]
(
 @Userid int
)

RETURNS int
AS

BEGIN
DECLARE @AppliedCount int

;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(checkindate) = year(getdate()) and  month(checkindate) = month(getdate())  and -- checkout is not null  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  in (SELECT PDatewithhour FROM TBLPERMISSION where status = 1 and UserID =  @userId)

union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as CheckInDate
from tblAAttendance where year(checkindate) = year(getdate()) and  month(checkindate) = month(getdate())  and   checkout is not null  and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  in  (SELECT PDatewithhour FROM TBLPERMISSION where status = 1 and UserID =  @userId)
)


select @AppliedCount = (select  ISNULL(count(*),0) from cte where userid = @Userid group by userid )

RETURN @AppliedCount
end