﻿CREATE function [dbo].[fn_Help]  
(  
   @HelpmenuId int 
  
)  
returns nvarchar(500)  
as  
begin return(select Description from tblhelpmenus with (nolock) where HId = @HelpmenuId )
end