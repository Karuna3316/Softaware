﻿create function [dbo].[fn_EMPId]  
(  
   @Userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 EMPID from tblUsers with(nolock) where userid = @Userid)  
end