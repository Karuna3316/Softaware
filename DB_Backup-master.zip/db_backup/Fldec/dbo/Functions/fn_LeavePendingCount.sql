﻿create function [dbo].[fn_LeavePendingCount]  
(  
   @userid int 
  
)  
returns int  
as  
begin return(
select count(*) as Count from tblRequestLeave where reportingTo = @userid and  year(leavestartedOn) = year(getdate()) and month(leavestartedOn) = 2 and approvedUser is null 
 )  
end