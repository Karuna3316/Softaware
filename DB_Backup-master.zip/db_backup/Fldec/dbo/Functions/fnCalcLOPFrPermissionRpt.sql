﻿

--select * from tblusers where UserName like '%pus%'
--select [dbo].[fnCalcLOPFrPermission](17, 12)
create function [dbo].[fnCalcLOPFrPermissionRpt](@userId int, @month int, @year int)
returns decimal(10,1)
as
begin


declare @totalPenality decimal(10,1)


set @totalPenality = 0

if(@userId = 33 or @userId = 148 or @userId = 131)
set @totalPenality = 0
else if(@userId = 48 or @userId = 49)
begin
;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(Checkindate) = @year and month(checkindate) = @month  and convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month and year(date) = @year) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)

union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:00')) ))) + ')'  as CheckInDate
from tblAAttendance where year(Checkindate) = @year and month(checkindate) =  @month and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month and year(date) = @year ) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 18:59:00.000', CheckOutDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)
)
select @totalPenality =   (Count(*) - isnull( [dbo].[fnPermissionAppliedCountRPT](@userId, @month,@year),0)) * 0.5   from cte   group by userid having Count(*) - isnull( [dbo].[fnPermissionAppliedCountRPT](@userId, @month,@year),0) > 0
end
else if(@userId = 95)
begin
;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(Checkindate) = @year and month(checkindate) = @month  and convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month and year(date) = @year) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)

union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'18:00')) ))) + ')'  as CheckInDate
from tblAAttendance where year(Checkindate) = @year and month(checkindate) =  @month and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month and year(date) = @year) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 17:59:00.000', CheckOutDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)
)
select @totalPenality =   (Count(*) - isnull( [dbo].[fnPermissionAppliedCountRPT](@userId, @month,@year),0)) * 0.5   from cte   group by userid having Count(*) - isnull( [dbo].[fnPermissionAppliedCountRPT](@userId, @month,@year),0) > 0
end
else
begin
;with cte as ( 
select userid, convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')'  as CheckInDate
 from tblAAttendance where year(Checkindate) = @year and month(checkindate) = @month  and convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month and year(date) = @year) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 10:00:00.000', CheckInDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckInDate,121)+' 12:00:00.000', CheckInDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +  [dbo].[fn_Breakcalc] ((Convert(int, datediff(minute,   convert(varchar(10),CheckInDate,121)+' 10:00:00.000',CheckInDate)))) + ')' not in (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)

union
select userid, convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')'  as CheckInDate
from tblAAttendance where year(Checkindate) = @year and month(checkindate) =  @month and   checkout is not null  and  convert(varchar(12), checkindate,103) not in (select convert(varchar(12), date,103) from tblDim where month(date) = @month and year(date) = @year) and
(Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 16:59:00.000', CheckOutDate)) >= 1 and
Convert(varchar(10), datediff(minute, convert(varchar(10),CheckOutDate,121)+' 19:29:00.000', CheckOutDate)) < 1) and userid =  @userId
--and convert(varchar(10), checkindate, 103) + ' (' +   [dbo].[fn_Breakcalc](convert(varchar, DATEDIFF(MINUTE, CheckOutDate, convert(datetime, convert(date,CheckOutDate) ) + convert(datetime,convert(time,'19:30')) ))) + ')' not in  (SELECT PDatewithhour FROM TBLPERMISSION where status = 1)-- where UserID =  @userId)
)
select @totalPenality =   (Count(*) - isnull( [dbo].[fnPermissionAppliedCountRPT](@userId, @month,@year),0)) * 0.5   from cte   group by userid having Count(*) - isnull( [dbo].[fnPermissionAppliedCountRPT](@userId, @month,@year),0) > 0
end

return @totalPenality 
end