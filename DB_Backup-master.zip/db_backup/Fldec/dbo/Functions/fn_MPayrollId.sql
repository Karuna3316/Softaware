﻿CREATE function [dbo].[fn_MPayrollId]  
(  
   @EmpName nvarchar(300) 
  
)  
returns int
as  
begin return(select top 1 PayrollID from tblPayrollM where EmpName = @EmpName order by CreatedDate desc)  
end