﻿CREATE function [dbo].[fn_VECClient]  
(  
   @ClientId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 [ClientName] from [dbo].[VECtblClient] where [ClientId] = @ClientId)  
end 


--select * from  [dbo].[VECtblTripdetails]