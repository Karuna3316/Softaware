﻿create function [dbo].[fn_sitenameshort]  
(  
   @siteid int 
  
)  
returns nvarchar(500)  
as  
begin return(select shortNameFrSite from tblSiteNames where sid = @siteid)  
end