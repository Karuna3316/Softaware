﻿--select [dbo].[fnLeaveAvaildedRpt](17, 12)
create function [dbo].[fnLeaveAvaildedRpt](@userId int, @month int, @year int)
returns decimal(10,1)
as
begin


declare @totalLeaveAvailed decimal(10,1)


set @totalLeaveAvailed = 0

set @totalLeaveAvailed = (select 

isnull(sum(case when leaveDaysType = 1 and leaveCategory=2 and isApproved=1 then 1	
			when leaveDaysType = 3 and leaveCategory=2  then 0.5
			when leaveDaysType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@month)
			else 0 end),0) + 
isnull(sum(case when leaveType = 1 and leaveCategory=2 and isApproved=1 then 1	
			when leaveType = 3 and leaveCategory=2  then 0.5
			when leaveType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@month)
			else 0 end),0) + 
		
			isnull(sum(case when leaveDaysType = 1 and leaveCategory=1 then 1
			when leaveDaysType = 3 and leaveCategory=1 then 0.5
			when leaveDaysType= 2 and leaveCategory=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@month) 
			else 0 end),0) + 
			isnull(sum(case when leaveType = 1 and leaveCategory=1 then 1
			when leaveType = 3 and leaveCategory=1  then 0.5
			when leaveType= 2 and leaveCategory=1  then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@month) 
			else 0 end),0)
			
from
tblRequestLeave  where isApproved=1 and userId = @userId and
 year(leaveStartedOn)= @year and month(leaveStartedOn) = @month
 group by userId)

return @totalLeaveAvailed 
end