﻿

--select [dbo].[fn_TimePercentageCalc]  ()

CREATE function [dbo].[fn_TimePercentageCalc]  
(  
  
  @userid int
)  
returns nvarchar(5)  
as  
begin 


declare @resultbreak int
declare @Hours int
set @Hours = (select Convert(varchar(10), datediff(minute, convert(varchar(10),getdate(),121)+' ' + (select convert(varchar(8), (select checkindate from tblAAttendance where userid = @userid and convert(varchar(12), checkindate,103) = convert(varchar(12),getdate(),103)),108) 'hh:mi:ss'),getdate())))

if (@Hours <30 ) 

set @resultbreak = 0
else if (@Hours >=30 and @Hours <60 ) 
set @resultbreak = 5
else if (@Hours >=60 and @Hours <90 ) 
set @resultbreak = 10
else if (@Hours >=90 and @Hours <120 ) 
set @resultbreak = 15
else if (@Hours >=120 and @Hours <150 ) 
set @resultbreak = 20
else if (@Hours >=150 and @Hours <180 ) 
set @resultbreak = 25
else if (@Hours >=180 and @Hours <210 ) 
set @resultbreak = 30
else if (@Hours >=210 and @Hours <240 ) 
set @resultbreak = 35
else if (@Hours >=240 and @Hours <270 ) 
set @resultbreak = 40
else if (@Hours >=270 and @Hours <300 ) 
set @resultbreak = 45
else if (@Hours >=300 and @Hours <330 ) 
set @resultbreak = 50
else if (@Hours >=330 and @Hours <360 ) 
set @resultbreak = 55
else if (@Hours >=360 and @Hours <390 ) 
set @resultbreak = 60
else if (@Hours >=390 and @Hours <420 ) 
set @resultbreak = 65
else if (@Hours >=420 and @Hours <450 ) 
set @resultbreak = 70
else if (@Hours >=450 and @Hours <480 ) 
set @resultbreak = 75
else if (@Hours >=480 and @Hours <510 ) 
set @resultbreak = 80
else if (@Hours >=510 and @Hours <540 ) 
set @resultbreak = 85
else if (@Hours >=540 and @Hours <570 ) 
set @resultbreak = 90
else if (@Hours >=570 and @Hours <600 ) 
set @resultbreak = 95
else if (@Hours >=600 and @Hours <630 ) 
set @resultbreak = 100
else if (@Hours >=630) 
set @resultbreak = 100
else
set @resultbreak = 0



return @resultbreak

end 

--