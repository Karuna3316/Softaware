﻿create function [dbo].[fn_ProjectId]  
(  
   @InventoryId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 ProjectId from InvInwardRegister where InventoryId = @InventoryId)  
end