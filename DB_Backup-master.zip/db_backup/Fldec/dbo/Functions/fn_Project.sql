﻿create function [dbo].[fn_Project]  
(  
   @ProjectId int 
  
)  
returns nvarchar(500)  
as  
begin return(select ProjectName from InvtblProject where ProjectId = @ProjectId)  
end