﻿create function [dbo].[fn_BankAccno]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select BankAccNo from tblusers where userid = @userid)  
end