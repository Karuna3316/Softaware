﻿CREATE function [dbo].[fn_MEMPId]  
(  
   @EmpName nvarchar(300) 
  
)  
returns nvarchar(30)
as  
begin return(select top 1 EmpId from tblPayrollM with(nolock) where EmpName = @EmpName order by CreatedDate desc)  
end