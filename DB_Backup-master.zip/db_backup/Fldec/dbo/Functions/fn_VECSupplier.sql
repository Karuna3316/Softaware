﻿CREATE function [dbo].[fn_VECSupplier]  
(  
   @SupplierId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 [SupplierName] from [dbo].[VECtblSupplier] where [SupplierId] = @SupplierId)  
end 


--select * from  [dbo].[VECtblTripdetails]