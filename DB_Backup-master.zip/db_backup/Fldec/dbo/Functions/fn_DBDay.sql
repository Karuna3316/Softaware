﻿CREATE function [dbo].[fn_DBDay]  
(@date datetime)
returns nvarchar(500)  
as  
begin return(select TheDayName from datedimension where Theyear = year(getdate()) and Themonth = month(getdate()) and TheDay = day(@date))  
end