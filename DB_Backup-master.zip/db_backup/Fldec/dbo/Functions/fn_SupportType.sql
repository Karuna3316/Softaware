﻿create function [dbo].[fn_SupportType]  
(  
   @SupportTypeId int 
  
)  
returns nvarchar(500)  
as  
begin return(select SupportType from Mt_SupportType where SupportTypeId = @SupportTypeId)  
end