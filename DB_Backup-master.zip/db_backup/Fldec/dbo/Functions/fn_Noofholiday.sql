﻿

CREATE function [dbo].[fn_Noofholiday]  
(  
   @userid int ,
   @month int,
   @year int
  
)  
returns int
as  
begin 
declare @resultbreak int
if(@userId = 15 or @userId = 17 or @userId = 18 or @userId = 23 or @userId = 33 or @userId = 103 or @userId = 131 or  @userId =25 or @userId = 59 or @userId = 88 or @userId = 98 or @userId = 112)
begin

if @month = (select month(createdDate) from tblusers where userid = @userid)
select @resultbreak = Count(*) from dbo.tblDim where month(date) = @month and year(date) = @year and Convert(varchar(12),date, 103) >= (select Convert(varchar(12),createdDate, 103) from tblusers where userid = @userid)
else
select @resultbreak = Count(*) from dbo.tblDim where month(date) = @month and year(date) = @year
end
else
begin

if @month = (select month(createdDate) from tblusers where userid = @userid)
select @resultbreak = Count(*) from tblDim where month(date) = @month and year(date) = @year and Convert(varchar(12),date, 103) >= (select Convert(varchar(12),createdDate, 103) from tblusers where userid = @userid)
else
select @resultbreak = Count(*) from tblDim where month(date) = @month and year(date) = @year
end


return @resultbreak

end