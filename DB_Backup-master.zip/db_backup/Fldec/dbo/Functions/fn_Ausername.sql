﻿CREATE function [dbo].[fn_Ausername]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select username from [Arboren].[dbo].[tblusers] where userid = @userid)  
end