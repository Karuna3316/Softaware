﻿CREATE function [dbo].[fn_RegularizationPendingCount]  
(  
   @userid int 
  
)  
returns int  
as  
begin return(select  count(*) as Count from tblReconciliationNew with(nolock) where reportingTo = @userid and year(CheckIn) = year(getdate())  and month(CheckIn) = month(getdate()) and approvedUser is null )  
end