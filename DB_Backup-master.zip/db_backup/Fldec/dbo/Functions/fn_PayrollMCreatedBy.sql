﻿CREATE function [dbo].[fn_PayrollMCreatedBy]  
(  
   @EmpName nvarchar(300) 
  
)  
returns nvarchar(300) 
as  
begin return(select top 1 case when Updatedby is null then  dbo.fn_username(CreatedBy) else  dbo.fn_username(UpdatedBy) end  from tblPayrollM with(nolock) where EmpName = @EmpName order by CreatedDate desc)  
end