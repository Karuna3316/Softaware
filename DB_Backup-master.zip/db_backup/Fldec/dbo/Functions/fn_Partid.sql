﻿create function [dbo].[fn_Partid]  
(  
   @PartNo nvarchar(200) 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 PartId from InvtblPartNo where PartNo = @PartNo)  
end