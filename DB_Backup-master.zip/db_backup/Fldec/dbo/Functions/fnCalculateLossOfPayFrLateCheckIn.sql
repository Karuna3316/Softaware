﻿--select dbo.fnCalculateLossOfPayFrLateCheckIn(20,6)
create function fnCalculateLossOfPayFrLateCheckIn(@userId int, @month int)
returns decimal(10,1)
as
begin
declare @tblLateCheckIn table(chkId int identity(1,1),daysDiffer int);
with tblFirstRows as(
select row_number() over(order by checkindate) as rNo,checkindate, userid from( select CheckInDate,userid
from tblaattendance where UserID=@userId and month(checkindate)=@month
and CAST(checkindate as time) > CAST('09:55' as time)) A),
 tblSecondRows as (
select row_number() over(order by checkindate) as rNo,checkindate, userid from( select CheckInDate,userid
from tblaattendance where UserID=@userId and month(checkindate)=@month
and CAST(checkindate as time) > CAST('09:55' as time)) B)

insert into @tblLateCheckIn(daysDiffer)
SELECT datediff(day,tblSecondRows.checkindate,tblFirstRows.checkindate) as daysDifference
FROM tblSecondRows LEFT OUTER JOIN tblFirstRows
ON tblFirstRows.rNo = tblSecondRows.rNo + 1;

declare @firstFiv int,@firstTen int, @firstFifteen int, @firstTwenty int
select @firstFiv = count(chkId) from @tblLateCheckIn where chkId <=5 and daysDiffer = 1
select @firstTen = count(chkId) from @tblLateCheckIn where chkId <=10 and daysDiffer = 1
select @firstFifteen = count(chkId) from @tblLateCheckIn where chkId <=15 and daysDiffer = 1
select @firstTwenty = count(chkId) from @tblLateCheckIn where chkId <=20 and daysDiffer = 1

declare @totalPenality decimal(10,1)
if(@firstTwenty = 20) set @totalPenality =2
else if (@firstFifteen = 15) set @totalPenality =1.5
else if(@firstTen = 10) set @totalPenality =1
else if (@firstFiv = 5) set @totalPenality = 0.5
else set @totalPenality = 0

declare @totalAbsent int
select @totalAbsent = dbo.fnGetDaysNotCaptured(@month,@userId)
return @totalPenality + @totalAbsent
end