﻿CREATE function [dbo].[fn_VECMaterial]  
(  
   @MaterialId int 
  
)  
returns nvarchar(500)  
as  
begin return(select  [MaterialName] from [dbo].[VECtblMaterial] where [MaterialId] = @MaterialId)  
end 


--select * from  [dbo].[VECtblTripdetails]