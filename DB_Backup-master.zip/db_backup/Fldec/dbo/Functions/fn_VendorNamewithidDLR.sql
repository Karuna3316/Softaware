﻿create function  [dbo].[fn_VendorNamewithidDLR]--('1') 
(  
   @Vendorid varchar(150) 
  
)  
returns nvarchar(max)  
as  
begin return(select '_' + ltrim(rtrim(JobNature)) + '_' from tblVendor where Vendorid = @Vendorid)  
end