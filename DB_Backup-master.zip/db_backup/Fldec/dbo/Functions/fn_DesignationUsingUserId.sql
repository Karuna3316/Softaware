﻿create function [dbo].[fn_DesignationUsingUserId]  
(  
   @UserId int 
  
)  
returns nvarchar(500)  
as  
begin return(select Designation from tblDesignation with (nolock) where DesignationID = (select U.DesignationId from tblusers U with(nolock) where userId = @UserId ) )
end