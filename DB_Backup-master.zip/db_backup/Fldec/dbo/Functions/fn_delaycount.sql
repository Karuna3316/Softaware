﻿create function [dbo].[fn_delaycount]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select username from tblusers where userid = @userid)  
end