﻿create function [dbo].[fn_joiningid]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select JoiningId from tblusers where userid = @userid)  
end