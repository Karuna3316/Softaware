﻿CREATE function [dbo].[fn_PayrollCreatedBy]  
(  
   @userid int 
  
)  
returns nvarchar(300) 
as  
begin return(select top 1 case when Updatedby is null then  dbo.fn_username(CreatedBy) else dbo.fn_username(Updatedby) end  from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end