﻿CREATE function  [dbo].[fn_VendorNameNew]--('1') 
(  
   @Vendorno varchar(150) 
  
)  
returns nvarchar(max)  
as  
begin return(select JobNature  from tblNVendor where VendorNo = @Vendorno)  
end