﻿CREATE function [dbo].[fn_HalfDayLeave]  
(  
   @userid int ,
   @month int,
   @year int
  
)  
returns decimal(18,1)
as  
begin 
declare @resultbreak decimal(18,1)

if(@userid = 148)
set @resultbreak = 0.0

else if(@userId = 15 or @userId = 17 or @userId = 18 or @userId = 23 or @userId = 33 or @userId = 103 or @userId = 131 or  @userId =25 or @userId = 59 or @userId = 88 or @userId = 98 or @userId = 112)
begin


set @resultbreak = (select  count(UserID) * 0.5 from tblAAttendance where year(checkindate)= @year and month(checkindate)= @month and UserID= @userid
and (CAST(checkindate as time) >= CAST('12:00' as time) or 
CAST(isnull(checkoutdate,'16:59') as time) <= CAST('16:59' as time)) and convert(varchar(12), checkindate, 103) not in (select convert(varchar(12), Date, 103) from dbo.tbldim where  month(date)= @month  and year(date)= @year))
end
else
begin

set @resultbreak = (select  count(UserID) * 0.5 from tblAAttendance where year(checkindate)= @year and month(checkindate)= @month and UserID= @userid
and (CAST(checkindate as time) >= CAST('12:00' as time) or 
CAST(isnull(checkoutdate,'16:59') as time) <= CAST('16:59' as time)) and convert(varchar(12), checkindate, 103) not in (select convert(varchar(12), Date, 103) from dbo.tbldim where  month(date)= @month  and year(date)= @year))
end


return @resultbreak

end