﻿CREATE function [dbo].[fn_PayrollCreatedDate]  
(  
   @userid int
  
)  
returns nvarchar(300) 
as  
begin return(select top 1 case when UpdatedDate is null then Convert(Varchar(12), CreatedDate, 103) else Convert(Varchar(12), UpdatedDate, 103) end  from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end