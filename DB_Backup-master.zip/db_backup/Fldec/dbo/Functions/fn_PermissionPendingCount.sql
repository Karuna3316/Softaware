﻿create function [dbo].[fn_PermissionPendingCount]  
(  
   @userid int 
  
)  
returns int  
as  
begin return(

select count(*) as Count  from tblPermission  where reportingTo = @userid and year(CheckIn) = year(getdate()) and  month(CheckIn) = month(getdate())  and approvedUser is null 

 )  
end