﻿create function [dbo].[fn_TeamUserid]  
(  
   @Userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select Team from tblTeam with (nolock) where TeamID = (select TeamID from tblUsers with (nolock) where userid = @Userid) )
end