﻿create function [dbo].[fn_suppliername]  
(  
   @sid int 
  
)  
returns nvarchar(500)  
as  
begin return(select SupplierName from [tblfdss_SupplierMaster] where sid = @sid)  
end