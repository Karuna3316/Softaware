﻿CREATE function [dbo].[fn_BilledJMR]  
(  
   @SLNo nvarchar(30) ,
  @Siteid int
)  
returns nvarchar(500)  
as  
begin return(select Sum(Qty) from tblInvoiceInstallation where SLNO = @SLNo and siteId = @Siteid)  
end