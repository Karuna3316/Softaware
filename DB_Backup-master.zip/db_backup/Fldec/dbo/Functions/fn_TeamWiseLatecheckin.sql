﻿create function [dbo].[fn_TeamWiseLatecheckin]  
(  
   @TeamID int 
  
)  
returns nvarchar(500)  
as  
begin return(

--select isnull( Count(*), 0) from tblUsers with(nolock) where active = 1 and  TeamId is not null and TeamId <> 0 and TeamId = @TeamID and userid   not  in  (select userid from tblAAttendance with(nolock) where 
--Convert(varchar(12), checkindate, 103) = Convert(varchar(12), getdate(), 103)) and userid  not  in (select userid from tblusers with(nolock) where active = 1 and projId is not null)

select isnull( Count(*), 0) from tblUsers with(nolock) where active = 1 and  TeamId is not null and TeamId <> 0 and TeamId = @TeamID and userid   in 
 (select userid from  tblAAttendance with(nolock) where  CONVERT(varchar(12), checkindate, 103) = CONVERT(varchar(12), getdate(), 103) and checkin =1  and 
((DATEPART(hour, CheckInDate) = 9  and  DATEPART(MINUTE, CheckInDate) >=51)  or (DATEPART(hour, CheckInDate) = 10 and   DATEPART(MINUTE, CheckInDate) >=0 ) or  (DATEPART(hour, CheckInDate) = 11 and   DATEPART(MINUTE, CheckInDate) >=0 )) and ( DATEPART(hour, CheckInDate) <= 12))
and userid  not  in (select userid from tblusers with(nolock) where active = 1 and projId is not null)



 )
end