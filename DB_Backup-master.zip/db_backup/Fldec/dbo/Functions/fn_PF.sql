﻿CREATE function [dbo].[fn_PF]  
(  
   @userid int 
  
)  
returns decimal(18,2) 
as  
begin return(select top 1 isnull( EPFEmployeeContribution, 0) + isnull(EPFEmployerContribution, 0) from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end