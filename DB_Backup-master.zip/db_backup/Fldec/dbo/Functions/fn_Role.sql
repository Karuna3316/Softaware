﻿create function [dbo].[fn_Role]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(


select roleName  from tblUsers U with(nolock) 
inner join tblRoleMapping RM
on RM.userid = U.userId
inner join tblroles R
on R.roleId = RM.roleId where U.userid =  @userid 


 )
end