﻿CREATE function [dbo].[fn_LBId]  
(  
   @Userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 lBId from tblLeaveBalanceMaster where userid = @Userid order by CreatedDate desc)  
end