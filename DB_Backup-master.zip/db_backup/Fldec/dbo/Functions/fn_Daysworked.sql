﻿CREATE function [dbo].[fn_Daysworked]  
(  
   @userid int ,
   @month int,
   @year int
  
)  
returns int
as  
begin 
declare @resultbreak int

if(@userid = 148)
set @resultbreak = ( select count(distinct day(checkindate)) from tblAAttendance where year(checkindate)= @year and month(checkindate)= @month and day(checkindate) not in ((select distinct day(date) from dbo.tblDim where month([date])= @month and year([Date]) = @year))
) + (select count(distinct date) from dbo.tblDim where month([date])= @month and year([Date]) = @year)



else if(@userId = 15 or @userId = 17 or @userId = 18 or @userId = 23 or @userId = 33 or @userId = 103 or @userId = 131 or  @userId =25 or @userId = 59 or @userId = 88 or @userId = 98 or @userId = 112)
begin


select @resultbreak =  ( select count(UserID) from tblAAttendance where year(checkindate)= @year and month(checkindate)= @month
and UserID=@userid) - (select count(UserID) from tblAAttendance where userid=@userid and month(checkindate)= @month and year(checkindate)= @year
and day(checkindate) in (select day(Date) from dbo.tblDim where month([date])= @month and year([Date]) = @year))
end
else
begin

select @resultbreak = ( select count(UserID) from tblAAttendance where year(checkindate)= @year and month(checkindate)= @month
and UserID=@userid) - (select count(UserID) from tblAAttendance where userid=@userid and month(checkindate)= @month and year(checkindate)= @year
and day(checkindate) in (select day(Date) from dbo.tblDim where month([date])= @month and year([Date]) = @year))
end


return @resultbreak

end