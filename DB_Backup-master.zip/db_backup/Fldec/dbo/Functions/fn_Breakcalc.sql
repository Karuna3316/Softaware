﻿
create function [dbo].[fn_Breakcalc]  
(  
   @break int 
  
)  
returns nvarchar(5)  
as  
begin 


declare @resultbreak varchar(20)

if (@break <60) 
begin
if (select len(@break)) = 1
begin
set @resultbreak = '00:' + '0' + convert(varchar(2), @break)
end
else 
set @resultbreak = '00:' +  convert(varchar(2), @break)
end

else if(@break = 60)
begin
set @resultbreak = '01:00'

end
else if(@break = 120)
begin
set @resultbreak = '02:00'

end
else if(@break = 180)
begin
set @resultbreak = '03:00'

end
else if(@break = 240)
begin
set @resultbreak = '04:00'

end
else if (@break <= 120 and @break >= 61)
begin
set @break = @break - 60

if (select len(@break)) = 1
begin
set @resultbreak = '01:'+ '0' + convert(varchar(2), @break)

end
else 
begin
set @resultbreak = '01:'+  convert(varchar(2), @break)

end
end
else if (@break <= 180 and @break >= 121)
begin
set @break = @break - 120

if (select len(@break)) = 1
begin
set @resultbreak = '02:'+ '0' + convert(varchar(2), @break)

end
else 
begin
set @resultbreak = '02:'+  convert(varchar(2), @break)

end
end
else if (@break <= 240 and @break >= 181)
begin
set @break = @break - 180

if (select len(@break)) = 1
begin
set @resultbreak = '03:'+ '0' + convert(varchar(2), @break)

end
else 
begin
set @resultbreak = '03:'+  convert(varchar(2), @break)

end
end

return @resultbreak

end 

--select [dbo].[fn_Breakcalc] (30)