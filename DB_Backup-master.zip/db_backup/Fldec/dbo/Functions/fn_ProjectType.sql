﻿CREATE function [dbo].[fn_ProjectType]  
(  
   @ProjectTypeId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 ProjectTypeName from InvProjectType where ProjectTypeId = @ProjectTypeId)  
end