﻿create function [dbo].[fn_ProfessionalTax]  
(  
   @userid int 
  
)  
returns decimal(18,2) 
as  
begin return(select top 1 ProfessionalTax from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end