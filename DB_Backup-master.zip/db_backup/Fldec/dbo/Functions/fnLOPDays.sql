﻿CREATE FUNCTION  [dbo].[fnLOPDays]
(  @userId int,
      @mon int,
      @year int 
)
RETURNS int
as
begin
declare @LOPDays int
declare @totalDaysInMonth int

select @totalDaysInMonth=case @mon 
when 12 then 31 when 11 then 30 when 10 then 31 when 9 then 30 when 8 then 31 when 7 then 31 
when 6 then 30 when 5 then 31 when 4 then 30 when 3 then 31 when 2 then 28 when 1 then 31 
end

declare @totalLea int, @clAvail int, @slAvail int

Select  @slAvail = isnull(sum(case when leaveDaysType = 1 and leaveCategory=2 and isApproved=1 then 1   
when leaveDaysType = 3 and leaveCategory=2  then 0.5
when leaveDaysType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)     
else 0 end),0) +   isnull(sum(case when leaveType = 1 and leaveCategory=2 and isApproved=1 then 1 
when leaveType = 3 and leaveCategory=2  then 0.5
when leaveType= 2 and leaveCategory=2 and isApproved=1 then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)   
else 0 end),0) ,
@clAvail = isnull(sum(case when leaveDaysType = 1 and leaveCategory=1 then 1    
when leaveDaysType = 3 and leaveCategory=1 then 0.5
 when leaveDaysType= 2 and leaveCategory=1 
then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)      else 0 end),0) +   
isnull(sum(case when leaveType = 1 and leaveCategory=1 then 1    
when leaveType = 3 and leaveCategory=1  then 0.5 
when leaveType= 2 and leaveCategory=1 
then dbo.fnCalculateLeaveCntFrMultipleDays(leaveStartedOn,leaveEndsOn,@mon)      else 0 end),0) ,

@totalLea = @totalDaysInMonth-(
(select count(DimId) from tblDim where year(date)= @year and month(date) = @mon) +
(select count(UserID) from tblAAttendance where year(checkindate)= @year and month(checkindate)=@mon and UserID=@userId
	and day(checkindate) not in(select day(date) from tblDim where year(date)=@year and month(date) = @mon)
	and CAST(checkindate as time) <= CAST('12:30' as time) and 
	CAST(checkoutdate as time) >= CAST('17:30' as time)) +
(select count(userId)*0.5 from tblAAttendance where year(checkindate)= @year 
and month(checkindate)=@mon and UserID =@userId
and (CAST(checkindate as time) >= CAST('12:30' as time) or 
CAST(checkoutdate as time) <= CAST('17:30' as time)))) 
from  tblRequestLeave where userId = @userId and isApproved=1 and   year(leaveStartedOn)=@year and month(leaveStartedOn) = @mon 

SELECT @LOPDays= @totalDaysInMonth -(@totalLea-( @clAvail+ @slAvail)) 

return @LOPDays
end