﻿CREATE function  [dbo].[fn_VendorNamewithid]
(  
   @Vendorid varchar(150) 
  
)  
returns nvarchar(max)  
as  
begin return(select JobNature + ' (' + Vendorno + ' ' + VendorName + ')'  from tblVendor where Vendorid = @Vendorid)  
end