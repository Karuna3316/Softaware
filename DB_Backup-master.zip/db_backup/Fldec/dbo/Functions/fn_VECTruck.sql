﻿CREATE function [dbo].[fn_VECTruck]  
(  
   @TruckId int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 [TruckNo] from [dbo].[VECtblTruck] where [TruckId] = @TruckId)  
end 


--select * from  [dbo].[VECtblTripdetails]