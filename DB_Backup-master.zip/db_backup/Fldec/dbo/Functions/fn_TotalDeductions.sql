﻿CREATE function [dbo].[fn_TotalDeductions]  
(  
   @userid int 
  
)  
returns decimal(18,2) 
as  
begin return(select top 1 isnull(TDS,0) + isnull(LoanOrAdvance,0) + isnull(EPFEmployeeContribution,0) + isnull(EPFEmployerContribution,0) + isnull(ESICEmployeeContribution,0) + isnull(ESICEmployerContribution,0) +  isnull(ProfessionalTax,0) from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end