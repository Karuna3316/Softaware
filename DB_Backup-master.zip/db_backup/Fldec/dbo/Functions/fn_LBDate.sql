﻿create function [dbo].[fn_LBDate]  
(  
   @Userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select top 1 convert(varchar(12), CreatedDate, 103) from tblLeaveBalanceMaster where userid = @Userid order by CreatedDate desc)  
end