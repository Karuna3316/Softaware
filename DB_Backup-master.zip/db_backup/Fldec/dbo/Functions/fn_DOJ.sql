﻿create function [dbo].[fn_DOJ]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select convert(varchar(12), DOJ, 103)  from tblUsers with(nolock) where userid =  @userid  )
end