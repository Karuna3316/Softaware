﻿Create function  [dbo].[fn_VendorIdNew]  --(' 4POP ')
(  
   @Vendorno varchar(150) 
  
)  
returns nvarchar(500)  
as  
begin return(select VendorID from tblNVendor where VendorNo = LTRIM(Rtrim(@Vendorno)))  
end