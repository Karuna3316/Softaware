﻿CREATE function  [dbo].[fn_VendorName]--('1') 
(  
   @Vendorno varchar(150) 
  
)  
returns nvarchar(max)  
as  
begin return(select JobNature + ' (' + VendorName + ')'  from tblVendor where VendorNo = @Vendorno)  
end