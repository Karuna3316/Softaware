﻿CREATE function [dbo].[fn_AnnualCTC]  
(  
   @userid int 
  
)  
returns decimal(18,2) 
as  
begin return(select top 1 convert(decimal(18,2),(GrossSalary/12 + isnull( EPFEmployerContribution,0)) * 12) from tblPayrollRegister where userid = @userid order by CreatedDate desc)  
end