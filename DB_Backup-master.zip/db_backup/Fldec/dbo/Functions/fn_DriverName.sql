﻿CREATE function [dbo].[fn_DriverName]  
(  
   @DriverId int 
  
)  
returns nvarchar(500)  
as  
begin return(select DriverName from [Menaka].[dbo].tbldriver where Driverid = @DriverId)  
end