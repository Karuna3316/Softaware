﻿Create function [dbo].[fn_Tusername]  
(  
   @userid int 
  
)  
returns nvarchar(500)  
as  
begin return(select username from [dbo].[tblTusers] where userid = @userid)  
end