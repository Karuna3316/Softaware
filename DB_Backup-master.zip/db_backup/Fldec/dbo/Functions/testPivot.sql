﻿
CREATE function [dbo].[testPivot]  
(  
   @dateStr nvarchar(50),@uId int ,@present int  
)  
returns nvarchar(50)  
as 
begin declare @returnString nvarchar(200)
if @present = 1
begin
set @returnString='P'
if exists(select AttendanceID from tblAAttendance where UserID = @uId and  convert(varchar,checkindate,103)=@dateStr
 and ( CAST(checkindate as time) >= CAST('12:00' as time) or 
CAST(checkoutdate as time) <= CAST('17:00' as time)))
set @returnString='HP'
end
else
begin
	if exists(select DimId from tblDim where convert(varchar,[Date],103)=@dateStr)
	select @returnString='H'
	else
		select @returnString='A'
end

 return @returnString  
end