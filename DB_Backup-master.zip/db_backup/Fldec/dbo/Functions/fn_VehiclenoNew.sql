﻿CREATE function [dbo].[fn_VehiclenoNew]  
(  
   @VehiclelogId int 
  
)  
returns nvarchar(500)  
as  
begin return(select VehicleNo from [Menaka].[dbo].tblVehiclelog where VehiclelogId = @VehiclelogId)  
end